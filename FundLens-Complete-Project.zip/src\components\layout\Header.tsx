// Top Navigation Header with Data Status, Reporting Date, and Action Buttons

import React from 'react';
import { UploadCloud, RefreshCw, Calendar, Database, ShieldCheck, Globe } from 'lucide-react';
import { formatDate } from '../../lib/formatting';

export type DataSourceMode = 'live' | 'uploaded';

interface HeaderProps {
  currentTabName: string;
  dataSourceMode: DataSourceMode;
  reportingDate?: string;
  onNavigateToUpload: () => void;
  onResetPortfolio: () => void;
  onSwitchToLiveIndianData: () => void;
  completenessScore?: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTabName,
  dataSourceMode,
  reportingDate,
  onNavigateToUpload,
  onResetPortfolio,
  onSwitchToLiveIndianData,
  completenessScore = 100,
}) => {
  return (
    <header className="sticky top-0 z-20 bg-white/95 backdrop-blur-sm border-b border-border px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
      {/* Breadcrumb / Title */}
      <div className="flex items-center gap-2.5">
        <span className="text-xs font-semibold uppercase tracking-wider text-text-sub">FundLens</span>
        <span className="text-border-dark text-xs">/</span>
        <h1 className="text-lg font-bold text-text-main tracking-tight">{currentTabName}</h1>
      </div>

      {/* Right Controls & Data Badges */}
      <div className="flex items-center gap-3 flex-wrap">
        {/* Data Source Badge */}
        <div
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border ${
            dataSourceMode === 'live'
              ? 'bg-emerald-50 text-emerald-800 border-emerald-300 font-semibold'
              : 'bg-blue-50 text-blue-800 border-blue-200'
          }`}
        >
          {dataSourceMode === 'live' ? (
            <>
              <Globe className="w-3.5 h-3.5 text-primary" />
              <span>Live Indian Mutual Funds (MFAPI / AMFI)</span>
            </>
          ) : (
            <>
              <Database className="w-3.5 h-3.5 text-blue-600" />
              <span>User Uploaded Disclosures</span>
            </>
          )}
        </div>

        {/* Reporting Date Badge */}
        {reportingDate && (
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-[#F6F8FA] text-text-sub border border-border">
            <Calendar className="w-3.5 h-3.5 text-text-sub" />
            <span>As of {formatDate(reportingDate)}</span>
          </div>
        )}

        {/* Data Completeness Badge */}
        <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-[#F6F8FA] text-text-sub border border-border">
          <ShieldCheck className="w-3.5 h-3.5 text-primary" />
          <span>Quality: {completenessScore}%</span>
        </div>

        {/* Reset / Switch Action Buttons */}
        {dataSourceMode === 'uploaded' ? (
          <button
            onClick={onSwitchToLiveIndianData}
            className="inline-flex items-center gap-1.5 bg-primary hover:bg-primary-hover text-white px-3.5 py-1.5 rounded-xl text-xs font-semibold shadow-xs transition-all"
            title="Switch back to live Indian mutual fund holdings from MFAPI"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Restore Live Indian Data</span>
          </button>
        ) : (
          <button
            onClick={onResetPortfolio}
            className="inline-flex items-center gap-1.5 bg-white hover:bg-slate-50 text-text-main border border-border px-3 py-1.5 rounded-xl text-xs font-medium shadow-xs transition-all"
            title="Reset portfolio allocation to default live Indian mutual fund schemes"
          >
            <RefreshCw className="w-3.5 h-3.5 text-text-sub" />
            <span>Reset Portfolio</span>
          </button>
        )}

        <button
          onClick={onNavigateToUpload}
          className="inline-flex items-center gap-1.5 bg-white hover:bg-slate-50 text-text-main border border-border px-3 py-1.5 rounded-xl text-xs font-medium shadow-xs transition-all"
          title="Upload mutual fund portfolio CSV"
        >
          <UploadCloud className="w-3.5 h-3.5 text-text-sub" />
          <span>Upload CSV</span>
        </button>
      </div>
    </header>
  );
};
