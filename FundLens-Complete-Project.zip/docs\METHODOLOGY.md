# FundLens Quantitative Methodology & Mathematical Formulations

This document specifies the exact mathematical principles, concentration formulas, and aggregation rules executed by FundLens.

---

## 1. Pairwise Weighted Fund Overlap

Given Fund $A$ and Fund $B$ with respective holding weight vectors $w_{i,A}$ and $w_{i,B}$ across all common companies $i$, the weighted portfolio overlap $O_{A,B}$ is computed as:

$$O_{A,B} = \sum_{i \in A \cap B} \min(w_{i,A}, w_{i,B})$$

### Core Properties:
- **Boundedness:** $0.0 \le O_{A,B} \le 1.0$ (or $0\% \le O_{A,B} \le 100\%$).
- **Symmetry:** $O_{A,B} = O_{B,A}$ for all pairs $A, B$.
- **Self-Overlap:** For any fund $A$ compared with itself, $O_{A,A} = \sum_i \min(w_{i,A}, w_{i,A}) = \sum_i w_{i,A}$. If equity holdings account for $94.5\%$ of assets (with $5.5\%$ held in cash), the true self-overlap is exactly $94.5\%$. FundLens computes this directly from holdings without hardcoding $100\%$.

### Example Calculation:
If Fund A holds $6.0\%$ HDFC Bank and Fund B holds $4.0\%$ HDFC Bank, the shared overlapping contribution from HDFC Bank is:
$$\min(6.0\%, 4.0\%) = 4.0\%$$

---

## 2. Effective Look-Through Stock Exposure

When an investor allocates weights $a_j$ across $M$ mutual funds in their portfolio, the effective exposure $E_i$ to an individual underlying stock $i$ is:

$$E_i = \sum_{j=1}^M a_j \cdot w_{i,j}$$

where:
- $a_j$ is the investor's portfolio allocation weight assigned to Fund $j$ (normalized such that $\sum_{j=1}^M a_j = 1$).
- $w_{i,j}$ is the weight of stock $i$ inside Fund $j$.

If a stock is held across 4 different mutual funds, the investor's actual ownership is the weighted sum of all 4 allocations.

---

## 3. Portfolio Concentration: Herfindahl-Hirschman Index (HHI)

To measure whether a portfolio is genuinely diversified or dominated by a small handful of stocks, FundLens computes the Herfindahl-Hirschman Index (HHI) across all effective stock exposures:

$$\text{HHI} = \sum_{i=1}^N p_i^2$$

where $p_i = \frac{E_i}{\sum_{k=1}^N E_k}$ represents the relative weight of stock $i$ as a proportion of total equity holdings.

### Benchmarks:
- $\text{HHI} < 0.05$ ($< 500$ on 10,000 scale): **Highly Diversified**
- $0.05 \le \text{HHI} \le 0.15$ ($500 - 1500$): **Moderate Concentration**
- $\text{HHI} > 0.15$ ($> 1500$): **High Concentration / Idiosyncratic Risk**

---

## 4. Effective Number of Holdings ($N_{\text{eff}}$)

The inverse of HHI yields the Effective Number of Equal-Weighted Holdings ($N_{\text{eff}}$):

$$N_{\text{eff}} = \frac{1}{\text{HHI}} = \frac{1}{\sum_{i=1}^N p_i^2}$$

### Interpretation:
If a portfolio contains 150 individual stock holdings across 4 funds, but $N_{\text{eff}} = 24.5$, the portfolio has the exact same concentration risk as a portfolio of only 25 equally weighted stocks. The remaining 125 holdings are long-tail micro-positions that provide negligible diversification benefit while generating potential tracking drag and overlap.

---

## 5. Sector & Market Cap Aggregations

Sector exposure $S_k$ for sector $k$ is given by:

$$S_k = \sum_{i \in \text{Sector}_k} E_i$$

### Denominator Setting:
- **Total Portfolio Assets:** Evaluates sector weights relative to $100\%$ of invested wealth (including fund cash/derivatives).
- **Classified Equity Assets:** Evaluates sector weights normalized exclusively against the disclosed equity subset ($\sum_k S_k = 100\%$).

### SEBI Market Capitalization Tiers:
- **Large-Cap:** Top 100 companies by average full market capitalization.
- **Mid-Cap:** 101st to 250th companies by market capitalization.
- **Small-Cap:** 251st company onwards.
- **Unclassified:** Foreign securities, cash, bonds, or unlisted holdings.
