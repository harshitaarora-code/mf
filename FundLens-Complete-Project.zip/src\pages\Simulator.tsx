// What-If Fund Replacement Simulator Screen for FundLens

import React, { useState } from 'react';
import {
  PortfolioFundItem,
  FundMeta,
  Holding,
  PortfolioMode,
} from '../types';
import { simulateFundReplacement } from '../lib/analytics';
import { formatPercent } from '../lib/formatting';
import {
  Sparkles,
  ArrowRight,
  RotateCcw,
  TrendingDown,
  TrendingUp,
  Minus,
  CheckCircle2,
  AlertTriangle,
  Building2,
  Layers,
  HelpCircle,
} from 'lucide-react';

interface SimulatorProps {
  portfolio: PortfolioFundItem[];
  availableFunds: FundMeta[];
  allHoldings: Holding[];
  mode: PortfolioMode;
}

export const Simulator: React.FC<SimulatorProps> = ({
  portfolio,
  availableFunds,
  allHoldings,
  mode,
}) => {
  // Candidate funds to replace
  const currentFundNames = portfolio.map((p) => p.fundName);

  const [targetFund, setTargetFund] = useState<string>(currentFundNames[0] || '');
  // Default replacement fund that is NOT currently in the portfolio
  const replacementCandidates = availableFunds.filter(
    (f) => !currentFundNames.includes(f.fundName)
  );
  const [replacementFund, setReplacementFund] = useState<string>(
    replacementCandidates[0]?.fundName || ''
  );

  // Check if replacement has holdings
  const replacementHoldings = allHoldings.filter((h) => h.fundName === replacementFund);
  const hasReplacementHoldings = replacementHoldings.length > 0;

  // Run authentic what-if simulation calculation
  const simulation =
    targetFund && replacementFund && hasReplacementHoldings
      ? simulateFundReplacement(portfolio, targetFund, replacementFund, allHoldings, mode)
      : null;

  const handleReset = () => {
    setTargetFund(currentFundNames[0] || '');
    setReplacementFund(replacementCandidates[0]?.fundName || '');
  };

  const renderDelta = (delta: number, formatAsPercentage = true, invertGood = false) => {
    if (Math.abs(delta) < 0.0001) {
      return (
        <span className="inline-flex items-center gap-0.5 text-xs text-text-sub font-semibold">
          <Minus className="w-3 h-3" /> No Change
        </span>
      );
    }

    const isPositive = delta > 0;
    // For concentration / overlap, usually a reduction (negative) is diversification improvement
    const isGood = invertGood ? !isPositive : isPositive;

    return (
      <span
        className={`inline-flex items-center gap-0.5 text-xs font-bold tabular-nums ${
          isGood ? 'text-emerald-700' : 'text-amber-700'
        }`}
      >
        {isPositive ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
        <span>
          {isPositive ? '+' : ''}
          {formatAsPercentage ? (delta * 100).toFixed(2) + '%' : delta.toFixed(2)}
        </span>
      </span>
    );
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Hero Header */}
      <div className="bg-white p-6 rounded-2xl border border-border shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-primary-light text-primary border border-primary-border">
                Portfolio Optimization Lab
              </span>
              <span className="text-xs text-text-sub">• Full Engine Recalculation</span>
            </div>
            <h2 className="text-2xl font-bold text-text-main tracking-tight">
              What-If Fund Replacement Simulator
            </h2>
            <p className="text-xs text-text-sub mt-1 max-w-2xl">
              Model replacing an existing mutual fund with a candidate scheme while keeping your target allocation constant. All underlying stock and sector metrics are freshly computed.
            </p>
          </div>

          <button
            onClick={handleReset}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-slate-50 text-text-main border border-border rounded-xl text-xs font-semibold shadow-2xs transition-all shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5 text-text-sub" />
            <span>Reset Simulation</span>
          </button>
        </div>

        {/* Replacement Controls Box */}
        <div className="mt-6 pt-6 border-t border-border grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          {/* Target Fund to Replace */}
          <div className="md:col-span-5 space-y-1">
            <label className="text-xs font-semibold text-text-sub block">
              1. Current Fund to Replace
            </label>
            <select
              value={targetFund}
              onChange={(e) => setTargetFund(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-border text-xs font-semibold text-text-main bg-[#F8F9FA] focus:outline-hidden focus:border-primary truncate"
            >
              {currentFundNames.map((name) => (
                <option key={`curr-${name}`} value={name}>
                  {name}
                </option>
              ))}
            </select>
          </div>

          {/* Arrow */}
          <div className="md:col-span-2 flex justify-center">
            <div className="w-9 h-9 rounded-full bg-primary-light border border-primary-border flex items-center justify-center text-primary">
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>

          {/* Replacement Candidate */}
          <div className="md:col-span-5 space-y-1">
            <label className="text-xs font-semibold text-text-sub block">
              2. Candidate Replacement Scheme
            </label>
            <select
              value={replacementFund}
              onChange={(e) => setReplacementFund(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-border text-xs font-semibold text-text-main bg-white focus:outline-hidden focus:border-primary truncate"
            >
              {replacementCandidates.map((f) => (
                <option key={`rep-${f.fundName}`} value={f.fundName}>
                  {f.fundName} ({f.category})
                </option>
              ))}
            </select>
          </div>
        </div>

        {!hasReplacementHoldings && (
          <div className="mt-4 p-3 bg-red-50 text-red-800 rounded-xl border border-red-200 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            <span>
              The selected replacement scheme has no valid holdings disclosure in the database. What-if recalculation cannot be performed.
            </span>
          </div>
        )}
      </div>

      {/* Before vs After Comparison Grid */}
      {simulation && (
        <div className="space-y-6">
          {/* Metric By Metric Comparison Cards */}
          <div className="bg-white rounded-2xl border border-border p-5 shadow-xs">
            <div className="mb-4">
              <h3 className="text-sm font-bold text-text-main">Deterministic Metric-by-Metric Impact</h3>
              <p className="text-[11px] text-text-sub">
                Side-by-side comparison between your Current Portfolio and the Simulated Portfolio
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Metric 1: Unique Stocks */}
              <div className="p-4 rounded-xl border border-border bg-[#F8F9FA]/60">
                <span className="text-[11px] font-semibold text-text-sub block">Unique Underlying Stocks</span>
                <div className="flex items-baseline justify-between mt-2">
                  <div className="text-xs text-text-sub">
                    Before: <strong className="text-text-main tabular-nums">{simulation.original.uniqueStocksCount}</strong>
                  </div>
                  <div className="text-sm font-bold text-text-main tabular-nums">
                    After: {simulation.simulated.uniqueStocksCount}
                  </div>
                </div>
                <div className="mt-2 pt-2 border-t border-border/80 flex items-center justify-between">
                  <span className="text-[10px] text-text-sub">Net Delta:</span>
                  {renderDelta(
                    simulation.simulated.uniqueStocksCount - simulation.original.uniqueStocksCount,
                    false,
                    false
                  )}
                </div>
              </div>

              {/* Metric 2: Portfolio Overlap */}
              <div className="p-4 rounded-xl border border-border bg-[#F8F9FA]/60">
                <span className="text-[11px] font-semibold text-text-sub block">Portfolio Overlap</span>
                <div className="flex items-baseline justify-between mt-2">
                  <div className="text-xs text-text-sub">
                    Before: <strong className="text-text-main tabular-nums">{formatPercent(simulation.original.portfolioWeightedOverlap)}</strong>
                  </div>
                  <div className="text-sm font-bold text-text-main tabular-nums">
                    After: {formatPercent(simulation.simulated.portfolioWeightedOverlap)}
                  </div>
                </div>
                <div className="mt-2 pt-2 border-t border-border/80 flex items-center justify-between">
                  <span className="text-[10px] text-text-sub">Net Delta:</span>
                  {renderDelta(
                    simulation.simulated.portfolioWeightedOverlap - simulation.original.portfolioWeightedOverlap,
                    true,
                    true
                  )}
                </div>
              </div>

              {/* Metric 3: Top 5 Stock Exposure */}
              <div className="p-4 rounded-xl border border-border bg-[#F8F9FA]/60">
                <span className="text-[11px] font-semibold text-text-sub block">Top 5 Concentration</span>
                <div className="flex items-baseline justify-between mt-2">
                  <div className="text-xs text-text-sub">
                    Before: <strong className="text-text-main tabular-nums">{formatPercent(simulation.original.top5StockExposure)}</strong>
                  </div>
                  <div className="text-sm font-bold text-text-main tabular-nums">
                    After: {formatPercent(simulation.simulated.top5StockExposure)}
                  </div>
                </div>
                <div className="mt-2 pt-2 border-t border-border/80 flex items-center justify-between">
                  <span className="text-[10px] text-text-sub">Net Delta:</span>
                  {renderDelta(
                    simulation.simulated.top5StockExposure - simulation.original.top5StockExposure,
                    true,
                    true
                  )}
                </div>
              </div>

              {/* Metric 4: Effective Holdings (1/HHI) */}
              <div className="p-4 rounded-xl border border-border bg-[#F8F9FA]/60">
                <span className="text-[11px] font-semibold text-text-sub block">Effective Holdings (1/HHI)</span>
                <div className="flex items-baseline justify-between mt-2">
                  <div className="text-xs text-text-sub">
                    Before: <strong className="text-text-main tabular-nums">{simulation.original.effectiveHoldings.toFixed(1)}</strong>
                  </div>
                  <div className="text-sm font-bold text-text-main tabular-nums">
                    After: {simulation.simulated.effectiveHoldings.toFixed(1)}
                  </div>
                </div>
                <div className="mt-2 pt-2 border-t border-border/80 flex items-center justify-between">
                  <span className="text-[10px] text-text-sub">Net Delta:</span>
                  {renderDelta(
                    simulation.simulated.effectiveHoldings - simulation.original.effectiveHoldings,
                    false,
                    false
                  )}
                </div>
              </div>
            </div>

            {/* Transparent Explanation Box */}
            <div className="mt-4 p-4 rounded-xl bg-blue-50/60 border border-blue-200 text-xs text-blue-900 leading-relaxed">
              <strong>Analytical Interpretation:</strong> Replacing <em>{targetFund}</em> with <em>{replacementFund}</em>{' '}
              {simulation.simulated.portfolioWeightedOverlap < simulation.original.portfolioWeightedOverlap
                ? `reduces portfolio overlap by ${formatPercent(
                    simulation.original.portfolioWeightedOverlap - simulation.simulated.portfolioWeightedOverlap
                  )} and increases unique holdings from ${simulation.original.uniqueStocksCount} to ${simulation.simulated.uniqueStocksCount}.`
                : `increases portfolio overlap by ${formatPercent(
                    simulation.simulated.portfolioWeightedOverlap - simulation.original.portfolioWeightedOverlap
                  )} due to overlapping holdings in common with the rest of your portfolio.`}
              <div className="mt-1 text-[11px] text-blue-800">
                <em>Notice:</em> Lower overlap signifies greater differentiation in underlying securities, but does not guarantee lower volatility, smaller drawdowns, or superior future performance.
              </div>
            </div>
          </div>

          {/* Underlying Stock Exposure Changes Table */}
          <div className="bg-white rounded-2xl border border-border shadow-xs overflow-hidden">
            <div className="p-4 border-b border-border bg-[#F8F9FA] flex items-center justify-between">
              <h3 className="text-xs font-bold text-text-main uppercase tracking-wider">
                Key Underlying Security Exposure Shifts
              </h3>
              <span className="text-xs text-text-sub">
                Sorted by largest absolute percentage change
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#F8F9FA]/60 text-text-sub border-b border-border">
                  <tr>
                    <th className="p-3.5 font-semibold">Underlying Company</th>
                    <th className="p-3.5 font-semibold">Sector</th>
                    <th className="p-3.5 font-semibold text-right">Original Weight</th>
                    <th className="p-3.5 font-semibold text-right">Simulated Weight</th>
                    <th className="p-3.5 font-semibold text-right">Net Shift (Δ)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {simulation.exposureDeltas.slice(0, 15).map((d) => (
                    <tr key={d.securityName} className="hover:bg-slate-50/50">
                      <td className="p-3.5 font-semibold text-text-main flex items-center gap-2">
                        <Building2 className="w-3.5 h-3.5 text-text-sub shrink-0" />
                        <span>{d.securityName}</span>
                      </td>
                      <td className="p-3.5 text-text-sub">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 border border-slate-200">
                          {d.sector}
                        </span>
                      </td>
                      <td className="p-3.5 text-right tabular-nums text-text-sub">
                        {formatPercent(d.originalWeight)}
                      </td>
                      <td className="p-3.5 text-right tabular-nums text-text-main font-semibold">
                        {formatPercent(d.simulatedWeight)}
                      </td>
                      <td className="p-3.5 text-right tabular-nums">
                        {renderDelta(d.delta, true, false)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
