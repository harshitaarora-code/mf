// Insight Card for Rule-Based Portfolio Observations

import React from 'react';
import { AlertTriangle, Info, CheckCircle2, ArrowRight } from 'lucide-react';
import { PortfolioInsight } from '../../types';

interface InsightCardProps {
  insight: PortfolioInsight;
  onActionClick: (screen: string, filter?: string) => void;
}

export const InsightCard: React.FC<InsightCardProps> = ({ insight, onActionClick }) => {
  const getStyleConfig = () => {
    switch (insight.type) {
      case 'warning':
        return {
          cardBg: 'bg-amber-50/50 hover:bg-amber-50/80',
          border: 'border-amber-200',
          iconColor: 'text-amber-600',
          icon: AlertTriangle,
          badgeBg: 'bg-amber-100 text-amber-900 border-amber-300',
        };
      case 'positive':
        return {
          cardBg: 'bg-emerald-50/50 hover:bg-emerald-50/80',
          border: 'border-emerald-200',
          iconColor: 'text-emerald-600',
          icon: CheckCircle2,
          badgeBg: 'bg-emerald-100 text-emerald-900 border-emerald-300',
        };
      default:
        return {
          cardBg: 'bg-blue-50/50 hover:bg-blue-50/80',
          border: 'border-blue-200',
          iconColor: 'text-blue-600',
          icon: Info,
          badgeBg: 'bg-blue-100 text-blue-900 border-blue-300',
        };
    }
  };

  const style = getStyleConfig();
  const Icon = style.icon;

  return (
    <div
      className={`rounded-xl border p-4 transition-all shadow-2xs ${style.cardBg} ${style.border}`}
    >
      <div className="flex items-start gap-3">
        <div className={`mt-0.5 shrink-0 ${style.iconColor}`}>
          <Icon className="w-4 h-4" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 mb-1">
            <h4 className="text-xs font-semibold text-text-main truncate">
              {insight.title}
            </h4>
            {insight.metricValue && (
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full border tabular-nums shrink-0 ${style.badgeBg}`}
              >
                {insight.metricLabel ? `${insight.metricLabel}: ` : ''}
                {insight.metricValue}
              </span>
            )}
          </div>
          <p className="text-[12px] text-text-sub leading-relaxed mb-2.5">
            {insight.description}
          </p>

          {insight.actionScreen && (
            <button
              onClick={() => onActionClick(insight.actionScreen!, insight.filterPayload)}
              className="inline-flex items-center gap-1 text-[11px] font-semibold text-primary hover:text-primary-hover hover:underline"
            >
              <span>{insight.actionText || 'View detailed analysis'}</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
