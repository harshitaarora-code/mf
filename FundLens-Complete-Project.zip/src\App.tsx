// FundLens Main Application Root Container - Powered by Live Indian Mutual Funds (MFAPI / AMFI)

import React, { useState, useMemo } from 'react';
import {
  PortfolioFundItem,
  FundMeta,
  Holding,
  PortfolioMode,
  EffectiveStockExposure,
} from './types';
import {
  LIVE_INDIAN_FUNDS,
  LIVE_INDIAN_HOLDINGS,
  LIVE_INDIAN_DEFAULT_PORTFOLIO,
} from './data/liveIndianFundsData';
import { calculatePortfolioAnalytics, normalizeWeights } from './lib/analytics';
import { generatePortfolioInsights } from './lib/insights';

import { Sidebar, NavScreenId } from './components/layout/Sidebar';
import { Header, DataSourceMode } from './components/layout/Header';
import { DataBanner } from './components/layout/DataBanner';

import { Overview } from './pages/Overview';
import { Portfolio } from './pages/Portfolio';
import { FundOverlap } from './pages/FundOverlap';
import { StockExposure } from './pages/StockExposure';
import { SectorAnalysis } from './pages/SectorAnalysis';
import { Simulator } from './pages/Simulator';
import { HoldingsData } from './pages/HoldingsData';
import { Methodology } from './pages/Methodology';
import { Menu, X } from 'lucide-react';

export function App() {
  // Navigation State
  const [currentScreen, setCurrentScreen] = useState<NavScreenId>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Live Indian Mutual Funds Data & Portfolio State
  const [allHoldings, setAllHoldings] = useState<Holding[]>(LIVE_INDIAN_HOLDINGS);
  const [availableFunds, setAvailableFunds] = useState<FundMeta[]>(LIVE_INDIAN_FUNDS);
  const [portfolio, setPortfolio] = useState<PortfolioFundItem[]>(LIVE_INDIAN_DEFAULT_PORTFOLIO);
  const [portfolioMode, setPortfolioMode] = useState<PortfolioMode>('allocation');
  const [isCustomUpload, setIsCustomUpload] = useState<boolean>(false);

  // Drilldown / Navigation Context States
  const [selectedStockForModal, setSelectedStockForModal] = useState<EffectiveStockExposure | null>(null);
  const [overlapPair, setOverlapPair] = useState<{ fundA?: string; fundB?: string }>({});
  const [stockFilter, setStockFilter] = useState<string>('');

  // Deterministic Analytics Calculation
  const analytics = useMemo(() => {
    return calculatePortfolioAnalytics(portfolio, allHoldings, portfolioMode);
  }, [portfolio, allHoldings, portfolioMode]);

  // Rule-Based Portfolio Observations
  const insights = useMemo(() => {
    return generatePortfolioInsights(analytics, portfolio, allHoldings);
  }, [analytics, portfolio, allHoldings]);

  // Navigation title mapping
  const screenTitles: Record<NavScreenId, string> = {
    overview: 'Portfolio Overview',
    portfolio: 'My Portfolio',
    'fund-overlap': 'Fund Overlap Analysis',
    'stock-exposure': 'Underlying Stock Exposure',
    'sector-analysis': 'Sector & Market-Cap Analysis',
    'what-if': 'What-If Simulator',
    'data-management': 'Holdings & Data Management',
    methodology: 'Methodology & Calculations',
  };

  // Explicit Normalization Action (User requested)
  const handleNormalizeWeights = () => {
    const rawWeights = portfolio.map((p) => p.targetWeight ?? p.normalizedWeight);
    const normalized = normalizeWeights(rawWeights);
    const updated = portfolio.map((item, i) => ({
      ...item,
      targetWeight: normalized[i],
      normalizedWeight: normalized[i],
    }));
    setPortfolio(updated);
  };

  // Reset to Live Indian Mutual Funds Benchmark
  const handleResetToLiveIndianData = () => {
    setAllHoldings(LIVE_INDIAN_HOLDINGS);
    setAvailableFunds(LIVE_INDIAN_FUNDS);
    setPortfolio(LIVE_INDIAN_DEFAULT_PORTFOLIO);
    setPortfolioMode('allocation');
    setIsCustomUpload(false);
    setStockFilter('');
  };

  // Import User CSV Disclosures
  const handleImportValidHoldings = (newHoldings: Holding[], newFunds: FundMeta[]) => {
    setAllHoldings(newHoldings);
    setAvailableFunds(newFunds);
    setIsCustomUpload(true);

    const newFundNames = newFunds.map((f) => f.fundName);
    const validPortfolio = portfolio.filter((p) => newFundNames.includes(p.fundName));

    if (validPortfolio.length > 0) {
      setPortfolio(validPortfolio);
    } else {
      const initialSelection = newFunds.slice(0, 3).map((f, i, arr) => ({
        id: `imp-${i}`,
        fundName: f.fundName,
        targetWeight: 1 / arr.length,
        normalizedWeight: 1 / arr.length,
      }));
      setPortfolio(initialSelection);
    }
    setCurrentScreen('overview');
  };

  const handleAddFundMeta = (newFund: FundMeta) => {
    setAvailableFunds((prev) => {
      if (prev.some((f) => f.fundName === newFund.fundName)) return prev;
      return [newFund, ...prev];
    });
  };

  // Cross-screen navigation helper
  const handleNavigate = (screen: string, filter?: string) => {
    if (filter) {
      setStockFilter(filter);
    }
    setCurrentScreen(screen as NavScreenId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectPair = (fundA: string, fundB: string) => {
    setOverlapPair({ fundA, fundB });
    setCurrentScreen('fund-overlap');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const activeDataSourceMode: DataSourceMode = isCustomUpload ? 'uploaded' : 'live';

  return (
    <div className="min-h-screen bg-[#F6F8FA] flex flex-col antialiased">
      {/* Top Banner */}
      <DataBanner
        dataSourceMode={activeDataSourceMode}
        onNavigateToUpload={() => setCurrentScreen('data-management')}
        onSwitchToLiveIndianData={handleResetToLiveIndianData}
        onResetPortfolio={handleResetToLiveIndianData}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Sidebar */}
        <div className="hidden lg:block shrink-0">
          <Sidebar
            currentScreen={currentScreen}
            onSelectScreen={(s) => setCurrentScreen(s)}
            fundsCount={portfolio.length}
            uniqueStocksCount={analytics.uniqueStocksCount}
          />
        </div>

        {/* Mobile Sidebar Overlay */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            <div
              className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs"
              onClick={() => setMobileMenuOpen(false)}
            />
            <div className="relative z-10 w-64 bg-white flex flex-col h-full shadow-2xl">
              <div className="p-4 border-b border-border flex items-center justify-between">
                <span className="font-bold text-sm text-text-main">Navigation</span>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 rounded-lg text-text-sub hover:text-text-main"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto">
                <Sidebar
                  currentScreen={currentScreen}
                  onSelectScreen={(s) => {
                    setCurrentScreen(s);
                    setMobileMenuOpen(false);
                  }}
                  fundsCount={portfolio.length}
                  uniqueStocksCount={analytics.uniqueStocksCount}
                />
              </div>
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
          {/* Top Header */}
          <div className="flex items-center lg:block">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-3 text-text-sub hover:text-text-main"
              aria-label="Open menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex-1">
              <Header
                currentTabName={screenTitles[currentScreen]}
                dataSourceMode={activeDataSourceMode}
                reportingDate={availableFunds[0]?.reportingDate}
                onNavigateToUpload={() => setCurrentScreen('data-management')}
                onResetPortfolio={handleResetToLiveIndianData}
                onSwitchToLiveIndianData={handleResetToLiveIndianData}
                completenessScore={analytics.dataCompletenessScore}
              />
            </div>
          </div>

          {/* Active Screen Container */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
            {currentScreen === 'overview' && (
              <Overview
                analytics={analytics}
                portfolio={portfolio}
                allHoldings={allHoldings}
                insights={insights}
                onNavigate={handleNavigate}
                onStockClick={(stock) => setSelectedStockForModal(stock)}
                onSelectPair={handleSelectPair}
              />
            )}

            {currentScreen === 'portfolio' && (
              <Portfolio
                portfolio={portfolio}
                availableFunds={availableFunds}
                mode={portfolioMode}
                onUpdatePortfolio={(newP, newMode) => {
                  setPortfolio(newP);
                  setPortfolioMode(newMode);
                }}
                onNormalizeWeights={handleNormalizeWeights}
                onAddFundMeta={handleAddFundMeta}
              />
            )}

            {currentScreen === 'fund-overlap' && (
              <FundOverlap
                portfolio={portfolio}
                allHoldings={allHoldings}
                initialFundA={overlapPair.fundA}
                initialFundB={overlapPair.fundB}
              />
            )}

            {currentScreen === 'stock-exposure' && (
              <StockExposure
                analytics={analytics}
                portfolio={portfolio}
                initialFilter={stockFilter}
              />
            )}

            {currentScreen === 'sector-analysis' && (
              <SectorAnalysis
                analytics={analytics}
                onNavigateToStock={(sec) => handleNavigate('stock-exposure', sec)}
              />
            )}

            {currentScreen === 'what-if' && (
              <Simulator
                portfolio={portfolio}
                availableFunds={availableFunds}
                allHoldings={allHoldings}
                mode={portfolioMode}
              />
            )}

            {currentScreen === 'data-management' && (
              <HoldingsData
                currentHoldings={allHoldings}
                availableFunds={availableFunds}
                isCustomUpload={isCustomUpload}
                onImportValidHoldings={handleImportValidHoldings}
                onResetToLiveIndianData={handleResetToLiveIndianData}
                onAddFundMeta={handleAddFundMeta}
              />
            )}

            {currentScreen === 'methodology' && <Methodology />}
          </main>
        </div>
      </div>
    </div>
  );
}

export default App;
