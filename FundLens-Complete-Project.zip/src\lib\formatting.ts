// Formatting utilities for FundLens (Indian Rupee, Percentages, Dates)

/**
 * Formats a decimal number as a percentage string (e.g. 0.068 -> "6.80%")
 */
export function formatPercent(value: number | undefined | null, decimals: number = 2): string {
  if (value === undefined || value === null || isNaN(value)) {
    return '0.00%';
  }
  return (value * 100).toFixed(decimals) + '%';
}

/**
 * Formats a raw number as an Indian Rupee amount (e.g. 150000 -> "₹1,50,000")
 */
export function formatINR(value: number | undefined | null): string {
  if (value === undefined || value === null || isNaN(value)) {
    return '—';
  }
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(value);
}

/**
 * Compact Indian number formatting (e.g. 1500000 -> "₹15.0 L", 25000000 -> "₹2.50 Cr")
 */
export function formatCompactINR(value: number | undefined | null): string {
  if (value === undefined || value === null || isNaN(value)) {
    return '—';
  }
  if (value >= 10000000) {
    return `₹${(value / 10000000).toFixed(2)} Cr`;
  }
  if (value >= 100000) {
    return `₹${(value / 100000).toFixed(2)} L`;
  }
  return formatINR(value);
}

/**
 * Formats date string (YYYY-MM-DD) into readable text (e.g. "30 Sep 2026")
 */
export function formatDate(dateStr: string | undefined | null): string {
  if (!dateStr || dateStr === 'N/A') return 'Undisclosed';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return dateStr;
  }
}
