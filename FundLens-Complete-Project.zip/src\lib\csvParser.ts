// PapaParse CSV Integration with Intelligent Header Mapping and Template Generation
// Adheres strictly to Section 5 (Screen 7) of Master Build Prompt

import Papa from 'papaparse';
import { RawParsedRow, validateHoldingsRows } from './validation';
import { CSVValidationResult } from '../types';

export interface ColumnMapping {
  fundName: string;
  schemeCode: string;
  securityName: string;
  isin: string;
  weight: string;
  sector: string;
  marketCap: string;
  reportingDate: string;
  instrumentType: string;
}

const ALIASES: Record<keyof ColumnMapping, string[]> = {
  fundName: ['fund name', 'fund', 'scheme', 'scheme name', 'fund_name', 'schemename', 'amc scheme'],
  schemeCode: ['scheme code', 'schemecode', 'code', 'scheme_code', 'amfi code'],
  securityName: ['security name', 'security', 'stock', 'stock name', 'company', 'company name', 'holding', 'scrip name'],
  isin: ['isin', 'isin code', 'isin_code', 'isincode'],
  weight: ['weight %', 'weight', 'weightage', 'weightage %', 'portfolio weight', 'holding weight', 'allocation', 'percent'],
  sector: ['sector', 'industry', 'sector name', 'industry name'],
  marketCap: ['market cap', 'marketcap', 'market_cap', 'cap category', 'mcap', 'cap'],
  reportingDate: ['reporting date', 'date', 'as of date', 'as of', 'disclosure date', 'portfolio date', 'rep_date'],
  instrumentType: ['instrument type', 'instrument', 'asset class', 'type', 'instrument_type'],
};

/**
 * Automatically infers column mappings from extracted header names.
 */
export function autoDetectColumnMapping(headers: string[]): ColumnMapping {
  const mapping: ColumnMapping = {
    fundName: '',
    schemeCode: '',
    securityName: '',
    isin: '',
    weight: '',
    sector: '',
    marketCap: '',
    reportingDate: '',
    instrumentType: '',
  };

  const normalizedHeaders = headers.map((h) => ({
    raw: h,
    clean: h.toLowerCase().replace(/[^a-z0-9]/g, ' ').trim(),
  }));

  for (const [key, aliasList] of Object.entries(ALIASES) as [keyof ColumnMapping, string[]][]) {
    // 1. Exact match with alias
    const exact = normalizedHeaders.find((h) => aliasList.includes(h.clean));
    if (exact) {
      mapping[key] = exact.raw;
      continue;
    }
    // 2. Partial match
    const partial = normalizedHeaders.find((h) =>
      aliasList.some((alias) => h.clean.includes(alias) || alias.includes(h.clean))
    );
    if (partial) {
      mapping[key] = partial.raw;
    }
  }

  return mapping;
}

/**
 * Parses raw CSV content with PapaParse and auto-detected or provided column mapping.
 */
export function parseHoldingsCSV(
  csvText: string,
  customMapping?: Partial<ColumnMapping>
): {
  headers: string[];
  inferredMapping: ColumnMapping;
  validationResult: CSVValidationResult;
  previewRows: Record<string, any>[];
} {
  const parsed = Papa.parse<Record<string, any>>(csvText, {
    header: true,
    skipEmptyLines: 'greedy',
    dynamicTyping: false,
  });

  const headers = parsed.meta.fields || [];
  const defaultMapping = autoDetectColumnMapping(headers);
  const activeMapping: ColumnMapping = {
    ...defaultMapping,
    ...(customMapping || {}),
  };

  const rawRows: RawParsedRow[] = parsed.data.map((row) => ({
    fundName: activeMapping.fundName ? row[activeMapping.fundName] : undefined,
    schemeCode: activeMapping.schemeCode ? row[activeMapping.schemeCode] : undefined,
    securityName: activeMapping.securityName ? row[activeMapping.securityName] : undefined,
    isin: activeMapping.isin ? row[activeMapping.isin] : undefined,
    weight: activeMapping.weight ? row[activeMapping.weight] : undefined,
    sector: activeMapping.sector ? row[activeMapping.sector] : undefined,
    marketCap: activeMapping.marketCap ? row[activeMapping.marketCap] : undefined,
    reportingDate: activeMapping.reportingDate ? row[activeMapping.reportingDate] : undefined,
    instrumentType: activeMapping.instrumentType ? row[activeMapping.instrumentType] : undefined,
  }));

  const validationResult = validateHoldingsRows(rawRows);

  return {
    headers,
    inferredMapping: activeMapping,
    validationResult,
    previewRows: parsed.data.slice(0, 5),
  };
}

/**
 * Generates an institutional-grade CSV template string for Indian mutual fund disclosures.
 */
export function generateCSVTemplate(): string {
  const headers = [
    'Fund Name',
    'Scheme Code',
    'Security Name',
    'ISIN',
    'Weight %',
    'Sector',
    'Market Cap',
    'Reporting Date',
    'Instrument Type',
  ];

  const templateRows = [
    ['Parag Parikh Flexi Cap Fund', '122640', 'HDFC Bank Ltd.', 'INE040A01034', '8.12', 'Financial Services', 'Large-Cap', '2026-09-30', 'Equity'],
    ['Parag Parikh Flexi Cap Fund', '122640', 'Bajaj Holdings & Investment Ltd.', 'INE118A01012', '6.95', 'Financial Services', 'Large-Cap', '2026-09-30', 'Equity'],
    ['Parag Parikh Flexi Cap Fund', '122640', 'ITC Ltd.', 'INE154A01025', '6.84', 'Consumer Defensive', 'Large-Cap', '2026-09-30', 'Equity'],
    ['Mirae Asset Large & Midcap Fund', '118834', 'HDFC Bank Ltd.', 'INE040A01034', '6.85', 'Financial Services', 'Large-Cap', '2026-09-30', 'Equity'],
    ['Mirae Asset Large & Midcap Fund', '118834', 'ICICI Bank Ltd.', 'INE090A01021', '6.20', 'Financial Services', 'Large-Cap', '2026-09-30', 'Equity'],
    ['Mirae Asset Large & Midcap Fund', '118834', 'Reliance Industries Ltd.', 'INE002A01018', '5.10', 'Energy', 'Large-Cap', '2026-09-30', 'Equity'],
  ];

  const lines = [headers.join(',')];
  for (const r of templateRows) {
    lines.push(r.map((val) => `"${val}"`).join(','));
  }
  return lines.join('\n');
}



