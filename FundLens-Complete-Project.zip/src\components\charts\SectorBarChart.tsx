// Horizontal Sector Exposure Bar Chart using Recharts

import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from 'recharts';
import { SectorExposure } from '../../types';
import { formatPercent } from '../../lib/formatting';

interface SectorBarChartProps {
  sectors: SectorExposure[];
  maxDisplay?: number;
  useClassifiedOnly?: boolean;
}

export const SectorBarChart: React.FC<SectorBarChartProps> = ({
  sectors,
  maxDisplay = 8,
  useClassifiedOnly = false,
}) => {
  const displaySectors = sectors.slice(0, maxDisplay);

  const chartData = displaySectors.map((s) => ({
    name: s.sector,
    value: useClassifiedOnly ? s.effectiveWeightClassified : s.effectiveWeight,
    rawWeight: s.effectiveWeight,
    stockCount: s.stockCount,
    topStock: s.topStockName,
  }));

  if (chartData.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-xs text-text-sub">
        No sector exposures available
      </div>
    );
  }

  return (
    <div className="w-full h-72">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          layout="vertical"
          data={chartData}
          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
        >
          <XAxis
            type="number"
            domain={[0, 'dataMax + 0.05']}
            tickFormatter={(val) => `${(val * 100).toFixed(0)}%`}
            tick={{ fontSize: 11, fill: '#667085' }}
            axisLine={{ stroke: '#E4E7EC' }}
            tickLine={false}
          />
          <YAxis
            type="category"
            dataKey="name"
            width={130}
            tick={{ fontSize: 11, fill: '#172B4D' }}
            axisLine={{ stroke: '#E4E7EC' }}
            tickLine={false}
          />
          <Tooltip
            formatter={(value: any, _: any, entry: any) => [
              `${formatPercent(Number(value))} (${entry.payload.stockCount} companies)`,
              'Exposure',
            ]}
            labelFormatter={(label) => `Sector: ${label}`}
            contentStyle={{
              backgroundColor: '#FFFFFF',
              borderColor: '#E4E7EC',
              borderRadius: '8px',
              fontSize: '12px',
            }}
          />
          <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={16}>
            {chartData.map((entry) => (
              <Cell
                key={`bar-${entry.name}`}
                fill={entry.name === 'Unclassified' ? '#94A3B8' : '#147D64'}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
