import React, { useState } from 'react';
import {
  PortfolioFundItem,
  FundMeta,
  PortfolioMode,
} from '../types';
import {
  Plus,
  Trash2,
  Percent,
  IndianRupee,
  AlertTriangle,
  Scale,
  Calendar,
  Layers,
  Search,
  Globe,
} from 'lucide-react';
import { formatPercent, formatINR, formatDate } from '../lib/formatting';
import { MFSchemeExplorerModal } from '../components/common/MFSchemeExplorerModal';

interface PortfolioProps {
  portfolio: PortfolioFundItem[];
  availableFunds: FundMeta[];
  mode: PortfolioMode;
  onUpdatePortfolio: (newPortfolio: PortfolioFundItem[], newMode: PortfolioMode) => void;
  onNormalizeWeights: () => void;
  onAddFundMeta?: (fund: FundMeta) => void;
}

export const Portfolio: React.FC<PortfolioProps> = ({
  portfolio,
  availableFunds,
  mode,
  onUpdatePortfolio,
  onNormalizeWeights,
  onAddFundMeta,
}) => {
  const [isMfapiModalOpen, setIsMfapiModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFundToAdd, setSelectedFundToAdd] = useState('');
  const [newFundAmount, setNewFundAmount] = useState<number>(100000);
  const [newFundWeight, setNewFundWeight] = useState<number>(20);

  const handleSelectSchemeFromMfapi = (scheme: { fundName: string; schemeCode: string; category: string }) => {
    // Register fund in available metadata if onAddFundMeta provided
    if (onAddFundMeta) {
      onAddFundMeta({
        fundName: scheme.fundName,
        schemeCode: scheme.schemeCode,
        category: scheme.category,
        reportingDate: new Date().toISOString().slice(0, 10),
        reportedWeightTotal: 1.0,
        isNormalized: true,
        holdingsCount: 0,
        completenessScore: 100,
        dataQualityIssues: [],
      });
    }

    // Add directly to portfolio
    const newItemId = `p-${Date.now()}`;
    const defaultWeight = 0.20;
    const defaultAmt = 100000;

    let updated: PortfolioFundItem[];
    if (mode === 'valuation') {
      const newItem: PortfolioFundItem = {
        id: newItemId,
        fundName: scheme.fundName,
        amount: defaultAmt,
        normalizedWeight: 0,
      };
      const candidateList = [...portfolio, newItem];
      const newTotal = candidateList.reduce((sum, item) => sum + (item.amount || 0), 0);
      updated = candidateList.map((item) => ({
        ...item,
        normalizedWeight: newTotal > 0 ? (item.amount || 0) / newTotal : 0,
      }));
    } else {
      const newItem: PortfolioFundItem = {
        id: newItemId,
        fundName: scheme.fundName,
        targetWeight: defaultWeight,
        normalizedWeight: defaultWeight,
      };
      updated = [...portfolio, newItem];
    }

    onUpdatePortfolio(updated, mode);
  };

  // Filter available funds not yet in portfolio
  const existingFundNames = new Set(portfolio.map((p) => p.fundName));
  const candidateFunds = availableFunds.filter(
    (f) =>
      !existingFundNames.has(f.fundName) &&
      (f.fundName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (f.schemeCode && f.schemeCode.includes(searchTerm)) ||
        f.category.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Sum calculations
  const totalAmount = portfolio.reduce((sum, item) => sum + (item.amount || 0), 0);
  const rawTargetWeightSum = portfolio.reduce((sum, item) => sum + (item.targetWeight || 0), 0);
  const normalizedSum = portfolio.reduce((sum, item) => sum + item.normalizedWeight, 0);

  // Tolerance check on 100% target weights
  const isTargetWeight100 = Math.abs(rawTargetWeightSum - 1.0) < 0.0001;

  // Handler: Change Mode (valuation vs allocation)
  const handleModeChange = (newMode: PortfolioMode) => {
    if (newMode === 'valuation') {
      // populate default amounts if empty
      const updated = portfolio.map((item) => ({
        ...item,
        amount: item.amount || Math.round(item.normalizedWeight * 1000000),
      }));
      onUpdatePortfolio(updated, newMode);
    } else {
      // populate target weights from current normalized
      const updated = portfolio.map((item) => ({
        ...item,
        targetWeight: item.targetWeight ?? item.normalizedWeight,
      }));
      onUpdatePortfolio(updated, newMode);
    }
  };

  // Handler: Update individual fund value
  const handleItemValueChange = (id: string, value: number) => {
    if (mode === 'valuation') {
      const updated = portfolio.map((item) =>
        item.id === id ? { ...item, amount: Math.max(0, value) } : item
      );
      // Recalculate normalized weights from amounts
      const newTotal = updated.reduce((sum, item) => sum + (item.amount || 0), 0);
      const normalized = updated.map((item) => ({
        ...item,
        normalizedWeight: newTotal > 0 ? (item.amount || 0) / newTotal : 0,
      }));
      onUpdatePortfolio(normalized, mode);
    } else {
      // Update target weight decimal
      const decimalVal = Math.max(0, value / 100);
      const updated = portfolio.map((item) =>
        item.id === id ? { ...item, targetWeight: decimalVal } : item
      );
      // Do not silently normalize! Maintain explicit raw target weights
      onUpdatePortfolio(updated, mode);
    }
  };

  // Handler: Remove fund
  const handleRemoveFund = (id: string) => {
    const updated = portfolio.filter((item) => item.id !== id);
    if (updated.length === 0) {
      onUpdatePortfolio([], mode);
      return;
    }

    if (mode === 'valuation') {
      const newTotal = updated.reduce((sum, item) => sum + (item.amount || 0), 0);
      const normalized = updated.map((item) => ({
        ...item,
        normalizedWeight: newTotal > 0 ? (item.amount || 0) / newTotal : 0,
      }));
      onUpdatePortfolio(normalized, mode);
    } else {
      onUpdatePortfolio(updated, mode);
    }
  };

  // Handler: Add Fund
  const handleAddFund = () => {
    if (!selectedFundToAdd) return;

    const fundDef = availableFunds.find((f) => f.fundName === selectedFundToAdd);
    if (!fundDef) return;

    const newItemId = `p-${Date.now()}`;
    let updated: PortfolioFundItem[];

    if (mode === 'valuation') {
      const newItem: PortfolioFundItem = {
        id: newItemId,
        fundName: fundDef.fundName,
        amount: newFundAmount,
        normalizedWeight: 0,
      };
      const candidateList = [...portfolio, newItem];
      const newTotal = candidateList.reduce((sum, item) => sum + (item.amount || 0), 0);
      updated = candidateList.map((item) => ({
        ...item,
        normalizedWeight: newTotal > 0 ? (item.amount || 0) / newTotal : 0,
      }));
    } else {
      const newItem: PortfolioFundItem = {
        id: newItemId,
        fundName: fundDef.fundName,
        targetWeight: newFundWeight / 100,
        normalizedWeight: newFundWeight / 100,
      };
      updated = [...portfolio, newItem];
    }

    onUpdatePortfolio(updated, mode);
    setSelectedFundToAdd('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header controls & Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-border shadow-xs">
        <div>
          <h2 className="text-xl font-bold text-text-main tracking-tight">My Portfolio Schemes</h2>
          <p className="text-xs text-text-sub mt-0.5">
            Configure mutual funds and portfolio weights. Financial metrics dynamically recalculate.
          </p>
        </div>

        {/* Right Action Controls: MFAPI live search & Mode Toggle */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsMfapiModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 hover:border-emerald-300 transition-all shadow-2xs"
            title="Search all 40,000+ Indian mutual fund schemes live via MFAPI.in"
          >
            <Globe className="w-3.5 h-3.5 text-primary" />
            <span>Search Indian Funds (Live MFAPI)</span>
          </button>

          {/* Mode Toggle */}
          <div className="flex items-center gap-1 bg-[#F6F8FA] p-1 rounded-xl border border-border shrink-0">
            <button
              onClick={() => handleModeChange('allocation')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                mode === 'allocation'
                  ? 'bg-white text-primary shadow-xs border border-border'
                  : 'text-text-sub hover:text-text-main'
              }`}
            >
              <Percent className="w-3.5 h-3.5" />
              <span>Target Weights (%)</span>
            </button>
            <button
              onClick={() => handleModeChange('valuation')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                mode === 'valuation'
                  ? 'bg-white text-primary shadow-xs border border-border'
                  : 'text-text-sub hover:text-text-main'
              }`}
            >
              <IndianRupee className="w-3.5 h-3.5" />
              <span>Investment Amount (₹)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Allocation Validation Alert (When in Allocation mode and != 100%) */}
      {mode === 'allocation' && !isTargetWeight100 && (
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-amber-900">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
            <div>
              <span className="font-bold">Allocations do not equal 100.0%: </span>
              <span>
                Current target total is {(rawTargetWeightSum * 100).toFixed(2)}%.
                You can adjust numbers manually or explicitly normalize to scale weights proportionally.
              </span>
            </div>
          </div>
          <button
            onClick={onNormalizeWeights}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-semibold text-xs shrink-0 shadow-xs transition-colors"
          >
            <Scale className="w-3.5 h-3.5" />
            <span>Normalize to 100%</span>
          </button>
        </div>
      )}

      {/* Portfolio Funds Table */}
      <div className="bg-white rounded-2xl border border-border overflow-hidden shadow-xs">
        <div className="p-4 border-b border-border flex items-center justify-between bg-[#F8F9FA]">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-primary" />
            <h3 className="text-xs font-bold text-text-main uppercase tracking-wider">
              Included Funds ({portfolio.length})
            </h3>
          </div>
          <div className="text-xs text-text-sub font-medium">
            {mode === 'valuation' ? (
              <span>Total Invested: <strong className="text-text-main">{formatINR(totalAmount)}</strong></span>
            ) : (
              <span>
                Reported Total:{' '}
                <strong className={isTargetWeight100 ? 'text-emerald-700' : 'text-amber-700'}>
                  {(rawTargetWeightSum * 100).toFixed(2)}%
                </strong>
              </span>
            )}
          </div>
        </div>

        {portfolio.length === 0 ? (
          <div className="p-12 text-center text-xs text-text-sub">
            Your portfolio is currently empty. Use the selector below to add mutual fund schemes.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-[#F8F9FA]/60 text-text-sub border-b border-border">
                <tr>
                  <th className="p-3.5 font-semibold">Mutual Fund Scheme</th>
                  <th className="p-3.5 font-semibold">Category</th>
                  <th className="p-3.5 font-semibold">Disclosure Date</th>
                  <th className="p-3.5 font-semibold text-right">
                    {mode === 'valuation' ? 'Amount Invested' : 'Target Weight'}
                  </th>
                  <th className="p-3.5 font-semibold text-right">Effective Weight</th>
                  <th className="p-3.5 font-semibold text-center">Quality</th>
                  <th className="p-3.5 font-semibold text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {portfolio.map((item) => {
                  const meta = availableFunds.find((f) => f.fundName === item.fundName);
                  return (
                    <tr key={item.id} className="hover:bg-slate-50/50">
                      <td className="p-3.5 font-semibold text-text-main max-w-xs">
                        <div className="truncate" title={item.fundName}>{item.fundName}</div>
                        {meta?.schemeCode && (
                          <span className="text-[10px] font-mono text-text-sub">
                            AMFI: {meta.schemeCode}
                          </span>
                        )}
                      </td>
                      <td className="p-3.5 text-text-sub">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 border border-slate-200">
                          {meta?.category || 'Equity Scheme'}
                        </span>
                      </td>
                      <td className="p-3.5 text-text-sub">
                        <div className="flex items-center gap-1.5 text-[11px]">
                          <Calendar className="w-3.5 h-3.5 text-text-sub" />
                          <span>{formatDate(meta?.reportingDate)}</span>
                        </div>
                      </td>
                      <td className="p-3.5 text-right">
                        {mode === 'valuation' ? (
                          <div className="flex items-center justify-end gap-1">
                            <span className="text-text-sub font-mono">₹</span>
                            <input
                              type="number"
                              min="0"
                              step="10000"
                              value={item.amount || ''}
                              onChange={(e) =>
                                handleItemValueChange(item.id, parseFloat(e.target.value) || 0)
                              }
                              className="w-28 text-right p-1.5 rounded-lg border border-border text-xs font-semibold tabular-nums text-text-main focus:outline-hidden focus:border-primary"
                            />
                          </div>
                        ) : (
                          <div className="flex items-center justify-end gap-1">
                            <input
                              type="number"
                              min="0"
                              max="100"
                              step="1"
                              value={
                                item.targetWeight !== undefined
                                  ? Math.round(item.targetWeight * 100)
                                  : Math.round(item.normalizedWeight * 100)
                              }
                              onChange={(e) =>
                                handleItemValueChange(item.id, parseFloat(e.target.value) || 0)
                              }
                              className="w-16 text-right p-1.5 rounded-lg border border-border text-xs font-semibold tabular-nums text-text-main focus:outline-hidden focus:border-primary"
                            />
                            <span className="text-text-sub">%</span>
                          </div>
                        )}
                      </td>
                      <td className="p-3.5 text-right font-bold text-primary tabular-nums">
                        {formatPercent(item.normalizedWeight)}
                      </td>
                      <td className="p-3.5 text-center">
                        <span
                          className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                            (meta?.completenessScore || 90) >= 95
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : 'bg-amber-50 text-amber-800 border-amber-200'
                          }`}
                        >
                          {meta?.completenessScore || 95}%
                        </span>
                      </td>
                      <td className="p-3.5 text-center">
                        <button
                          onClick={() => handleRemoveFund(item.id)}
                          className="p-1.5 text-text-sub hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors"
                          title={`Remove ${item.fundName}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add New Fund Box */}
      <div className="bg-white rounded-2xl border border-border p-5 shadow-xs">
        <h3 className="text-xs font-bold text-text-main uppercase tracking-wider mb-3">
          Add Mutual Fund Scheme to Portfolio
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
          {/* Fund Selector */}
          <div className="md:col-span-6 space-y-1">
            <label className="text-[11px] font-semibold text-text-sub">Select Scheme</label>
            <select
              value={selectedFundToAdd}
              onChange={(e) => setSelectedFundToAdd(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-border text-xs text-text-main bg-white focus:outline-hidden focus:border-primary"
            >
              <option value="">-- Choose a fund from holdings dataset --</option>
              {candidateFunds.map((f) => (
                <option key={f.fundName} value={f.fundName}>
                  {f.fundName} ({f.category})
                </option>
              ))}
            </select>
          </div>

          {/* Allocation input */}
          <div className="md:col-span-4 space-y-1">
            <label className="text-[11px] font-semibold text-text-sub">
              {mode === 'valuation' ? 'Investment Amount (₹)' : 'Target Weight (%)'}
            </label>
            {mode === 'valuation' ? (
              <input
                type="number"
                min="1000"
                step="10000"
                value={newFundAmount}
                onChange={(e) => setNewFundAmount(parseFloat(e.target.value) || 0)}
                className="w-full p-2.5 rounded-xl border border-border text-xs text-text-main tabular-nums focus:outline-hidden focus:border-primary"
              />
            ) : (
              <input
                type="number"
                min="1"
                max="100"
                step="1"
                value={newFundWeight}
                onChange={(e) => setNewFundWeight(parseFloat(e.target.value) || 0)}
                className="w-full p-2.5 rounded-xl border border-border text-xs text-text-main tabular-nums focus:outline-hidden focus:border-primary"
              />
            )}
          </div>

          {/* Add Button */}
          <div className="md:col-span-2">
            <button
              onClick={handleAddFund}
              disabled={!selectedFundToAdd}
              className="w-full py-2.5 bg-primary hover:bg-primary-hover disabled:bg-slate-200 disabled:text-slate-400 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add Scheme</span>
            </button>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-border flex items-center justify-between text-xs text-text-sub flex-wrap gap-2">
          <span>Looking for an Indian mutual fund scheme not listed above?</span>
          <button
            onClick={() => setIsMfapiModalOpen(true)}
            className="text-primary font-semibold hover:underline inline-flex items-center gap-1"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Search live across all 40,000+ Indian Mutual Funds on MFAPI</span>
          </button>
        </div>
      </div>

      {/* Live Indian Mutual Funds Explorer Modal */}
      <MFSchemeExplorerModal
        isOpen={isMfapiModalOpen}
        onClose={() => setIsMfapiModalOpen(false)}
        onAddSchemeToPortfolio={handleSelectSchemeFromMfapi}
      />
    </div>
  );
};
