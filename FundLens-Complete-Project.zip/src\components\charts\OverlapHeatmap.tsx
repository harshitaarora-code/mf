// Interactive Pairwise Fund Overlap Heatmap Matrix

import React from 'react';
import { Holding, PortfolioFundItem } from '../../types';
import { calculatePairwiseOverlap, calculateSelfOverlap } from '../../lib/analytics';
import { formatPercent } from '../../lib/formatting';

interface OverlapHeatmapProps {
  portfolio: PortfolioFundItem[];
  allHoldings: Holding[];
  onSelectPair?: (fundA: string, fundB: string) => void;
}

export const OverlapHeatmap: React.FC<OverlapHeatmapProps> = ({
  portfolio,
  allHoldings,
  onSelectPair,
}) => {
  if (portfolio.length === 0) {
    return (
      <div className="h-48 flex items-center justify-center text-xs text-text-sub">
        Add at least one fund to view the overlap matrix
      </div>
    );
  }

  // Calculate matrix of overlaps
  const matrix: { fundA: string; fundB: string; overlap: number; isSelf: boolean }[][] = [];

  for (let i = 0; i < portfolio.length; i++) {
    const row: { fundA: string; fundB: string; overlap: number; isSelf: boolean }[] = [];
    const fundA = portfolio[i].fundName;

    for (let j = 0; j < portfolio.length; j++) {
      const fundB = portfolio[j].fundName;
      if (i === j) {
        const selfOverlap = calculateSelfOverlap(fundA, allHoldings);
        row.push({ fundA, fundB, overlap: selfOverlap, isSelf: true });
      } else {
        const pair = calculatePairwiseOverlap(fundA, fundB, allHoldings);
        row.push({ fundA, fundB, overlap: pair.overlapWeight, isSelf: false });
      }
    }
    matrix.push(row);
  }

  const getCellBg = (overlap: number, isSelf: boolean) => {
    if (isSelf) return 'bg-slate-100/80 text-slate-700 font-semibold border-slate-200';
    if (overlap >= 0.45) return 'bg-rose-100 text-rose-900 border-rose-200 font-bold';
    if (overlap >= 0.35) return 'bg-amber-100 text-amber-900 border-amber-200 font-semibold';
    if (overlap >= 0.20) return 'bg-emerald-50 text-emerald-900 border-emerald-100 font-medium';
    return 'bg-slate-50 text-slate-600 border-slate-100';
  };

  return (
    <div className="w-full overflow-x-auto">
      <table className="w-full text-xs border-collapse">
        <thead>
          <tr>
            <th className="p-2 text-left font-semibold text-text-sub text-[11px] uppercase tracking-wider border-b border-border min-w-[140px]">
              Scheme
            </th>
            {portfolio.map((item, idx) => (
              <th
                key={`th-${item.id}`}
                className="p-2 text-center font-semibold text-text-sub text-[11px] uppercase tracking-wider border-b border-border min-w-[90px]"
                title={item.fundName}
              >
                F{idx + 1}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {matrix.map((row, i) => (
            <tr key={`row-${portfolio[i].id}`} className="hover:bg-slate-50/50">
              <td className="p-2 font-medium text-text-main border-b border-border/60 truncate max-w-[160px]" title={portfolio[i].fundName}>
                <span className="text-[10px] font-bold text-text-sub mr-1.5 tabular-nums">
                  F{i + 1}
                </span>
                {portfolio[i].fundName}
              </td>
              {row.map((cell, j) => (
                <td
                  key={`cell-${i}-${j}`}
                  className="p-1.5 border-b border-border/60 text-center"
                >
                  <button
                    type="button"
                    disabled={cell.isSelf}
                    onClick={() => onSelectPair && onSelectPair(cell.fundA, cell.fundB)}
                    className={`w-full py-1.5 px-1 rounded-md text-center tabular-nums text-xs transition-all border ${getCellBg(
                      cell.overlap,
                      cell.isSelf
                    )} ${
                      !cell.isSelf
                        ? 'hover:ring-2 hover:ring-primary/40 cursor-pointer'
                        : 'cursor-default'
                    }`}
                    title={
                      cell.isSelf
                        ? `Self-overlap of ${cell.fundA}: ${formatPercent(cell.overlap)} total valid holdings`
                        : `Click to compare ${cell.fundA} vs ${cell.fundB} (${formatPercent(cell.overlap)} common)`
                    }
                  >
                    {formatPercent(cell.overlap, 1)}
                  </button>
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>

      {/* Heatmap Legend */}
      <div className="mt-3 flex items-center justify-end gap-3 text-[11px] text-text-sub flex-wrap">
        <span className="font-medium text-text-main">Overlap Scale:</span>
        <div className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-slate-50 border border-slate-200"></span>
          <span>&lt; 20%</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-emerald-50 border border-emerald-200"></span>
          <span>20% – 35%</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-amber-100 border border-amber-300"></span>
          <span>35% – 45%</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-rose-100 border border-rose-300"></span>
          <span>&gt; 45% (High)</span>
        </div>
      </div>
    </div>
  );
};
