# FundLens Technical Specification & Architecture

This document outlines the software engineering design, data structures, and validation rules governing FundLens.

---

## 1. Technology Stack

- **Runtime & Build Tooling:** Vite 6 with Node.js LTS v20.18.0
- **UI Framework:** React 18 with TypeScript 5
- **Styling & Design Tokens:** Tailwind CSS v3 with semantic financial design tokens (emerald green `#147D64`, navy `#172B4D`, surface `#F6F8FA`)
- **Data Visualization:** Recharts (responsive SVG rendering)
- **CSV Processing:** PapaParse (RFC-4180 compliant streaming parser)
- **Iconography:** Lucide React
- **Unit Testing Suite:** Vitest v2.1.9

---

## 2. Core Domain Data Models

```typescript
// src/types/index.ts

export type MarketCapCategory = 'Large-Cap' | 'Mid-Cap' | 'Small-Cap' | 'Unclassified';

export interface Holding {
  fundName: string;
  schemeCode?: string;
  securityName: string;
  isin?: string;
  weight: number; // Stored as decimal (e.g. 0.0812 for 8.12%)
  sector: string;
  marketCapCategory: MarketCapCategory;
  reportingDate?: string;
  instrumentType?: string;
}

export interface FundMeta {
  fundName: string;
  schemeCode?: string;
  fundHouse?: string;
  category?: string;
  aumCr?: number;
  ter?: number;
  benchmark?: string;
  reportingDate?: string;
}

export interface EffectiveStockExposure {
  securityName: string;
  isin?: string;
  sector: string;
  marketCapCategory: MarketCapCategory;
  effectiveWeight: number; // Aggregate look-through weight
  holdingFundsCount: number;
  breakdown: Array<{
    fundName: string;
    fundAllocation: number;
    weightInFund: number;
    contributionToPortfolio: number;
  }>;
}

export interface PairwiseOverlapResult {
  fundA: string;
  fundB: string;
  overlapWeight: number; // Sum of min(w_i,A, w_i,B)
  sharedHoldingsCount: number;
  sharedHoldings: Array<{
    securityName: string;
    isin?: string;
    sector: string;
    weightInA: number;
    weightInB: number;
    overlapWeight: number;
  }>;
}
```

---

## 3. Financial Calculation Guarantees

1. **No External Backend Dependency:** Calculations run 100% on the client CPU, guaranteeing sub-millisecond recalculations when moving portfolio weight sliders.
2. **Deterministic Outputs:** Every calculation function is pure and immutable. Given identical inputs, outputs are bit-for-bit identical.
3. **Strict Validation Pipeline:**
   - Detects non-numeric, negative, or infinite weights.
   - Detects and flags duplicate holdings within the same fund disclosure.
   - Flags funds whose weights sum to $< 80\%$ or $> 105\%$.
   - Handles unclassified equity or cash segments gracefully without crashing.
