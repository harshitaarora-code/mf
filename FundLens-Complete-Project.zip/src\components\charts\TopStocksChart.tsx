// Top Underlying Stock Exposures Ranked Horizontal Bar Chart

import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from 'recharts';
import { EffectiveStockExposure } from '../../types';
import { formatPercent } from '../../lib/formatting';

interface TopStocksChartProps {
  stockExposures: EffectiveStockExposure[];
  maxDisplay?: number;
  onStockClick?: (stock: EffectiveStockExposure) => void;
}

export const TopStocksChart: React.FC<TopStocksChartProps> = ({
  stockExposures,
  maxDisplay = 10,
  onStockClick,
}) => {
  const topStocks = stockExposures.slice(0, maxDisplay);

  const chartData = topStocks.map((s) => ({
    name: s.securityName.length > 20 ? s.securityName.slice(0, 18) + '...' : s.securityName,
    fullName: s.securityName,
    value: s.effectiveWeight,
    sector: s.sector,
    fundCount: s.fundCount,
    rawStock: s,
  }));

  if (chartData.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-xs text-text-sub">
        No stock exposures available
      </div>
    );
  }

  return (
    <div className="w-full h-80">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          layout="vertical"
          data={chartData}
          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
        >
          <XAxis
            type="number"
            domain={[0, 'dataMax + 0.02']}
            tickFormatter={(val) => `${(val * 100).toFixed(1)}%`}
            tick={{ fontSize: 11, fill: '#667085' }}
            axisLine={{ stroke: '#E4E7EC' }}
            tickLine={false}
          />
          <YAxis
            type="category"
            dataKey="name"
            width={140}
            tick={{ fontSize: 11, fill: '#172B4D' }}
            axisLine={{ stroke: '#E4E7EC' }}
            tickLine={false}
          />
          <Tooltip
            formatter={(value: any, _: any, entry: any) => [
              `${formatPercent(Number(value))} (${entry.payload.fundCount} funds)`,
              'Effective Exposure',
            ]}
            labelFormatter={(_, payload) => {
              if (payload && payload[0]) {
                return `${payload[0].payload.fullName} (${payload[0].payload.sector})`;
              }
              return '';
            }}
            contentStyle={{
              backgroundColor: '#FFFFFF',
              borderColor: '#E4E7EC',
              borderRadius: '8px',
              fontSize: '12px',
            }}
          />
          <Bar
            dataKey="value"
            radius={[0, 4, 4, 0]}
            barSize={14}
            cursor="pointer"
            onClick={(data) => {
              if (onStockClick && data.rawStock) {
                onStockClick(data.rawStock);
              }
            }}
          >
            {chartData.map((entry, idx) => (
              <Cell
                key={`stock-cell-${idx}`}
                fill={entry.value >= 0.08 ? '#D97706' : '#2563EB'}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
