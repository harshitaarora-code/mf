// FundLens Deterministic Financial Calculation Engine
// Adheres strictly to Section 6 of Master Build Prompt

import {
  Holding,
  PortfolioFundItem,
  PortfolioMode,
  EffectiveStockExposure,
  SectorExposure,
  MarketCapExposure,
  PairwiseOverlap,
  PortfolioAnalyticsResult,
} from '../types';

/**
 * Normalizes an array of numbers so they sum exactly to 1.0.
 * Returns array of zeroes if total sum is 0.
 */
export function normalizeWeights(weights: number[]): number[] {
  const sum = weights.reduce((acc, w) => acc + (isNaN(w) ? 0 : w), 0);
  if (sum <= 0) return weights.map(() => 0);
  return weights.map((w) => (isNaN(w) ? 0 : w / sum));
}

/**
 * Standardizes a security identifier: prefers ISIN, falls back to normalized name.
 */
export function getSecurityIdentifier(h: { isin?: string; securityName: string }): string {
  if (h.isin && h.isin.trim().length > 0) {
    return h.isin.trim().toUpperCase();
  }
  return h.securityName.trim().toLowerCase();
}

/**
 * Calculates pairwise weighted overlap between Fund A and Fund B:
 * O_{A,B} = \sum_i min(w_{i,A}, w_{i,B})
 */
export function calculatePairwiseOverlap(
  fundAName: string,
  fundBName: string,
  allHoldings: Holding[]
): PairwiseOverlap {
  const holdingsA = allHoldings.filter((h) => h.fundName === fundAName && !isNaN(h.weight) && h.weight > 0);
  const holdingsB = allHoldings.filter((h) => h.fundName === fundBName && !isNaN(h.weight) && h.weight > 0);

  // Group by unique security identifier
  const mapA = new Map<string, Holding>();
  for (const h of holdingsA) {
    const key = getSecurityIdentifier(h);
    const existing = mapA.get(key);
    if (existing) {
      mapA.set(key, { ...existing, weight: existing.weight + h.weight });
    } else {
      mapA.set(key, { ...h });
    }
  }

  const mapB = new Map<string, Holding>();
  for (const h of holdingsB) {
    const key = getSecurityIdentifier(h);
    const existing = mapB.get(key);
    if (existing) {
      mapB.set(key, { ...existing, weight: existing.weight + h.weight });
    } else {
      mapB.set(key, { ...h });
    }
  }

  const sharedHoldings: PairwiseOverlap['sharedHoldings'] = [];
  const uniqueToA: PairwiseOverlap['uniqueToA'] = [];
  const uniqueToB: PairwiseOverlap['uniqueToB'] = [];

  let overlapWeight = 0;

  // Process all keys in Fund A
  for (const [key, hA] of mapA.entries()) {
    const hB = mapB.get(key);
    if (hB) {
      const minW = Math.min(hA.weight, hB.weight);
      overlapWeight += minW;
      sharedHoldings.push({
        securityName: hA.securityName || hB.securityName,
        isin: hA.isin || hB.isin || 'N/A',
        sector: hA.sector || hB.sector || 'Unclassified',
        weightInA: hA.weight,
        weightInB: hB.weight,
        overlapContribution: minW,
      });
    } else {
      uniqueToA.push({
        securityName: hA.securityName,
        isin: hA.isin || 'N/A',
        sector: hA.sector || 'Unclassified',
        weight: hA.weight,
      });
    }
  }

  // Process securities unique to Fund B
  for (const [key, hB] of mapB.entries()) {
    if (!mapA.has(key)) {
      uniqueToB.push({
        securityName: hB.securityName,
        isin: hB.isin || 'N/A',
        sector: hB.sector || 'Unclassified',
        weight: hB.weight,
      });
    }
  }

  // Sort shared holdings descending by contribution to overlap
  sharedHoldings.sort((a, b) => b.overlapContribution - a.overlapContribution);
  uniqueToA.sort((a, b) => b.weight - a.weight);
  uniqueToB.sort((a, b) => b.weight - a.weight);

  // Sector differences
  const sectorMapA = new Map<string, number>();
  for (const h of holdingsA) {
    const sec = h.sector?.trim() || 'Unclassified';
    sectorMapA.set(sec, (sectorMapA.get(sec) || 0) + h.weight);
  }
  const sectorMapB = new Map<string, number>();
  for (const h of holdingsB) {
    const sec = h.sector?.trim() || 'Unclassified';
    sectorMapB.set(sec, (sectorMapB.get(sec) || 0) + h.weight);
  }

  const allSectors = Array.from(new Set([...sectorMapA.keys(), ...sectorMapB.keys()]));
  const sectorDeltas = allSectors.map((sector) => {
    const wA = sectorMapA.get(sector) || 0;
    const wB = sectorMapB.get(sector) || 0;
    return {
      sector,
      weightInA: wA,
      weightInB: wB,
      delta: Math.abs(wA - wB),
    };
  }).sort((a, b) => b.delta - a.delta);

  // Reporting dates
  const repDateA = holdingsA[0]?.reportingDate || 'N/A';
  const repDateB = holdingsB[0]?.reportingDate || 'N/A';
  const isContemporaneous = repDateA !== 'N/A' && repDateB !== 'N/A' && repDateA === repDateB;

  return {
    fundA: fundAName,
    fundB: fundBName,
    overlapWeight,
    reportingDateA: repDateA,
    reportingDateB: repDateB,
    isContemporaneous,
    sharedHoldings,
    uniqueToA,
    uniqueToB,
    sectorDeltas,
  };
}

/**
 * Calculates self-overlap of a fund:
 * O_{A,A} = \sum_i w_{i,A}
 * Note: Never hardcodes 1.0! Returns actual sum of valid weights.
 */
export function calculateSelfOverlap(fundName: string, allHoldings: Holding[]): number {
  const holdings = allHoldings.filter((h) => h.fundName === fundName && !isNaN(h.weight) && h.weight > 0);
  return holdings.reduce((sum, h) => sum + h.weight, 0);
}

/**
 * Calculates Effective Stock Exposure across portfolio funds:
 * E_i = \sum_j a_j * w_{i,j}
 */
export function calculateEffectiveStockExposures(
  portfolio: PortfolioFundItem[],
  allHoldings: Holding[],
  totalValuation: number | null = null
): EffectiveStockExposure[] {
  if (portfolio.length === 0) return [];

  // Map of securityId -> Accumulated data
  const stockMap = new Map<
    string,
    {
      securityName: string;
      isin: string;
      sector: string;
      marketCap: EffectiveStockExposure['marketCap'];
      effectiveWeight: number;
      fundContributions: EffectiveStockExposure['fundContributions'];
    }
  >();

  for (const item of portfolio) {
    if (item.normalizedWeight <= 0) continue;

    const fundHoldings = allHoldings.filter(
      (h) => h.fundName === item.fundName && !isNaN(h.weight) && h.weight > 0
    );

    for (const h of fundHoldings) {
      const key = getSecurityIdentifier(h);
      const contribution = item.normalizedWeight * h.weight;

      const existing = stockMap.get(key);
      if (existing) {
        existing.effectiveWeight += contribution;
        existing.fundContributions.push({
          fundName: item.fundName,
          fundWeightInPortfolio: item.normalizedWeight,
          stockWeightInFund: h.weight,
          contributionWeight: contribution,
        });
        // Enrich missing metadata if available in another fund's record
        if ((!existing.isin || existing.isin === 'N/A') && h.isin) {
          existing.isin = h.isin;
        }
        if (existing.sector === 'Unclassified' && h.sector) {
          existing.sector = h.sector;
        }
        if (existing.marketCap === 'Unclassified' && h.marketCap) {
          existing.marketCap = h.marketCap;
        }
      } else {
        stockMap.set(key, {
          securityName: h.securityName,
          isin: h.isin?.trim() || 'N/A',
          sector: h.sector?.trim() || 'Unclassified',
          marketCap: h.marketCap || 'Unclassified',
          effectiveWeight: contribution,
          fundContributions: [
            {
              fundName: item.fundName,
              fundWeightInPortfolio: item.normalizedWeight,
              stockWeightInFund: h.weight,
              contributionWeight: contribution,
            },
          ],
        });
      }
    }
  }

  const result: EffectiveStockExposure[] = [];
  for (const item of stockMap.values()) {
    // Sort fund contributions descending
    item.fundContributions.sort((a, b) => b.contributionWeight - a.contributionWeight);

    result.push({
      securityName: item.securityName,
      isin: item.isin,
      sector: item.sector,
      marketCap: item.marketCap,
      effectiveWeight: item.effectiveWeight,
      effectiveAmount:
        totalValuation !== null && totalValuation > 0
          ? totalValuation * item.effectiveWeight
          : undefined,
      fundContributions: item.fundContributions,
      fundCount: item.fundContributions.length,
      dataQualityWarning:
        item.isin === 'N/A' || item.sector === 'Unclassified'
          ? 'Missing ISIN or sector disclosure'
          : undefined,
    });
  }

  // Sort descending by effective weight
  result.sort((a, b) => b.effectiveWeight - a.effectiveWeight);
  return result;
}

/**
 * Calculates Sector Exposure:
 * S_k = \sum_{i \in k} E_i
 */
export function calculateSectorExposures(
  stockExposures: EffectiveStockExposure[]
): SectorExposure[] {
  if (stockExposures.length === 0) return [];

  const sectorMap = new Map<
    string,
    {
      effectiveWeight: number;
      stocks: EffectiveStockExposure[];
      contributingFunds: Set<string>;
    }
  >();

  for (const s of stockExposures) {
    const secName = s.sector?.trim() || 'Unclassified';
    let entry = sectorMap.get(secName);
    if (!entry) {
      entry = {
        effectiveWeight: 0,
        stocks: [],
        contributingFunds: new Set<string>(),
      };
      sectorMap.set(secName, entry);
    }
    entry.effectiveWeight += s.effectiveWeight;
    entry.stocks.push(s);
    for (const fc of s.fundContributions) {
      entry.contributingFunds.add(fc.fundName);
    }
  }

  // Calculate sum of classified sectors (excluding Unclassified)
  let classifiedTotal = 0;
  for (const [sec, entry] of sectorMap.entries()) {
    if (sec.toLowerCase() !== 'unclassified') {
      classifiedTotal += entry.effectiveWeight;
    }
  }

  const result: SectorExposure[] = [];
  for (const [sector, entry] of sectorMap.entries()) {
    // Top stock in sector
    const topStock = entry.stocks.reduce(
      (max, s) => (s.effectiveWeight > max.effectiveWeight ? s : max),
      entry.stocks[0]
    );

    result.push({
      sector,
      effectiveWeight: entry.effectiveWeight,
      effectiveWeightClassified:
        classifiedTotal > 0 && sector.toLowerCase() !== 'unclassified'
          ? entry.effectiveWeight / classifiedTotal
          : 0,
      stockCount: entry.stocks.length,
      contributingFunds: Array.from(entry.contributingFunds),
      topStockName: topStock ? topStock.securityName : 'N/A',
      topStockWeight: topStock ? topStock.effectiveWeight : 0,
    });
  }

  // Sort descending by effective weight
  result.sort((a, b) => b.effectiveWeight - a.effectiveWeight);
  return result;
}

/**
 * Calculates Market Cap category breakdown
 */
export function calculateMarketCapExposures(
  stockExposures: EffectiveStockExposure[]
): MarketCapExposure[] {
  const map: Record<string, { weight: number; count: number }> = {
    'Large-Cap': { weight: 0, count: 0 },
    'Mid-Cap': { weight: 0, count: 0 },
    'Small-Cap': { weight: 0, count: 0 },
    Other: { weight: 0, count: 0 },
    Unclassified: { weight: 0, count: 0 },
  };

  for (const s of stockExposures) {
    const cap = s.marketCap || 'Unclassified';
    if (!map[cap]) {
      map[cap] = { weight: 0, count: 0 };
    }
    map[cap].weight += s.effectiveWeight;
    map[cap].count += 1;
  }

  return (Object.keys(map) as MarketCapExposure['category'][]).map((cat) => ({
    category: cat,
    effectiveWeight: map[cat].weight,
    stockCount: map[cat].count,
  }));
}

/**
 * Calculates Herfindahl-Hirschman Index (HHI) and Effective Number of Holdings:
 * HHI = \sum_i p_i^2
 * N_{effective} = 1 / HHI
 *
 * Uses proportions p_i normalized within the valid equity universe (sum p_i = 1.0).
 */
export function calculateConcentrationMetrics(
  stockWeights: number[]
): { hhi: number; effectiveHoldings: number } {
  const validWeights = stockWeights.filter((w) => !isNaN(w) && w > 0);
  if (validWeights.length === 0) {
    return { hhi: 0, effectiveHoldings: 0 };
  }

  const total = validWeights.reduce((sum, w) => sum + w, 0);
  if (total <= 0) {
    return { hhi: 0, effectiveHoldings: 0 };
  }

  // Calculate p_i = w_i / total
  const proportions = validWeights.map((w) => w / total);
  const hhi = proportions.reduce((sum, p) => sum + p * p, 0);
  const effectiveHoldings = hhi > 0 ? 1 / hhi : 0;

  return { hhi, effectiveHoldings };
}

/**
 * Calculates Portfolio-Weighted Pairwise Stock Overlap:
 * Across all pairs of funds (j < k), weighted by portfolio weights:
 * O_portfolio = \sum_{j < k} (2 * a_j * a_k / (1 - \sum a_m^2)) * O_{j,k}
 */
export function calculatePortfolioWeightedOverlap(
  portfolio: PortfolioFundItem[],
  allHoldings: Holding[]
): number {
  if (portfolio.length <= 1) return 0;

  const validItems = portfolio.filter((item) => item.normalizedWeight > 0);
  if (validItems.length <= 1) return 0;

  let totalCrossWeight = 0;
  for (let j = 0; j < validItems.length; j++) {
    for (let k = j + 1; k < validItems.length; k++) {
      totalCrossWeight += 2 * validItems[j].normalizedWeight * validItems[k].normalizedWeight;
    }
  }

  if (totalCrossWeight <= 0) return 0;

  let weightedOverlapSum = 0;
  for (let j = 0; j < validItems.length; j++) {
    for (let k = j + 1; k < validItems.length; k++) {
      const pair = calculatePairwiseOverlap(
        validItems[j].fundName,
        validItems[k].fundName,
        allHoldings
      );
      const pairWeight =
        (2 * validItems[j].normalizedWeight * validItems[k].normalizedWeight) / totalCrossWeight;
      weightedOverlapSum += pairWeight * pair.overlapWeight;
    }
  }

  return weightedOverlapSum;
}

/**
 * Complete Portfolio Analytics Engine:
 * Generates all portfolio-level metrics, exposures, concentration, and diagnostics.
 */
export function calculatePortfolioAnalytics(
  portfolio: PortfolioFundItem[],
  allHoldings: Holding[],
  mode: PortfolioMode = 'allocation'
): PortfolioAnalyticsResult {
  if (portfolio.length === 0) {
    return {
      mode,
      totalValuation: null,
      fundsCount: 0,
      uniqueStocksCount: 0,
      portfolioWeightedOverlap: 0,
      top5StockExposure: 0,
      top10StockExposure: 0,
      top20StockExposure: 0,
      highestStockExposure: null,
      highestSectorExposure: null,
      stockExposures: [],
      sectorExposures: [],
      marketCapExposures: [],
      hhi: 0,
      effectiveHoldings: 0,
      unclassifiedWeight: 0,
      dataCompletenessScore: 0,
      hasReportingDateMismatch: false,
    };
  }

  // Valuation
  const totalValuation =
    mode === 'valuation'
      ? portfolio.reduce((sum, item) => sum + (item.amount || 0), 0)
      : null;

  // Stock exposures
  const stockExposures = calculateEffectiveStockExposures(
    portfolio,
    allHoldings,
    totalValuation
  );

  // Unique stocks
  const uniqueStocksCount = stockExposures.length;

  // Top N exposures
  const top5StockExposure = stockExposures
    .slice(0, 5)
    .reduce((sum, s) => sum + s.effectiveWeight, 0);
  const top10StockExposure = stockExposures
    .slice(0, 10)
    .reduce((sum, s) => sum + s.effectiveWeight, 0);
  const top20StockExposure = stockExposures
    .slice(0, 20)
    .reduce((sum, s) => sum + s.effectiveWeight, 0);

  // Highest exposures
  const highestStockExposure =
    stockExposures.length > 0
      ? {
          securityName: stockExposures[0].securityName,
          weight: stockExposures[0].effectiveWeight,
        }
      : null;

  // Sectors
  const sectorExposures = calculateSectorExposures(stockExposures);
  const highestSectorExposure =
    sectorExposures.length > 0
      ? {
          sector: sectorExposures[0].sector,
          weight: sectorExposures[0].effectiveWeight,
        }
      : null;

  // Market Cap
  const marketCapExposures = calculateMarketCapExposures(stockExposures);

  // Concentration
  const stockWeights = stockExposures.map((s) => s.effectiveWeight);
  const { hhi, effectiveHoldings } = calculateConcentrationMetrics(stockWeights);

  // Unclassified
  const unclassifiedSector = sectorExposures.find(
    (s) => s.sector.toLowerCase() === 'unclassified'
  );
  const unclassifiedWeight = unclassifiedSector ? unclassifiedSector.effectiveWeight : 0;

  // Portfolio-weighted overlap
  const portfolioWeightedOverlap = calculatePortfolioWeightedOverlap(
    portfolio,
    allHoldings
  );

  // Reporting dates audit
  const dates = new Set<string>();
  let totalDataFields = 0;
  let populatedDataFields = 0;

  for (const item of portfolio) {
    const fundHoldings = allHoldings.filter((h) => h.fundName === item.fundName);
    for (const h of fundHoldings) {
      if (h.reportingDate) dates.add(h.reportingDate);
      totalDataFields += 4; // isin, sector, marketCap, reportingDate
      if (h.isin && h.isin !== 'N/A') populatedDataFields++;
      if (h.sector && h.sector !== 'Unclassified') populatedDataFields++;
      if (h.marketCap && h.marketCap !== 'Unclassified') populatedDataFields++;
      if (h.reportingDate) populatedDataFields++;
    }
  }

  const sortedDates = Array.from(dates).sort();
  const hasReportingDateMismatch = sortedDates.length > 1;
  const dataCompletenessScore =
    totalDataFields > 0 ? Math.round((populatedDataFields / totalDataFields) * 100) : 100;

  return {
    mode,
    totalValuation,
    fundsCount: portfolio.length,
    uniqueStocksCount,
    portfolioWeightedOverlap,
    top5StockExposure,
    top10StockExposure,
    top20StockExposure,
    highestStockExposure,
    highestSectorExposure,
    stockExposures,
    sectorExposures,
    marketCapExposures,
    hhi,
    effectiveHoldings,
    unclassifiedWeight,
    dataCompletenessScore,
    hasReportingDateMismatch,
    earliestDate: sortedDates[0],
    latestDate: sortedDates[sortedDates.length - 1],
  };
}

/**
 * Runs What-If Fund Replacement Simulation:
 * Replaces targetFundName with replacementFundName, preserves allocation,
 * and completely recalculates the portfolio via the analytics engine.
 */
export function simulateFundReplacement(
  currentPortfolio: PortfolioFundItem[],
  targetFundName: string,
  replacementFundName: string,
  allHoldings: Holding[],
  mode: PortfolioMode = 'allocation'
): {
  original: PortfolioAnalyticsResult;
  simulated: PortfolioAnalyticsResult;
  simulatedPortfolio: PortfolioFundItem[];
  exposureDeltas: {
    securityName: string;
    isin: string;
    sector: string;
    originalWeight: number;
    simulatedWeight: number;
    delta: number;
  }[];
} {
  const original = calculatePortfolioAnalytics(currentPortfolio, allHoldings, mode);

  // Build simulated portfolio by replacing the fund item
  const simulatedPortfolio = currentPortfolio.map((item) => {
    if (item.fundName === targetFundName) {
      return {
        ...item,
        id: `sim-${Date.now()}-${replacementFundName}`,
        fundName: replacementFundName,
      };
    }
    return { ...item };
  });

  const simulated = calculatePortfolioAnalytics(simulatedPortfolio, allHoldings, mode);

  // Compare security exposures
  const origMap = new Map<string, EffectiveStockExposure>();
  for (const s of original.stockExposures) {
    origMap.set(getSecurityIdentifier(s), s);
  }

  const simMap = new Map<string, EffectiveStockExposure>();
  for (const s of simulated.stockExposures) {
    simMap.set(getSecurityIdentifier(s), s);
  }

  const allKeys = Array.from(new Set([...origMap.keys(), ...simMap.keys()]));
  const exposureDeltas = allKeys.map((key) => {
    const o = origMap.get(key);
    const s = simMap.get(key);
    const origW = o ? o.effectiveWeight : 0;
    const simW = s ? s.effectiveWeight : 0;
    return {
      securityName: o?.securityName || s?.securityName || 'Unknown',
      isin: o?.isin || s?.isin || 'N/A',
      sector: o?.sector || s?.sector || 'Unclassified',
      originalWeight: origW,
      simulatedWeight: simW,
      delta: simW - origW,
    };
  }).sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta));

  return {
    original,
    simulated,
    simulatedPortfolio,
    exposureDeltas,
  };
}
