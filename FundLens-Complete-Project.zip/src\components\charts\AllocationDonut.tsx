// Portfolio Fund Allocation Donut Chart using Recharts

import React from 'react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
} from 'recharts';
import { PortfolioFundItem } from '../../types';
import { formatPercent, formatINR } from '../../lib/formatting';

interface AllocationDonutProps {
  portfolio: PortfolioFundItem[];
  totalValuation: number | null;
}

const PALETTE = [
  '#147D64', // Emerald
  '#2563EB', // Blue
  '#0D9488', // Teal
  '#D97706', // Amber
  '#7C3AED', // Violet
  '#475569', // Slate
  '#DB2777', // Pink
  '#059669', // Green
];

export const AllocationDonut: React.FC<AllocationDonutProps> = ({
  portfolio,
  totalValuation,
}) => {
  const chartData = portfolio.map((item, idx) => ({
    name: item.fundName,
    value: item.normalizedWeight,
    amount: item.amount,
    color: PALETTE[idx % PALETTE.length],
  }));

  if (chartData.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-xs text-text-sub">
        No funds in portfolio
      </div>
    );
  }

  return (
    <div className="w-full flex flex-col md:flex-row items-center gap-4">
      <div className="relative w-full md:w-1/2 h-56">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={chartData}
              innerRadius={55}
              outerRadius={80}
              paddingAngle={2}
              dataKey="value"
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              formatter={(value: any, _: any, entry: any) => {
                const num = Number(value);
                const percentStr = formatPercent(num);
                const amtStr = entry.payload.amount ? ` (${formatINR(entry.payload.amount)})` : '';
                return [`${percentStr}${amtStr}`, 'Allocation'];
              }}
              contentStyle={{
                backgroundColor: '#FFFFFF',
                borderColor: '#E4E7EC',
                borderRadius: '8px',
                fontSize: '12px',
              }}
            />
          </PieChart>
        </ResponsiveContainer>
        {/* Center label */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
          <span className="text-xl font-bold text-text-main tabular-nums">
            {portfolio.length}
          </span>
          <span className="text-[10px] uppercase font-semibold text-text-sub tracking-wider">
            Funds
          </span>
        </div>
      </div>

      {/* Legend */}
      <div className="w-full md:w-1/2 space-y-2 overflow-y-auto max-h-56 pr-1">
        {chartData.map((item) => (
          <div key={item.name} className="flex items-center justify-between text-xs gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <span
                className="w-2.5 h-2.5 rounded-full shrink-0"
                style={{ backgroundColor: item.color }}
              />
              <span className="text-text-main font-medium truncate" title={item.name}>
                {item.name}
              </span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {item.amount && totalValuation && (
                <span className="text-[11px] text-text-sub tabular-nums">
                  {formatINR(item.amount)}
                </span>
              )}
              <span className="font-semibold text-text-main tabular-nums text-xs">
                {formatPercent(item.value)}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
