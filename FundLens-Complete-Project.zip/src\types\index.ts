// Core Type Definitions for FundLens

export type MarketCapCategory = 'Large-Cap' | 'Mid-Cap' | 'Small-Cap' | 'Other' | 'Unclassified';

export type InstrumentType = 'Equity' | 'Debt' | 'Cash & Equivalents' | 'Derivatives' | 'Other';

export interface Holding {
  fundName: string;
  schemeCode?: string;
  securityName: string;
  isin?: string;
  weight: number; // Stored as decimal internally (e.g. 0.08 for 8%)
  sector?: string;
  marketCap?: MarketCapCategory;
  reportingDate?: string; // YYYY-MM-DD
  instrumentType?: InstrumentType;
}

export interface FundMeta {
  fundName: string;
  schemeCode?: string;
  category: string;
  reportingDate: string;
  reportedWeightTotal: number; // Sum of holding weights (e.g. 0.985 for 98.5%)
  isNormalized: boolean;
  holdingsCount: number;
  completenessScore: number; // 0 to 100
  dataQualityIssues: string[];
}

export interface PortfolioFundItem {
  id: string;
  fundName: string;
  amount?: number; // Investment amount in INR (optional)
  targetWeight?: number; // User target weight decimal (optional, e.g. 0.25)
  normalizedWeight: number; // Effective weight used in portfolio calculations (sums to 1.0)
}

export type PortfolioMode = 'allocation' | 'valuation'; // Target % vs Amount

export interface EffectiveStockExposure {
  securityName: string;
  isin: string;
  sector: string;
  marketCap: MarketCapCategory;
  effectiveWeight: number; // Decimal (e.g. 0.068 for 6.8%)
  effectiveAmount?: number; // INR
  fundContributions: {
    fundName: string;
    fundWeightInPortfolio: number;
    stockWeightInFund: number;
    contributionWeight: number; // a_j * w_{i,j}
  }[];
  fundCount: number;
  dataQualityWarning?: string;
}

export interface SectorExposure {
  sector: string;
  effectiveWeight: number; // Decimal
  effectiveWeightClassified: number; // Percentage within classified universe
  stockCount: number;
  contributingFunds: string[];
  topStockName: string;
  topStockWeight: number;
}

export interface MarketCapExposure {
  category: MarketCapCategory;
  effectiveWeight: number;
  stockCount: number;
}

export interface PairwiseOverlap {
  fundA: string;
  fundB: string;
  overlapWeight: number; // Decimal (0.13 for 13%)
  reportingDateA: string;
  reportingDateB: string;
  isContemporaneous: boolean;
  sharedHoldings: {
    securityName: string;
    isin: string;
    sector: string;
    weightInA: number;
    weightInB: number;
    overlapContribution: number; // min(w_A, w_B)
  }[];
  uniqueToA: {
    securityName: string;
    isin: string;
    sector: string;
    weight: number;
  }[];
  uniqueToB: {
    securityName: string;
    isin: string;
    sector: string;
    weight: number;
  }[];
  sectorDeltas: {
    sector: string;
    weightInA: number;
    weightInB: number;
    delta: number;
  }[];
}

export interface PortfolioAnalyticsResult {
  mode: PortfolioMode;
  totalValuation: number | null;
  fundsCount: number;
  uniqueStocksCount: number;
  portfolioWeightedOverlap: number;
  top5StockExposure: number;
  top10StockExposure: number;
  top20StockExposure: number;
  highestStockExposure: {
    securityName: string;
    weight: number;
  } | null;
  highestSectorExposure: {
    sector: string;
    weight: number;
  } | null;
  stockExposures: EffectiveStockExposure[];
  sectorExposures: SectorExposure[];
  marketCapExposures: MarketCapExposure[];
  hhi: number; // Herfindahl-Hirschman Index
  effectiveHoldings: number; // 1 / HHI
  unclassifiedWeight: number;
  dataCompletenessScore: number;
  hasReportingDateMismatch: boolean;
  earliestDate?: string;
  latestDate?: string;
}

export interface PortfolioInsight {
  id: string;
  type: 'warning' | 'info' | 'positive';
  title: string;
  description: string;
  metricLabel?: string;
  metricValue?: string;
  actionScreen?: string;
  actionText?: string;
  filterPayload?: string;
}

export interface CSVValidationResult {
  isValid: boolean;
  totalRows: number;
  validRows: number;
  rejectedRows: number;
  parsedHoldings: Holding[];
  fundsDiscovered: string[];
  errors: {
    row: number;
    fundName?: string;
    securityName?: string;
    field: string;
    message: string;
    rawContent?: string;
  }[];
  warnings: {
    row?: number;
    fundName?: string;
    type: string;
    message: string;
  }[];
  reportingDates: string[];
  completenessScore: number;
}
