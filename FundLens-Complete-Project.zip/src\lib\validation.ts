// CSV Holdings Validation Engine
// Adheres strictly to Section 5 (Screen 7) and Section 12 of Master Build Prompt

import { Holding, CSVValidationResult, MarketCapCategory, InstrumentType } from '../types';

export interface RawParsedRow {
  fundName?: string;
  schemeCode?: string;
  securityName?: string;
  isin?: string;
  weight?: string | number;
  sector?: string;
  marketCap?: string;
  reportingDate?: string;
  instrumentType?: string;
  [key: string]: any;
}

export function validateHoldingsRows(rawRows: RawParsedRow[]): CSVValidationResult {
  const errors: CSVValidationResult['errors'] = [];
  const warnings: CSVValidationResult['warnings'] = [];
  const parsedHoldings: Holding[] = [];
  const fundsDiscoveredSet = new Set<string>();
  const reportingDatesSet = new Set<string>();

  // Tracking duplicates per fund: fundName + isinOrSecurity
  const seenRecords = new Map<string, number>(); // key -> first seen row number
  const fundWeightsMap = new Map<string, number>();

  let totalFieldCount = 0;
  let populatedFieldCount = 0;

  rawRows.forEach((row, index) => {
    const rowNum = index + 1; // 1-indexed for user-friendly error messages

    const fundName = (row.fundName || '').trim();
    const securityName = (row.securityName || '').trim();
    const rawWeight = row.weight;

    // Rule 1: Missing fund identifier
    if (!fundName) {
      errors.push({
        row: rowNum,
        field: 'Fund Name',
        message: 'Fund identifier is required.',
        rawContent: JSON.stringify(row),
      });
      return;
    }

    fundsDiscoveredSet.add(fundName);

    // Rule 2: Missing security identifier (neither Security Name nor ISIN provided)
    const isin = (row.isin || '').trim().toUpperCase();
    if (!securityName && !isin) {
      errors.push({
        row: rowNum,
        fundName,
        field: 'Security Identifier',
        message: 'Security Name or ISIN is required.',
        rawContent: JSON.stringify(row),
      });
      return;
    }

    // Rule 3: Validate weight
    if (rawWeight === undefined || rawWeight === null || String(rawWeight).trim() === '') {
      errors.push({
        row: rowNum,
        fundName,
        securityName: securityName || isin,
        field: 'Weight %',
        message: 'Weight is missing. Missing values cannot be silently assumed as 0%.',
        rawContent: String(rawWeight),
      });
      return;
    }

    let numericWeight: number;
    if (typeof rawWeight === 'number') {
      numericWeight = rawWeight;
    } else {
      const cleanStr = String(rawWeight).replace('%', '').trim();
      numericWeight = parseFloat(cleanStr);
    }

    if (isNaN(numericWeight)) {
      errors.push({
        row: rowNum,
        fundName,
        securityName: securityName || isin,
        field: 'Weight %',
        message: `Non-numeric weight '${rawWeight}' cannot be parsed.`,
        rawContent: String(rawWeight),
      });
      return;
    }

    // If input was given as percentage (e.g. 8.5 for 8.5%), convert to decimal if > 1.0
    // Check if the file consistently uses decimals (e.g. 0.08) or percentages (e.g. 8.0)
    let decimalWeight = numericWeight;
    if (numericWeight > 1.0) {
      decimalWeight = numericWeight / 100;
    }

    // Rule 4: Reject negative weights
    if (decimalWeight < 0) {
      errors.push({
        row: rowNum,
        fundName,
        securityName: securityName || isin,
        field: 'Weight %',
        message: `Negative weight '${rawWeight}' is not permitted for standard equity holdings.`,
        rawContent: String(rawWeight),
      });
      return;
    }

    // Rule 5: Duplicate detection
    const uniqueSecKey = `${fundName.toLowerCase()}:::${(isin || securityName).toLowerCase()}`;
    if (seenRecords.has(uniqueSecKey)) {
      const previousRow = seenRecords.get(uniqueSecKey)!;
      warnings.push({
        row: rowNum,
        fundName,
        type: 'DUPLICATE_HOLDING',
        message: `Duplicate security '${securityName || isin}' previously defined at row ${previousRow}. The weights will be combined.`,
      });
    } else {
      seenRecords.set(uniqueSecKey, rowNum);
    }

    // Rule 6: Track completeness
    totalFieldCount += 5; // isin, sector, marketCap, reportingDate, instrumentType
    if (isin) populatedFieldCount++;
    if (row.sector && row.sector.trim()) populatedFieldCount++;
    if (row.marketCap && row.marketCap.trim()) populatedFieldCount++;
    if (row.reportingDate && row.reportingDate.trim()) populatedFieldCount++;
    if (row.instrumentType && row.instrumentType.trim()) populatedFieldCount++;

    // Warnings for missing optional fields
    if (!isin) {
      warnings.push({
        row: rowNum,
        fundName,
        type: 'MISSING_ISIN',
        message: `Missing ISIN for '${securityName}'. Matching will rely on string name normalization.`,
      });
    }

    const sector = (row.sector || '').trim() || 'Unclassified';
    if (sector === 'Unclassified') {
      warnings.push({
        row: rowNum,
        fundName,
        type: 'UNCLASSIFIED_SECTOR',
        message: `Holding '${securityName || isin}' has no sector classification.`,
      });
    }

    // Standardize Market Cap
    let standardizedMarketCap: MarketCapCategory = 'Unclassified';
    const rawCap = (row.marketCap || '').trim().toLowerCase();
    if (rawCap.includes('large')) standardizedMarketCap = 'Large-Cap';
    else if (rawCap.includes('mid')) standardizedMarketCap = 'Mid-Cap';
    else if (rawCap.includes('small')) standardizedMarketCap = 'Small-Cap';
    else if (rawCap.includes('other')) standardizedMarketCap = 'Other';

    // Standardize Instrument Type
    let standardizedInstrument: InstrumentType = 'Equity';
    const rawInst = (row.instrumentType || '').trim().toLowerCase();
    if (rawInst.includes('debt') || rawInst.includes('bond')) standardizedInstrument = 'Debt';
    else if (rawInst.includes('cash') || rawInst.includes('treps') || rawInst.includes('net current')) standardizedInstrument = 'Cash & Equivalents';
    else if (rawInst.includes('deriv') || rawInst.includes('future') || rawInst.includes('option')) standardizedInstrument = 'Derivatives';

    const repDate = (row.reportingDate || '').trim();
    if (repDate) {
      reportingDatesSet.add(repDate);
    }

    // Accumulate valid holding
    parsedHoldings.push({
      fundName,
      schemeCode: (row.schemeCode || '').trim() || undefined,
      securityName: securityName || isin,
      isin: isin || undefined,
      weight: decimalWeight,
      sector,
      marketCap: standardizedMarketCap,
      reportingDate: repDate || undefined,
      instrumentType: standardizedInstrument,
    });

    fundWeightsMap.set(fundName, (fundWeightsMap.get(fundName) || 0) + decimalWeight);
  });

  // Rule 7: Fund-level weight tolerance warnings
  for (const [fund, totalW] of fundWeightsMap.entries()) {
    if (totalW < 0.90 || totalW > 1.05) {
      warnings.push({
        fundName: fund,
        type: 'WEIGHT_TOTAL_TOLERANCE',
        message: `Reported holdings for '${fund}' sum to ${(totalW * 100).toFixed(2)}% (outside the standard 90%-105% tolerance). An unnormalized portfolio will reflect this difference.`,
      });
    }
  }

  // Rule 8: Mixed reporting dates
  const reportingDates = Array.from(reportingDatesSet).sort();
  if (reportingDates.length > 1) {
    warnings.push({
      type: 'MIXED_REPORTING_DATES',
      message: `Holdings dataset contains multiple disclosure dates (${reportingDates.join(', ')}). Overlap comparisons across non-contemporaneous dates should be interpreted with caution.`,
    });
  }

  const completenessScore =
    totalFieldCount > 0 ? Math.round((populatedFieldCount / totalFieldCount) * 100) : 100;

  return {
    isValid: errors.length === 0 && parsedHoldings.length > 0,
    totalRows: rawRows.length,
    validRows: parsedHoldings.length,
    rejectedRows: errors.length,
    parsedHoldings,
    fundsDiscovered: Array.from(fundsDiscoveredSet),
    errors,
    warnings,
    reportingDates,
    completenessScore,
  };
}
