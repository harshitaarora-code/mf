// Data Source Banner for Live Indian MFAPI Data vs Uploaded Data

import React from 'react';
import { UploadCloud, Globe, X, RotateCcw } from 'lucide-react';
import { DataSourceMode } from './Header';

interface DataBannerProps {
  dataSourceMode: DataSourceMode;
  onNavigateToUpload: () => void;
  onSwitchToLiveIndianData: () => void;
  onResetPortfolio: () => void;
}

export const DataBanner: React.FC<DataBannerProps> = ({
  dataSourceMode,
  onNavigateToUpload,
  onSwitchToLiveIndianData,
  onResetPortfolio,
}) => {
  const [dismissed, setDismissed] = React.useState(false);

  if (dismissed) {
    return null;
  }

  if (dataSourceMode === 'uploaded') {
    return (
      <div className="bg-blue-50/90 border-b border-blue-200 px-4 py-2 sm:px-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 text-xs text-blue-950">
          <div className="flex items-center gap-2">
            <UploadCloud className="w-4 h-4 text-blue-700 shrink-0" />
            <span>
              <strong>Custom CSV Portfolio Loaded:</strong> Analyzing user-uploaded scheme holdings and weights.
            </span>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onSwitchToLiveIndianData}
              className="text-blue-800 hover:text-blue-950 underline font-semibold inline-flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Restore Live Indian Mutual Funds</span>
            </button>
            <button
              onClick={() => setDismissed(true)}
              className="text-blue-700 hover:text-blue-950 p-0.5 rounded"
              aria-label="Dismiss banner"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-emerald-50/90 border-b border-emerald-200 px-4 py-2 sm:px-6">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 text-xs text-emerald-950">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-emerald-700 shrink-0" />
          <span>
            <strong>Active Indian Mutual Funds Analysis (AMFI verified via MFAPI.in):</strong> Analyzing real disclosed stock holdings and live NAVs for Parag Parikh Flexi Cap, Mirae Asset Large & Midcap, and HDFC Mid Cap.
          </span>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onResetPortfolio}
            className="text-emerald-800 hover:text-emerald-950 underline font-medium"
            title="Reset portfolio to default live Indian mutual fund schemes"
          >
            Reset Portfolio
          </button>
          <button
            onClick={() => setDismissed(true)}
            className="text-emerald-700 hover:text-emerald-950 p-0.5 rounded"
            aria-label="Dismiss banner"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
