// Interactive Live Indian Mutual Funds Explorer (MFAPI.in)

import React, { useState, useEffect } from 'react';
import {
  searchMutualFunds,
  fetchSchemeDetails,
  calculateNavMetrics,
  MFSchemeSearchResult,
  MFSchemeDetails,
  MFSchemeMetrics,
  POPULAR_INDIAN_SCHEMES,
} from '../../lib/mfapi';
import { formatPercent } from '../../lib/formatting';
import {
  Search,
  Building2,
  TrendingUp,
  TrendingDown,
  Calendar,
  Layers,
  Plus,
  Loader2,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  X,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
} from 'recharts';

interface MFSchemeExplorerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddSchemeToPortfolio: (scheme: { fundName: string; schemeCode: string; category: string }) => void;
}

export const MFSchemeExplorerModal: React.FC<MFSchemeExplorerModalProps> = ({
  isOpen,
  onClose,
  onAddSchemeToPortfolio,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<MFSchemeSearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedSchemeCode, setSelectedSchemeCode] = useState<number>(122640); // default Parag Parikh
  const [schemeDetails, setSchemeDetails] = useState<MFSchemeDetails | null>(null);
  const [metrics, setMetrics] = useState<MFSchemeMetrics | null>(null);
  const [isLoadingDetails, setIsLoadingDetails] = useState(false);
  const [addedSuccess, setAddedSuccess] = useState(false);

  // Debounced search
  useEffect(() => {
    if (!searchTerm.trim()) {
      setSearchResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const results = await searchMutualFunds(searchTerm);
        setSearchResults(results.slice(0, 15));
      } finally {
        setIsSearching(false);
      }
    }, 350);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Load details on scheme select
  useEffect(() => {
    if (!selectedSchemeCode) return;
    setIsLoadingDetails(true);
    setAddedSuccess(false);
    fetchSchemeDetails(selectedSchemeCode).then((details) => {
      setSchemeDetails(details);
      if (details) {
        setMetrics(calculateNavMetrics(details.data));
      }
      setIsLoadingDetails(false);
    });
  }, [selectedSchemeCode]);

  if (!isOpen) return null;

  // Prepare NAV chart data (last 90 records)
  const chartData = (schemeDetails?.data || [])
    .slice(0, 90)
    .reverse()
    .map((r) => ({
      date: r.date,
      nav: parseFloat(r.nav),
    }))
    .filter((r) => !isNaN(r.nav));

  const handleAdd = () => {
    if (!schemeDetails) return;
    onAddSchemeToPortfolio({
      fundName: schemeDetails.meta.scheme_name,
      schemeCode: String(schemeDetails.meta.scheme_code),
      category: schemeDetails.meta.scheme_category || 'Equity Scheme',
    });
    setAddedSuccess(true);
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl border border-border shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="p-5 border-b border-border flex items-center justify-between gap-4 bg-[#F8F9FA]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary-light border border-primary-border flex items-center justify-center text-primary shrink-0">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-text-main">
                  Live Indian Mutual Funds & NAV Explorer
                </h3>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                  MFAPI.in Live Feed
                </span>
              </div>
              <p className="text-xs text-text-sub mt-0.5">
                Official AMFI scheme metadata, daily Net Asset Values, and return analytics
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-text-sub hover:text-text-main hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Search Bar */}
          <div className="space-y-2">
            <div className="relative">
              <Search className="w-4 h-4 text-text-sub absolute left-3.5 top-3" />
              <input
                type="text"
                placeholder="Search any Indian mutual fund (e.g. Parag Parikh, HDFC, Mirae, Nippon, SBI)..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-border text-xs text-text-main bg-white shadow-2xs focus:outline-hidden focus:border-primary"
              />
              {isSearching && (
                <Loader2 className="w-4 h-4 text-primary animate-spin absolute right-3.5 top-3" />
              )}
            </div>

            {/* Quick popular chips */}
            <div className="flex items-center gap-1.5 flex-wrap text-[11px] text-text-sub pt-1">
              <span className="font-semibold text-text-main">Popular:</span>
              {POPULAR_INDIAN_SCHEMES.slice(0, 5).map((pop) => (
                <button
                  key={pop.code}
                  onClick={() => {
                    setSelectedSchemeCode(pop.code);
                    setSearchTerm('');
                    setSearchResults([]);
                  }}
                  className={`px-2 py-0.5 rounded-md border text-[11px] transition-all ${
                    selectedSchemeCode === pop.code
                      ? 'bg-primary-light text-primary border-primary-border font-semibold'
                      : 'bg-[#F8F9FA] text-text-sub border-border hover:text-text-main'
                  }`}
                >
                  {pop.name.split('-')[0].trim()}
                </button>
              ))}
            </div>

            {/* Live Search Results Dropdown */}
            {searchResults.length > 0 && (
              <div className="border border-border rounded-xl bg-white shadow-lg overflow-hidden max-h-48 overflow-y-auto divide-y divide-border/60">
                {searchResults.map((res) => (
                  <button
                    key={res.schemeCode}
                    onClick={() => {
                      setSelectedSchemeCode(res.schemeCode);
                      setSearchResults([]);
                      setSearchTerm('');
                    }}
                    className="w-full text-left p-2.5 text-xs hover:bg-slate-50 transition-colors flex items-center justify-between gap-2"
                  >
                    <span className="font-medium text-text-main truncate">{res.schemeName}</span>
                    <span className="font-mono text-[10px] text-text-sub shrink-0">
                      AMFI: {res.schemeCode}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Scheme Details & NAV Analytics */}
          {isLoadingDetails ? (
            <div className="p-12 flex flex-col items-center justify-center text-xs text-text-sub gap-2">
              <Loader2 className="w-6 h-6 text-primary animate-spin" />
              <span>Fetching live AMFI disclosures from MFAPI.in...</span>
            </div>
          ) : schemeDetails ? (
            <div className="space-y-6">
              {/* Scheme Summary Card */}
              <div className="p-4 rounded-xl border border-border bg-[#F8F9FA]/60 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-primary">
                    {schemeDetails.meta.fund_house}
                  </span>
                  <h4 className="text-sm font-bold text-text-main leading-tight">
                    {schemeDetails.meta.scheme_name}
                  </h4>
                  <div className="flex items-center gap-2 text-xs text-text-sub flex-wrap">
                    <span className="bg-white px-2 py-0.5 rounded border border-border">
                      {schemeDetails.meta.scheme_category}
                    </span>
                    <span>•</span>
                    <span className="font-mono">AMFI: {schemeDetails.meta.scheme_code}</span>
                    {schemeDetails.meta.isin_growth && (
                      <>
                        <span>•</span>
                        <span className="font-mono">ISIN: {schemeDetails.meta.isin_growth}</span>
                      </>
                    )}
                  </div>
                </div>

                {/* Add to Portfolio Button */}
                <button
                  onClick={handleAdd}
                  disabled={addedSuccess}
                  className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold shadow-xs transition-all shrink-0 ${
                    addedSuccess
                      ? 'bg-emerald-600 text-white'
                      : 'bg-primary hover:bg-primary-hover text-white'
                  }`}
                >
                  {addedSuccess ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Added to Portfolio!</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4" />
                      <span>Add Scheme to Portfolio</span>
                    </>
                  )}
                </button>
              </div>

              {/* NAV KPI Metrics */}
              {metrics && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3.5 rounded-xl border border-border bg-white">
                    <span className="text-[11px] text-text-sub block font-medium">Latest NAV</span>
                    <span className="text-2xl font-bold text-text-main tabular-nums">
                      ₹{metrics.latestNav.toFixed(2)}
                    </span>
                    <span className="text-[10px] text-text-sub block mt-0.5">
                      As of {metrics.latestDate}
                    </span>
                  </div>

                  <div className="p-3.5 rounded-xl border border-border bg-white">
                    <span className="text-[11px] text-text-sub block font-medium">1-Year Return</span>
                    <span
                      className={`text-2xl font-bold tabular-nums ${
                        metrics.return1Y !== undefined && metrics.return1Y >= 0
                          ? 'text-emerald-700'
                          : 'text-rose-700'
                      }`}
                    >
                      {metrics.return1Y !== undefined ? formatPercent(metrics.return1Y) : '—'}
                    </span>
                    <span className="text-[10px] text-text-sub block mt-0.5">Absolute NAV return</span>
                  </div>

                  <div className="p-3.5 rounded-xl border border-border bg-white">
                    <span className="text-[11px] text-text-sub block font-medium">3-Year CAGR</span>
                    <span
                      className={`text-2xl font-bold tabular-nums ${
                        metrics.return3Y !== undefined && metrics.return3Y >= 0
                          ? 'text-emerald-700'
                          : 'text-rose-700'
                      }`}
                    >
                      {metrics.return3Y !== undefined ? formatPercent(metrics.return3Y) : '—'}
                    </span>
                    <span className="text-[10px] text-text-sub block mt-0.5">Annualized growth</span>
                  </div>

                  <div className="p-3.5 rounded-xl border border-border bg-white">
                    <span className="text-[11px] text-text-sub block font-medium">52-Week Range</span>
                    <div className="text-sm font-bold text-text-main tabular-nums mt-1">
                      ₹{metrics.low52w?.toFixed(1)} – ₹{metrics.high52w?.toFixed(1)}
                    </div>
                    <span className="text-[10px] text-text-sub block mt-0.5">High: ₹{metrics.allTimeHigh?.toFixed(1)}</span>
                  </div>
                </div>
              )}

              {/* NAV Trend Chart */}
              {chartData.length > 0 && (
                <div className="p-4 rounded-xl border border-border bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-text-main">
                      Historical NAV Trend (Recent 90 Trading Days)
                    </span>
                    <span className="text-[10px] text-text-sub">Source: AMFI via MFAPI.in</span>
                  </div>
                  <div className="h-44 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={chartData} margin={{ top: 5, right: 10, left: 10, bottom: 0 }}>
                        <defs>
                          <linearGradient id="navGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#147D64" stopOpacity={0.2} />
                            <stop offset="95%" stopColor="#147D64" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <XAxis
                          dataKey="date"
                          tick={{ fontSize: 10, fill: '#667085' }}
                          tickLine={false}
                          interval={15}
                        />
                        <YAxis
                          domain={['dataMin - 1', 'dataMax + 1']}
                          tick={{ fontSize: 10, fill: '#667085' }}
                          tickLine={false}
                          orientation="right"
                        />
                        <Tooltip
                          formatter={(val: any) => [`₹${Number(val).toFixed(2)}`, 'NAV']}
                          labelFormatter={(label) => `Date: ${label}`}
                          contentStyle={{
                            backgroundColor: '#FFFFFF',
                            borderColor: '#E4E7EC',
                            borderRadius: '8px',
                            fontSize: '11px',
                          }}
                        />
                        <Area
                          type="monotone"
                          dataKey="nav"
                          stroke="#147D64"
                          strokeWidth={2}
                          fill="url(#navGrad)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

              {/* NAV vs Holdings Guidance Notice */}
              <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 text-xs text-blue-900 leading-relaxed">
                <strong>Data Architecture Note:</strong> MFAPI delivers verified daily Net Asset Values and AMFI master classifications. To conduct underlying stock look-through and pairwise overlap calculations, pair this scheme with its periodic monthly holdings CSV disclosure (available from the AMC factsheet or our template).
              </div>
            </div>
          ) : null}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-border bg-[#F8F9FA] flex justify-between items-center text-xs text-text-sub">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-primary" />
            <span>Connected to AMFI Indian Mutual Funds Registry</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-slate-100 text-text-main border border-border rounded-lg text-xs font-semibold shadow-2xs transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
