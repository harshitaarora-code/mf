// Rule-Based Portfolio Intelligence Observations Engine
// Adheres strictly to Section 5 (Screen 1) and Section 9 of Master Build Prompt

import { PortfolioAnalyticsResult, PortfolioFundItem, Holding, PortfolioInsight } from '../types';
import { calculatePairwiseOverlap } from './analytics';
import { formatPercent } from './formatting';

// Documented analytical thresholds
export const THRESHOLDS = {
  HIGH_STOCK_CONCENTRATION: 0.08, // 8% single stock exposure
  CRITICAL_STOCK_CONCENTRATION: 0.12, // 12% single stock exposure
  HIGH_SECTOR_CONCENTRATION: 0.30, // 30% single sector exposure
  HIGH_FUND_OVERLAP: 0.35, // 35% pairwise overlap between any two funds
  SIGNIFICANT_PORTFOLIO_OVERLAP: 0.25, // 25% overall portfolio weighted overlap
  TOP5_CONCENTRATION: 0.40, // 40% top 5 stock concentration
  UNCLASSIFIED_WARNING: 0.05, // 5% holdings unclassified
};

/**
 * Generates transparent, rule-based observations from deterministic portfolio analytics.
 */
export function generatePortfolioInsights(
  analytics: PortfolioAnalyticsResult,
  portfolio: PortfolioFundItem[],
  allHoldings: Holding[]
): PortfolioInsight[] {
  const insights: PortfolioInsight[] = [];

  if (portfolio.length === 0 || analytics.stockExposures.length === 0) {
    return [
      {
        id: 'empty-portfolio',
        type: 'info',
        title: 'No Active Funds in Portfolio',
        description: 'Add mutual fund schemes from the available dataset or upload your own portfolio disclosures to begin diversification analysis.',
        actionScreen: 'portfolio',
        actionText: 'Configure Portfolio',
      },
    ];
  }

  // 1. Single Stock Concentration Check
  const topStock = analytics.stockExposures[0];
  if (topStock && topStock.effectiveWeight >= THRESHOLDS.CRITICAL_STOCK_CONCENTRATION) {
    insights.push({
      id: 'critical-stock-exposure',
      type: 'warning',
      title: `Critical Single-Stock Concentration: ${topStock.securityName}`,
      description: `Your portfolio has an effective exposure of ${formatPercent(topStock.effectiveWeight)} to ${topStock.securityName} across ${topStock.fundCount} funds. Even diversified mutual funds can create unintended single-stock risk when overlapping.`,
      metricLabel: 'Effective Exposure',
      metricValue: formatPercent(topStock.effectiveWeight),
      actionScreen: 'stock-exposure',
      actionText: 'View Stock Exposure',
      filterPayload: topStock.securityName,
    });
  } else if (topStock && topStock.effectiveWeight >= THRESHOLDS.HIGH_STOCK_CONCENTRATION) {
    insights.push({
      id: 'high-stock-exposure',
      type: 'info',
      title: `Elevated Single-Stock Weight: ${topStock.securityName}`,
      description: `${topStock.securityName} accounts for ${formatPercent(topStock.effectiveWeight)} of your underlying equity holdings across ${topStock.fundCount} mutual funds.`,
      metricLabel: 'Effective Exposure',
      metricValue: formatPercent(topStock.effectiveWeight),
      actionScreen: 'stock-exposure',
      actionText: 'Inspect Holdings',
      filterPayload: topStock.securityName,
    });
  }

  // 2. High Pairwise Fund Overlap Check
  let highestOverlapPair: { fundA: string; fundB: string; overlap: number } | null = null;
  for (let i = 0; i < portfolio.length; i++) {
    for (let j = i + 1; j < portfolio.length; j++) {
      const pair = calculatePairwiseOverlap(portfolio[i].fundName, portfolio[j].fundName, allHoldings);
      if (!highestOverlapPair || pair.overlapWeight > highestOverlapPair.overlap) {
        highestOverlapPair = {
          fundA: portfolio[i].fundName,
          fundB: portfolio[j].fundName,
          overlap: pair.overlapWeight,
        };
      }
    }
  }

  if (highestOverlapPair && highestOverlapPair.overlap >= THRESHOLDS.HIGH_FUND_OVERLAP) {
    insights.push({
      id: 'high-pairwise-overlap',
      type: 'warning',
      title: `High Overlap Between Scheme Pair`,
      description: `'${highestOverlapPair.fundA}' and '${highestOverlapPair.fundB}' share ${formatPercent(highestOverlapPair.overlap)} of their holdings by weight. Holding both may offer limited incremental diversification.`,
      metricLabel: 'Pairwise Overlap',
      metricValue: formatPercent(highestOverlapPair.overlap),
      actionScreen: 'fund-overlap',
      actionText: 'Compare Pair',
    });
  }

  // 3. Sector Concentration Check
  const topSector = analytics.sectorExposures[0];
  if (topSector && topSector.effectiveWeight >= THRESHOLDS.HIGH_SECTOR_CONCENTRATION) {
    insights.push({
      id: 'high-sector-concentration',
      type: 'warning',
      title: `High Sector Exposure: ${topSector.sector}`,
      description: `${topSector.sector} accounts for ${formatPercent(topSector.effectiveWeight)} of your overall equity exposure across ${topSector.contributingFunds.length} funds. Systematic shocks to this sector will significantly impact portfolio returns.`,
      metricLabel: 'Sector Weight',
      metricValue: formatPercent(topSector.effectiveWeight),
      actionScreen: 'sector-analysis',
      actionText: 'Analyze Sectors',
      filterPayload: topSector.sector,
    });
  }

  // 4. Top 5 Stock Concentration
  if (analytics.top5StockExposure >= THRESHOLDS.TOP5_CONCENTRATION) {
    insights.push({
      id: 'top5-concentration',
      type: 'info',
      title: 'Top 5 Concentration Alert',
      description: `Your top 5 individual stock holdings represent ${formatPercent(analytics.top5StockExposure)} of total equity value. Despite owning ${analytics.fundsCount} funds, the top 5 companies drive a substantial share of performance.`,
      metricLabel: 'Top 5 Weight',
      metricValue: formatPercent(analytics.top5StockExposure),
      actionScreen: 'stock-exposure',
      actionText: 'Review Top Stocks',
    });
  }

  // 5. Unclassified or Missing Disclosures Warning
  if (analytics.unclassifiedWeight >= THRESHOLDS.UNCLASSIFIED_WARNING) {
    insights.push({
      id: 'unclassified-holdings',
      type: 'warning',
      title: 'Unclassified Underlying Securities Detected',
      description: `${formatPercent(analytics.unclassifiedWeight)} of your portfolio's underlying holdings lack standardized sector or market-cap classification. Review data management to enrich disclosures.`,
      metricLabel: 'Unclassified',
      metricValue: formatPercent(analytics.unclassifiedWeight),
      actionScreen: 'data-management',
      actionText: 'Inspect Data Quality',
    });
  }

  // 6. Non-contemporaneous Reporting Dates
  if (analytics.hasReportingDateMismatch) {
    insights.push({
      id: 'date-mismatch-warning',
      type: 'info',
      title: 'Mixed Portfolio Disclosure Dates',
      description: `Fund reporting dates range from ${analytics.earliestDate} to ${analytics.latestDate}. Overlap and exposure metrics are based on the latest available disclosures and should be viewed with date differences in mind.`,
      actionScreen: 'data-management',
      actionText: 'View Reporting Dates',
    });
  }

  // 7. Well-Diversified Positive Observation
  if (
    analytics.top5StockExposure < 0.30 &&
    analytics.portfolioWeightedOverlap < 0.20 &&
    analytics.uniqueStocksCount > 60
  ) {
    insights.push({
      id: 'healthy-diversification',
      type: 'positive',
      title: 'Strong Multi-Fund Diversification',
      description: `Low portfolio overlap (${formatPercent(analytics.portfolioWeightedOverlap)}) and a broad distribution of ${analytics.uniqueStocksCount} unique companies with top 5 exposure contained under 30%.`,
      metricLabel: 'Effective Stocks',
      metricValue: analytics.effectiveHoldings.toFixed(1),
      actionScreen: 'what-if',
      actionText: 'Simulate Replacements',
    });
  }

  return insights;
}
