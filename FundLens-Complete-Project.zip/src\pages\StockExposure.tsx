// Stock Exposure Analysis Screen for FundLens

import React, { useState } from 'react';
import {
  PortfolioAnalyticsResult,
  PortfolioFundItem,
  EffectiveStockExposure,
} from '../types';
import { formatPercent, formatINR } from '../lib/formatting';
import { TopStocksChart } from '../components/charts/TopStocksChart';
import { StockDrilldownModal } from '../components/modals/StockDrilldownModal';
import {
  Search,
  Building2,
  TrendingUp,
  Info,
  ShieldAlert,
  ArrowUpDown,
  Filter,
} from 'lucide-react';

interface StockExposureProps {
  analytics: PortfolioAnalyticsResult;
  portfolio: PortfolioFundItem[];
  initialFilter?: string;
}

export const StockExposure: React.FC<StockExposureProps> = ({
  analytics,
  portfolio,
  initialFilter = '',
}) => {
  const [searchTerm, setSearchTerm] = useState(initialFilter);
  const [selectedSector, setSelectedSector] = useState<string>('ALL');
  const [selectedMarketCap, setSelectedMarketCap] = useState<string>('ALL');
  const [sortField, setSortField] = useState<'effectiveWeight' | 'name' | 'funds'>('effectiveWeight');
  const [sortAsc, setSortAsc] = useState(false);
  const [selectedStockForModal, setSelectedStockForModal] = useState<EffectiveStockExposure | null>(null);

  // Available unique sectors & market caps for filtering
  const sectors = Array.from(new Set(analytics.stockExposures.map((s) => s.sector))).sort();
  const marketCaps = ['Large-Cap', 'Mid-Cap', 'Small-Cap', 'Unclassified'];

  // Filtering
  const filteredStocks = analytics.stockExposures
    .filter((s) => {
      const matchesSearch =
        s.securityName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.isin.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.sector.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesSector = selectedSector === 'ALL' || s.sector === selectedSector;
      const matchesCap = selectedMarketCap === 'ALL' || s.marketCap === selectedMarketCap;
      return matchesSearch && matchesSector && matchesCap;
    })
    .sort((a, b) => {
      let diff = 0;
      if (sortField === 'effectiveWeight') diff = b.effectiveWeight - a.effectiveWeight;
      else if (sortField === 'name') diff = a.securityName.localeCompare(b.securityName);
      else if (sortField === 'funds') diff = b.fundCount - a.fundCount;
      return sortAsc ? -diff : diff;
    });

  const toggleSort = (field: 'effectiveWeight' | 'name' | 'funds') => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Hero Header */}
      <div className="bg-white p-6 rounded-2xl border border-border shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-primary-light text-primary border border-primary-border">
                Look-Through Holdings
              </span>
              <span className="text-xs text-text-sub font-mono">E_i = ∑ a_j · w_ij</span>
            </div>
            <h2 className="text-2xl font-bold text-text-main tracking-tight">
              Effective Underlying Stock Exposures
            </h2>
            <p className="text-xs text-text-sub mt-1 max-w-2xl">
              Inspect your actual percentage exposure to each underlying company after combining all mutual funds and their reported weights.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-3 bg-[#F8F9FA] rounded-xl border border-border text-right">
              <span className="text-[11px] text-text-sub block font-medium">Unique Companies</span>
              <span className="text-xl font-bold text-text-main tabular-nums">
                {analytics.uniqueStocksCount}
              </span>
            </div>
          </div>
        </div>

        {/* Summary Badges: Top 5, Top 10, Top 20 */}
        <div className="mt-6 pt-6 border-t border-border grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-3.5 rounded-xl bg-slate-50 border border-border">
            <span className="text-[11px] font-medium text-text-sub block">Top 5 Concentration</span>
            <span className="text-2xl font-bold text-text-main tabular-nums">
              {formatPercent(analytics.top5StockExposure)}
            </span>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 border border-border">
            <span className="text-[11px] font-medium text-text-sub block">Top 10 Concentration</span>
            <span className="text-2xl font-bold text-text-main tabular-nums">
              {formatPercent(analytics.top10StockExposure)}
            </span>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 border border-border">
            <span className="text-[11px] font-medium text-text-sub block">Top 20 Concentration</span>
            <span className="text-2xl font-bold text-text-main tabular-nums">
              {formatPercent(analytics.top20StockExposure)}
            </span>
          </div>
          <div className="p-3.5 rounded-xl bg-primary-light/50 border border-primary-border">
            <span className="text-[11px] font-medium text-text-sub block">Highest Single Exposure</span>
            <span className="text-2xl font-bold text-primary tabular-nums">
              {analytics.highestStockExposure ? formatPercent(analytics.highestStockExposure.weight) : '—'}
            </span>
            <span className="text-[11px] text-text-sub truncate block mt-0.5">
              {analytics.highestStockExposure?.securityName}
            </span>
          </div>
        </div>
      </div>

      {/* Top 10 Bar Chart */}
      <div className="bg-white rounded-2xl border border-border p-5 shadow-xs">
        <div className="mb-3">
          <h3 className="text-sm font-bold text-text-main">Top 10 Effective Stock Exposures</h3>
          <p className="text-[11px] text-text-sub">
            Gold bars indicate single-stock weights exceeding 8%. Click any bar to open full fund contribution drill-down.
          </p>
        </div>
        <TopStocksChart
          stockExposures={analytics.stockExposures}
          maxDisplay={10}
          onStockClick={(stock) => setSelectedStockForModal(stock)}
        />
      </div>

      {/* Searchable Company Level Table */}
      <div className="bg-white rounded-2xl border border-border shadow-xs overflow-hidden">
        {/* Table Filters */}
        <div className="p-4 border-b border-border flex flex-wrap items-center justify-between gap-3 bg-[#F8F9FA]">
          <div className="flex flex-wrap items-center gap-2">
            {/* Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-text-sub absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search company or ISIN..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 pr-3 py-1.5 rounded-lg border border-border text-xs text-text-main bg-white focus:outline-hidden focus:border-primary w-56"
              />
            </div>

            {/* Sector dropdown */}
            <select
              value={selectedSector}
              onChange={(e) => setSelectedSector(e.target.value)}
              className="p-1.5 rounded-lg border border-border text-xs text-text-main bg-white focus:outline-hidden focus:border-primary"
            >
              <option value="ALL">All Sectors ({sectors.length})</option>
              {sectors.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>

            {/* Market Cap dropdown */}
            <select
              value={selectedMarketCap}
              onChange={(e) => setSelectedMarketCap(e.target.value)}
              className="p-1.5 rounded-lg border border-border text-xs text-text-main bg-white focus:outline-hidden focus:border-primary"
            >
              <option value="ALL">All Market Caps</option>
              {marketCaps.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div className="text-xs text-text-sub font-medium">
            Showing <strong className="text-text-main">{filteredStocks.length}</strong> of{' '}
            <strong className="text-text-main">{analytics.uniqueStocksCount}</strong> companies
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#F8F9FA]/60 text-text-sub border-b border-border">
              <tr>
                <th
                  onClick={() => toggleSort('name')}
                  className="p-3.5 font-semibold cursor-pointer hover:text-text-main"
                >
                  <div className="inline-flex items-center gap-1">
                    <span>Security Name</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="p-3.5 font-semibold">ISIN Identifier</th>
                <th className="p-3.5 font-semibold">Sector</th>
                <th className="p-3.5 font-semibold">Market Cap</th>
                <th
                  onClick={() => toggleSort('funds')}
                  className="p-3.5 font-semibold text-center cursor-pointer hover:text-text-main"
                >
                  <div className="inline-flex items-center justify-center gap-1">
                    <span>Funds Holding</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                {/* Dynamically show portfolio funds columns if <= 4 funds */}
                {portfolio.length <= 4 &&
                  portfolio.map((p) => (
                    <th
                      key={`th-fund-${p.id}`}
                      className="p-3.5 font-semibold text-right text-[11px] truncate max-w-[100px]"
                      title={p.fundName}
                    >
                      {p.fundName.slice(0, 12)}...
                    </th>
                  ))}
                <th
                  onClick={() => toggleSort('effectiveWeight')}
                  className="p-3.5 font-semibold text-right cursor-pointer hover:text-primary text-primary"
                >
                  <div className="inline-flex items-center gap-1">
                    <span>Effective Exposure</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="p-3.5 font-semibold text-center">Drill Down</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filteredStocks.map((stock, idx) => (
                <tr
                  key={`stock-${stock.isin}-${idx}`}
                  onClick={() => setSelectedStockForModal(stock)}
                  className="hover:bg-slate-50/80 cursor-pointer transition-colors"
                >
                  <td className="p-3.5 font-semibold text-text-main flex items-center gap-2">
                    <Building2 className="w-3.5 h-3.5 text-text-sub shrink-0" />
                    <span>{stock.securityName}</span>
                  </td>
                  <td className="p-3.5 font-mono text-[11px] text-text-sub">
                    {stock.isin !== 'N/A' ? (
                      stock.isin
                    ) : (
                      <span className="text-amber-700 font-sans italic">Undisclosed</span>
                    )}
                  </td>
                  <td className="p-3.5 text-text-sub">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 border border-slate-200">
                      {stock.sector}
                    </span>
                  </td>
                  <td className="p-3.5 text-text-sub">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        stock.marketCap === 'Large-Cap'
                          ? 'bg-blue-50 text-blue-800 border border-blue-200'
                          : stock.marketCap === 'Mid-Cap'
                          ? 'bg-teal-50 text-teal-800 border border-teal-200'
                          : stock.marketCap === 'Small-Cap'
                          ? 'bg-amber-50 text-amber-800 border border-amber-200'
                          : 'bg-slate-100 text-slate-700 border border-slate-200'
                      }`}
                    >
                      {stock.marketCap}
                    </span>
                  </td>
                  <td className="p-3.5 text-center tabular-nums">
                    <span className="inline-block px-2 py-0.5 rounded-md font-semibold bg-slate-100 text-text-main text-[11px]">
                      {stock.fundCount} / {portfolio.length}
                    </span>
                  </td>

                  {/* Fund-level contributions if <= 4 funds */}
                  {portfolio.length <= 4 &&
                    portfolio.map((p) => {
                      const match = stock.fundContributions.find((fc) => fc.fundName === p.fundName);
                      return (
                        <td
                          key={`cell-${p.id}-${stock.isin}`}
                          className="p-3.5 text-right tabular-nums text-text-sub text-[11px]"
                        >
                          {match ? formatPercent(match.contributionWeight) : '—'}
                        </td>
                      );
                    })}

                  <td className="p-3.5 text-right tabular-nums font-bold text-primary text-xs">
                    {formatPercent(stock.effectiveWeight)}
                  </td>
                  <td className="p-3.5 text-center">
                    <span className="text-[10px] font-semibold text-primary bg-primary-light px-2 py-1 rounded-md border border-primary-border">
                      Breakdown
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Drill-down Modal */}
      <StockDrilldownModal
        stock={selectedStockForModal}
        onClose={() => setSelectedStockForModal(null)}
      />
    </div>
  );
};
