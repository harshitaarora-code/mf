// MFAPI.in Live Indian Mutual Fund Data Client & Analytics Service
// Fetches official AMFI NAV disclosures and scheme metadata

export interface MFSchemeSearchResult {
  schemeCode: number;
  schemeName: string;
}

export interface MFSchemeMeta {
  fund_house: string;
  scheme_type: string;
  scheme_category: string;
  scheme_code: number;
  scheme_name: string;
  isin_growth?: string | null;
  isin_div_reinvestment?: string | null;
}

export interface MFNavRecord {
  date: string; // DD-MM-YYYY
  nav: string;
}

export interface MFSchemeDetails {
  meta: MFSchemeMeta;
  data: MFNavRecord[];
  status: string;
}

export interface MFSchemeMetrics {
  latestNav: number;
  latestDate: string;
  previousNav?: number;
  dailyChange?: number;
  dailyPercentChange?: number;
  high52w?: number;
  low52w?: number;
  allTimeHigh?: number;
  return1M?: number;
  return6M?: number;
  return1Y?: number;
  return3Y?: number;
}

// In-memory cache to prevent redundant network calls
const searchCache = new Map<string, MFSchemeSearchResult[]>();
const detailsCache = new Map<number | string, MFSchemeDetails>();

// Curated popular Indian mutual fund schemes for one-click exploration
export const POPULAR_INDIAN_SCHEMES: { code: number; name: string; category: string; fundHouse: string }[] = [
  {
    code: 122640,
    name: 'Parag Parikh Flexi Cap Fund - Regular Plan - Growth',
    category: 'Flexi Cap Fund',
    fundHouse: 'PPFAS Mutual Fund',
  },
  {
    code: 100122,
    name: 'HDFC Balanced Advantage Fund - Growth Option',
    category: 'Balanced Advantage',
    fundHouse: 'HDFC Mutual Fund',
  },
  {
    code: 119551,
    name: 'Tata Digital India Fund - Regular Plan - Growth',
    category: 'Sectoral / Thematic',
    fundHouse: 'Tata Mutual Fund',
  },
  {
    code: 125488,
    name: 'Bandhan Sterling Value Fund - Regular Plan - Growth',
    category: 'Value Fund',
    fundHouse: 'Bandhan Mutual Fund',
  },
  {
    code: 120503,
    name: 'Axis Small Cap Fund - Regular Plan - Growth',
    category: 'Small Cap Fund',
    fundHouse: 'Axis Mutual Fund',
  },
  {
    code: 118224,
    name: 'Kotak Emerging Equity Scheme - Growth',
    category: 'Mid Cap Fund',
    fundHouse: 'Kotak Mahindra Mutual Fund',
  },
  {
    code: 120585,
    name: 'ICICI Prudential Bluechip Fund - Growth',
    category: 'Large Cap Fund',
    fundHouse: 'ICICI Prudential Mutual Fund',
  },
  {
    code: 112090,
    name: 'Nippon India Small Cap Fund - Growth Plan',
    category: 'Small Cap Fund',
    fundHouse: 'Nippon India Mutual Fund',
  },
];

/**
 * Parses date string in "DD-MM-YYYY" format to Date object
 */
function parseMFDate(dateStr: string): Date {
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    return new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]));
  }
  return new Date(dateStr);
}

/**
 * Searches Indian mutual funds via MFAPI.in
 */
export async function searchMutualFunds(query: string): Promise<MFSchemeSearchResult[]> {
  const cleanQuery = query.trim();
  if (cleanQuery.length < 2) return [];

  const cacheKey = cleanQuery.toLowerCase();
  if (searchCache.has(cacheKey)) {
    return searchCache.get(cacheKey)!;
  }

  // Attempt proxy endpoint first, fallback to direct
  const endpoints = [
    `/api/mfapi/mf/search?q=${encodeURIComponent(cleanQuery)}`,
    `https://api.mfapi.in/mf/search?q=${encodeURIComponent(cleanQuery)}`,
  ];

  for (const url of endpoints) {
    try {
      const response = await fetch(url, { headers: { Accept: 'application/json' } });
      if (response.ok) {
        const data: MFSchemeSearchResult[] = await response.json();
        searchCache.set(cacheKey, data);
        return data;
      }
    } catch {
      // try next endpoint
    }
  }

  return [];
}

/**
 * Fetches full scheme details and historical NAV disclosures from MFAPI.in
 */
export async function fetchSchemeDetails(schemeCode: number | string): Promise<MFSchemeDetails | null> {
  const code = String(schemeCode);
  if (detailsCache.has(code)) {
    return detailsCache.get(code)!;
  }

  const endpoints = [
    `/api/mfapi/mf/${code}`,
    `https://api.mfapi.in/mf/${code}`,
  ];

  for (const url of endpoints) {
    try {
      const response = await fetch(url, { headers: { Accept: 'application/json' } });
      if (response.ok) {
        const details: MFSchemeDetails = await response.json();
        if (details && details.meta) {
          detailsCache.set(code, details);
          return details;
        }
      }
    } catch {
      // try next endpoint
    }
  }

  return null;
}

/**
 * Computes performance, historical returns, and 52-week ranges from NAV series
 */
export function calculateNavMetrics(records: MFNavRecord[]): MFSchemeMetrics | null {
  if (!records || records.length === 0) return null;

  const validRecords = records
    .map((r) => ({
      date: parseMFDate(r.date),
      rawDate: r.date,
      nav: parseFloat(r.nav),
    }))
    .filter((r) => !isNaN(r.nav) && r.nav > 0)
    .sort((a, b) => b.date.getTime() - a.date.getTime()); // Newest first

  if (validRecords.length === 0) return null;

  const latest = validRecords[0];
  const previous = validRecords[1];

  const dailyChange = previous ? latest.nav - previous.nav : undefined;
  const dailyPercentChange = previous ? (dailyChange! / previous.nav) : undefined;

  // 52-week window (365 days)
  const oneYearAgoTime = latest.date.getTime() - 365 * 24 * 60 * 60 * 1000;
  const records52W = validRecords.filter((r) => r.date.getTime() >= oneYearAgoTime);

  let high52w = latest.nav;
  let low52w = latest.nav;
  for (const r of records52W) {
    if (r.nav > high52w) high52w = r.nav;
    if (r.nav < low52w) low52w = r.nav;
  }

  // All-time high
  const allTimeHigh = Math.max(...validRecords.map((r) => r.nav));

  // Helper to find NAV closest to a target date
  const findNavAtTime = (targetTime: number): number | undefined => {
    // Find first record on or before target time
    const rec = validRecords.find((r) => r.date.getTime() <= targetTime);
    return rec?.nav;
  };

  const nav1MAgo = findNavAtTime(latest.date.getTime() - 30 * 24 * 60 * 60 * 1000);
  const nav6MAgo = findNavAtTime(latest.date.getTime() - 180 * 24 * 60 * 60 * 1000);
  const nav1YAgo = findNavAtTime(latest.date.getTime() - 365 * 24 * 60 * 60 * 1000);
  const nav3YAgo = findNavAtTime(latest.date.getTime() - 3 * 365 * 24 * 60 * 60 * 1000);

  const return1M = nav1MAgo ? (latest.nav - nav1MAgo) / nav1MAgo : undefined;
  const return6M = nav6MAgo ? (latest.nav - nav6MAgo) / nav6MAgo : undefined;
  const return1Y = nav1YAgo ? (latest.nav - nav1YAgo) / nav1YAgo : undefined;
  // 3Y CAGR = (latest / 3Y_ago)^(1/3) - 1
  const return3Y = nav3YAgo ? Math.pow(latest.nav / nav3YAgo, 1 / 3) - 1 : undefined;

  return {
    latestNav: latest.nav,
    latestDate: latest.rawDate,
    previousNav: previous?.nav,
    dailyChange,
    dailyPercentChange,
    high52w,
    low52w,
    allTimeHigh,
    return1M,
    return6M,
    return1Y,
    return3Y,
  };
}
