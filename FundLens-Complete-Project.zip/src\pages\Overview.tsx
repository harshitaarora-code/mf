// Overview Dashboard Screen for FundLens

import React from 'react';
import {
  PortfolioAnalyticsResult,
  PortfolioFundItem,
  Holding,
  PortfolioInsight,
  EffectiveStockExposure,
} from '../types';
import { KpiCard } from '../components/cards/KpiCard';
import { InsightCard } from '../components/cards/InsightCard';
import { AllocationDonut } from '../components/charts/AllocationDonut';
import { SectorBarChart } from '../components/charts/SectorBarChart';
import { TopStocksChart } from '../components/charts/TopStocksChart';
import { OverlapHeatmap } from '../components/charts/OverlapHeatmap';
import { formatPercent, formatCompactINR } from '../lib/formatting';
import { ArrowRight, Sparkles, Layers, SlidersHorizontal, ShieldCheck } from 'lucide-react';

interface OverviewProps {
  analytics: PortfolioAnalyticsResult;
  portfolio: PortfolioFundItem[];
  allHoldings: Holding[];
  insights: PortfolioInsight[];
  onNavigate: (screen: string, filter?: string) => void;
  onStockClick: (stock: EffectiveStockExposure) => void;
  onSelectPair: (fundA: string, fundB: string) => void;
}

export const Overview: React.FC<OverviewProps> = ({
  analytics,
  portfolio,
  allHoldings,
  insights,
  onNavigate,
  onStockClick,
  onSelectPair,
}) => {
  return (
    <div className="space-y-6 pb-12">
      {/* Screen Hero Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-border shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-primary-light text-primary border border-primary-border">
              Institutional Intelligence
            </span>
            <span className="text-xs text-text-sub">• Deterministic Engine</span>
          </div>
          <h2 className="text-2xl font-bold text-text-main tracking-tight">
            Portfolio Diversification Overview
          </h2>
          <p className="text-xs text-text-sub mt-1 max-w-2xl">
            Uncover the true underlying stock holdings, pairwise fund overlap, and sector concentration across your Indian mutual fund investments.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => onNavigate('portfolio')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-slate-50 text-text-main border border-border rounded-xl text-xs font-semibold shadow-2xs transition-all"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-text-sub" />
            <span>Manage Funds</span>
          </button>
          <button
            onClick={() => onNavigate('what-if')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-primary hover:bg-primary-hover text-white rounded-xl text-xs font-semibold shadow-sm transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Simulate Replacement</span>
          </button>
        </div>
      </div>

      {/* 6 Core KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {/* KPI 1: Portfolio Valuation */}
        <KpiCard
          label="Portfolio Value"
          value={
            analytics.mode === 'valuation' && analytics.totalValuation !== null
              ? formatCompactINR(analytics.totalValuation)
              : 'Target Weights'
          }
          subValue={
            analytics.mode === 'valuation'
              ? 'Valuation-based portfolio'
              : 'Normalized 100% weights'
          }
          tooltip="Total portfolio valuation if amounts were entered, or allocation-based analysis if using target percentage weights."
          contextTag={{
            text: analytics.mode === 'valuation' ? 'INR Mode' : 'Weight Mode',
            type: 'neutral',
          }}
          onClick={() => onNavigate('portfolio')}
        />

        {/* KPI 2: Mutual Funds Count */}
        <KpiCard
          label="Mutual Funds"
          value={`${analytics.fundsCount}`}
          subValue="Active schemes in portfolio"
          tooltip="Total number of mutual fund schemes currently included in this portfolio analysis."
          contextTag={{ text: 'Schemes', type: 'accent' }}
          onClick={() => onNavigate('portfolio')}
        />

        {/* KPI 3: Unique Underlying Stocks */}
        <KpiCard
          label="Unique Stocks"
          value={`${analytics.uniqueStocksCount}`}
          subValue={`Effective: ${analytics.effectiveHoldings > 0 ? analytics.effectiveHoldings.toFixed(1) : '—'}`}
          tooltip="Total distinct companies held across all portfolio funds after deduplicating common holdings. Effective holdings derived via 1/HHI."
          contextTag={{
            text: analytics.uniqueStocksCount > 60 ? 'Broad Universe' : 'Focused',
            type: analytics.uniqueStocksCount > 60 ? 'positive' : 'neutral',
          }}
          onClick={() => onNavigate('stock-exposure')}
        />

        {/* KPI 4: Portfolio Weighted Overlap */}
        <KpiCard
          label="Portfolio Overlap"
          value={formatPercent(analytics.portfolioWeightedOverlap)}
          subValue="Allocation-weighted average"
          tooltip="Portfolio-level average pairwise stock overlap weighted by your individual fund allocations."
          contextTag={{
            text: analytics.portfolioWeightedOverlap > 0.35 ? 'High Overlap' : 'Diversified',
            type: analytics.portfolioWeightedOverlap > 0.35 ? 'warning' : 'positive',
          }}
          onClick={() => onNavigate('fund-overlap')}
        />

        {/* KPI 5: Largest Single Stock Exposure */}
        <KpiCard
          label="Largest Single Stock"
          value={
            analytics.highestStockExposure
              ? formatPercent(analytics.highestStockExposure.weight)
              : '—'
          }
          subValue={
            analytics.highestStockExposure
              ? analytics.highestStockExposure.securityName
              : 'None'
          }
          tooltip="The maximum aggregate exposure to any individual company across all mutual funds you own."
          contextTag={{
            text:
              analytics.highestStockExposure && analytics.highestStockExposure.weight >= 0.08
                ? 'Elevated'
                : 'Balanced',
            type:
              analytics.highestStockExposure && analytics.highestStockExposure.weight >= 0.08
                ? 'warning'
                : 'positive',
          }}
          onClick={() => onNavigate('stock-exposure')}
        />

        {/* KPI 6: Largest Sector Exposure */}
        <KpiCard
          label="Largest Sector"
          value={
            analytics.highestSectorExposure
              ? formatPercent(analytics.highestSectorExposure.weight)
              : '—'
          }
          subValue={
            analytics.highestSectorExposure
              ? analytics.highestSectorExposure.sector
              : 'None'
          }
          tooltip="The highest sector weight across your total portfolio equity investments."
          contextTag={{
            text:
              analytics.highestSectorExposure && analytics.highestSectorExposure.weight >= 0.30
                ? 'Concentrated'
                : 'Normal',
            type:
              analytics.highestSectorExposure && analytics.highestSectorExposure.weight >= 0.30
                ? 'warning'
                : 'neutral',
          }}
          onClick={() => onNavigate('sector-analysis')}
        />
      </div>

      {/* Main Charts Grid: Portfolio Allocation & Sector Exposure */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Allocation Donut Card */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-border p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-text-main">Fund Allocation</h3>
              <p className="text-[11px] text-text-sub">Portfolio weights across selected mutual funds</p>
            </div>
            <button
              onClick={() => onNavigate('portfolio')}
              className="text-xs text-primary font-semibold hover:underline inline-flex items-center gap-1"
            >
              <span>Edit</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <AllocationDonut
            portfolio={portfolio}
            totalValuation={analytics.totalValuation}
          />
        </div>

        {/* Sector Exposure Bar Chart Card */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-border p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-sm font-bold text-text-main">Effective Sector Exposure</h3>
              <p className="text-[11px] text-text-sub">Combined industry weighting across all underlying securities</p>
            </div>
            <button
              onClick={() => onNavigate('sector-analysis')}
              className="text-xs text-primary font-semibold hover:underline inline-flex items-center gap-1"
            >
              <span>All Sectors</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <SectorBarChart sectors={analytics.sectorExposures} maxDisplay={7} />
        </div>
      </div>

      {/* Secondary Grid: Top Stocks Exposure & Overlap Heatmap */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Top Underlying Stock Exposures */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-border p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-sm font-bold text-text-main">Top Underlying Stocks</h3>
              <p className="text-[11px] text-text-sub">Highest effective exposure companies (click bar for drill-down)</p>
            </div>
            <button
              onClick={() => onNavigate('stock-exposure')}
              className="text-xs text-primary font-semibold hover:underline inline-flex items-center gap-1"
            >
              <span>View All {analytics.uniqueStocksCount}</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <TopStocksChart
            stockExposures={analytics.stockExposures}
            maxDisplay={8}
            onStockClick={onStockClick}
          />
        </div>

        {/* Pairwise Fund Overlap Heatmap */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-border p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold text-text-main">Fund Overlap Matrix</h3>
              <p className="text-[11px] text-text-sub">Pairwise common holdings weight O(A,B) = ∑ min(w_A, w_B)</p>
            </div>
            <button
              onClick={() => onNavigate('fund-overlap')}
              className="text-xs text-primary font-semibold hover:underline inline-flex items-center gap-1"
            >
              <span>Compare Pair</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <OverlapHeatmap
            portfolio={portfolio}
            allHoldings={allHoldings}
            onSelectPair={onSelectPair}
          />
        </div>
      </div>

      {/* Portfolio Rule-Based Insights Section */}
      <div className="bg-white rounded-2xl border border-border p-5 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-primary">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-text-main">Portfolio Intelligence & Rule-Based Observations</h3>
              <p className="text-[11px] text-text-sub">
                Deterministic findings generated strictly from calculated exposure thresholds and holdings disclosures
              </p>
            </div>
          </div>
        </div>

        {insights.length === 0 ? (
          <div className="p-6 text-center text-xs text-text-sub bg-[#F8F9FA] rounded-xl border border-border">
            No active observations for current portfolio.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {insights.map((insight) => (
              <InsightCard
                key={insight.id}
                insight={insight}
                onActionClick={(screen, filter) => onNavigate(screen, filter)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
