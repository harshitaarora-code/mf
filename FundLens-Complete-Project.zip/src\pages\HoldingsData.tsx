// Holdings & Data Management Screen with Drag-and-Drop CSV Upload and Deep Validation

import React, { useState, useRef } from 'react';
import {
  Holding,
  FundMeta,
  CSVValidationResult,
} from '../types';
import { parseHoldingsCSV, generateCSVTemplate, ColumnMapping } from '../lib/csvParser';
import { formatPercent, formatDate } from '../lib/formatting';
import {
  UploadCloud,
  FileSpreadsheet,
  Download,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Database,
  RefreshCw,
  FileText,
  ShieldCheck,
  ChevronRight,
  Layers,
  Globe,
} from 'lucide-react';
import { MFSchemeExplorerModal } from '../components/common/MFSchemeExplorerModal';

interface HoldingsDataProps {
  currentHoldings: Holding[];
  availableFunds: FundMeta[];
  isCustomUpload: boolean;
  onImportValidHoldings: (holdings: Holding[], funds: FundMeta[]) => void;
  onResetToLiveIndianData: () => void;
  onAddFundMeta?: (fund: FundMeta) => void;
}

export const HoldingsData: React.FC<HoldingsDataProps> = ({
  currentHoldings,
  availableFunds,
  isCustomUpload,
  onImportValidHoldings,
  onResetToLiveIndianData,
  onAddFundMeta,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [csvRawText, setCsvRawText] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);
  const [customMapping, setCustomMapping] = useState<ColumnMapping | null>(null);
  const [parseResult, setParseResult] = useState<ReturnType<typeof parseHoldingsCSV> | null>(null);
  const [uploadSuccessMessage, setUploadSuccessMessage] = useState<string>('');
  const [isMfapiModalOpen, setIsMfapiModalOpen] = useState(false);

  // Handle file read
  const processFile = (file: File) => {
    setFileName(file.name);
    setUploadSuccessMessage('');
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      setCsvRawText(text);
      const parsed = parseHoldingsCSV(text);
      setCustomMapping(parsed.inferredMapping);
      setParseResult(parsed);
    };
    reader.readAsText(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  // Re-run validation on manual mapping change
  const handleMappingFieldChange = (key: keyof ColumnMapping, headerName: string) => {
    if (!customMapping || !csvRawText) return;
    const updatedMapping = { ...customMapping, [key]: headerName };
    setCustomMapping(updatedMapping);
    const revalidated = parseHoldingsCSV(csvRawText, updatedMapping);
    setParseResult(revalidated);
  };

  // Confirm Import
  const handleConfirmImport = () => {
    if (!parseResult || !parseResult.validationResult.isValid) return;

    const newHoldings = parseResult.validationResult.parsedHoldings;
    const discoveredFundNames = parseResult.validationResult.fundsDiscovered;

    // Generate FundMeta for imported funds
    const newFunds: FundMeta[] = discoveredFundNames.map((name) => {
      const fundHoldings = newHoldings.filter((h) => h.fundName === name);
      const weightSum = fundHoldings.reduce((sum, h) => sum + h.weight, 0);
      const date = fundHoldings[0]?.reportingDate || new Date().toISOString().slice(0, 10);
      return {
        fundName: name,
        category: 'Uploaded Scheme',
        reportingDate: date,
        reportedWeightTotal: weightSum,
        isNormalized: false,
        holdingsCount: fundHoldings.length,
        completenessScore: parseResult.validationResult.completenessScore,
        dataQualityIssues: [],
      };
    });

    onImportValidHoldings(newHoldings, newFunds);
    setUploadSuccessMessage(
      `Successfully imported ${newHoldings.length} holdings across ${newFunds.length} mutual fund schemes.`
    );
  };

  // Download template
  const handleDownloadTemplate = () => {
    const csvContent = generateCSVTemplate();
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'fundlens_holdings_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Hero Header */}
      <div className="bg-white p-6 rounded-2xl border border-border shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-primary-light text-primary border border-primary-border">
                Data Management
              </span>
              <span className="text-xs text-text-sub">• Strict Validation Pipeline</span>
            </div>
            <h2 className="text-2xl font-bold text-text-main tracking-tight">
              Mutual Fund Holdings & CSV Import
            </h2>
            <p className="text-xs text-text-sub mt-1 max-w-2xl">
              Import mutual fund portfolio disclosures via CSV. The engine validates identifiers, flags non-numeric weights, detects duplicate records, and computes data completeness.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={handleDownloadTemplate}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-slate-50 text-text-main border border-border rounded-xl text-xs font-semibold shadow-2xs transition-all"
            >
              <Download className="w-3.5 h-3.5 text-primary" />
              <span>Download CSV Template</span>
            </button>
            <button
              onClick={onResetToLiveIndianData}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-text-main rounded-xl text-xs font-semibold transition-all"
            >
              <RefreshCw className="w-3.5 h-3.5 text-text-sub" />
              <span>Reload Live Indian Funds</span>
            </button>
          </div>
        </div>

        {/* Current Data Source Banner */}
        <div className="mt-6 pt-6 border-t border-border flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-primary" />
            <span className="text-text-sub">Active Data Source:</span>
            <strong className="text-text-main">
              {isCustomUpload ? 'User Uploaded Disclosures' : 'Live Indian Mutual Funds (AMFI Disclosures via MFAPI)'}
            </strong>
          </div>
          <div className="text-text-sub">
            Loaded <strong className="text-text-main">{availableFunds.length}</strong> funds and{' '}
            <strong className="text-text-main">{currentHoldings.length}</strong> individual holding records.
          </div>
        </div>
      </div>

      {/* Live Indian Mutual Funds (MFAPI.in) Data Integration Card */}
      <div className="bg-gradient-to-r from-emerald-500/10 via-teal-500/5 to-transparent rounded-2xl border border-primary-border p-6 shadow-xs bg-white">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-primary-light border border-primary-border flex items-center justify-center text-primary shrink-0 mt-0.5">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-text-main">
                  Live Indian Mutual Funds Registry & NAV Engine
                </h3>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300">
                  MFAPI.in Live Feed
                </span>
              </div>
              <p className="text-xs text-text-sub mt-1 max-w-2xl leading-relaxed">
                Connect live to official AMFI daily Net Asset Values, historical performance tracking (1Y/3Y CAGR), and official scheme codes across all 40,000+ Indian mutual fund schemes.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsMfapiModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-primary hover:bg-primary-hover text-white rounded-xl text-xs font-semibold shadow-xs transition-all shrink-0"
          >
            <Globe className="w-4 h-4" />
            <span>Launch Live Scheme Explorer</span>
          </button>
        </div>
      </div>

      {/* CSV Drag & Drop Upload Card */}
      <div className="bg-white rounded-2xl border border-border p-6 shadow-xs">
        <h3 className="text-sm font-bold text-text-main mb-3">Upload Mutual Fund Holdings CSV</h3>

        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all ${
            isDragging
              ? 'border-primary bg-primary-light/40'
              : 'border-border hover:border-primary-border hover:bg-slate-50/60'
          }`}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".csv,text/csv"
            className="hidden"
          />
          <div className="w-12 h-12 rounded-2xl bg-primary-light border border-primary-border mx-auto flex items-center justify-center text-primary mb-3">
            <UploadCloud className="w-6 h-6" />
          </div>
          <h4 className="text-sm font-semibold text-text-main">
            {fileName ? fileName : 'Choose a CSV file or drag and drop'}
          </h4>
          <p className="text-xs text-text-sub mt-1">
            Accepts official AMC factsheet disclosures, AMFI portfolio dumps, or custom CSV exports
          </p>
          <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-text-sub text-[11px] font-medium">
            <span>Required headers: Fund Name, Security Name or ISIN, Weight %</span>
          </div>
        </div>

        {uploadSuccessMessage && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{uploadSuccessMessage}</span>
          </div>
        )}
      </div>

      {/* Parsing & Validation Review */}
      {parseResult && (
        <div className="space-y-6">
          {/* Validation Metrics Banner */}
          <div className="bg-white rounded-2xl border border-border p-5 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
              <div>
                <h3 className="text-sm font-bold text-text-main">CSV Parsing & Quality Verification</h3>
                <p className="text-[11px] text-text-sub">
                  Review discovered columns, row validation status, and data completeness
                </p>
              </div>

              <button
                onClick={handleConfirmImport}
                disabled={!parseResult.validationResult.isValid}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-primary hover:bg-primary-hover disabled:bg-slate-200 disabled:text-slate-400 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors shrink-0"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Confirm & Apply Import ({parseResult.validationResult.validRows} rows)</span>
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-border">
                <span className="text-[11px] font-medium text-text-sub block">Total Rows Read</span>
                <span className="text-2xl font-bold text-text-main tabular-nums">
                  {parseResult.validationResult.totalRows}
                </span>
              </div>
              <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200">
                <span className="text-[11px] font-medium text-emerald-800 block">Valid Holding Records</span>
                <span className="text-2xl font-bold text-emerald-800 tabular-nums">
                  {parseResult.validationResult.validRows}
                </span>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 border border-border">
                <span className="text-[11px] font-medium text-text-sub block">Schemes Discovered</span>
                <span className="text-2xl font-bold text-text-main tabular-nums">
                  {parseResult.validationResult.fundsDiscovered.length}
                </span>
              </div>
              <div className="p-3.5 rounded-xl bg-primary-light/40 border border-primary-border">
                <span className="text-[11px] font-medium text-text-sub block">Completeness Score</span>
                <span className="text-2xl font-bold text-primary tabular-nums">
                  {parseResult.validationResult.completenessScore}%
                </span>
              </div>
            </div>

            {/* Error & Warning Lists */}
            {parseResult.validationResult.errors.length > 0 && (
              <div className="mt-4 p-4 rounded-xl bg-red-50 border border-red-200 text-xs text-red-900 space-y-2">
                <div className="flex items-center gap-2 font-bold text-red-800">
                  <XCircle className="w-4 h-4 text-red-600" />
                  <span>{parseResult.validationResult.errors.length} Critical Validation Errors (Import Blocked)</span>
                </div>
                <div className="max-h-36 overflow-y-auto space-y-1 pr-2">
                  {parseResult.validationResult.errors.map((err, i) => (
                    <div key={`err-${i}`} className="text-[11px]">
                      • Row {err.row}: <strong>{err.field}</strong> — {err.message}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {parseResult.validationResult.warnings.length > 0 && (
              <div className="mt-4 p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 space-y-2">
                <div className="flex items-center gap-2 font-bold text-amber-800">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  <span>{parseResult.validationResult.warnings.length} Quality Warnings (Audited)</span>
                </div>
                <div className="max-h-36 overflow-y-auto space-y-1 pr-2">
                  {parseResult.validationResult.warnings.map((warn, i) => (
                    <div key={`warn-${i}`} className="text-[11px]">
                      • {warn.row ? `Row ${warn.row}: ` : ''}
                      {warn.message}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Column Mapping Fallback Card */}
          {customMapping && (
            <div className="bg-white rounded-2xl border border-border p-5 shadow-xs">
              <h3 className="text-xs font-bold text-text-main uppercase tracking-wider mb-2">
                Column Header Mapping
              </h3>
              <p className="text-xs text-text-sub mb-4">
                Verify or adjust which CSV column maps to each required holding attribute.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {Object.keys(customMapping).map((key) => (
                  <div key={key} className="space-y-1">
                    <label className="text-[11px] font-semibold text-text-sub capitalize">
                      {key.replace(/([A-Z])/g, ' $1')}
                    </label>
                    <select
                      value={(customMapping as any)[key] || ''}
                      onChange={(e) =>
                        handleMappingFieldChange(key as keyof ColumnMapping, e.target.value)
                      }
                      className="w-full p-2 rounded-lg border border-border text-xs text-text-main bg-white focus:outline-hidden focus:border-primary"
                    >
                      <option value="">-- (Not Mapped) --</option>
                      {parseResult.headers.map((h) => (
                        <option key={h} value={h}>
                          {h}
                        </option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* First Rows Preview Table */}
          <div className="bg-white rounded-2xl border border-border shadow-xs overflow-hidden">
            <div className="p-4 border-b border-border bg-[#F8F9FA]">
              <h3 className="text-xs font-bold text-text-main uppercase tracking-wider">
                Raw File Preview (First 5 Rows)
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#F8F9FA]/60 text-text-sub border-b border-border">
                  <tr>
                    {parseResult.headers.map((h) => (
                      <th key={h} className="p-3 font-semibold">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {parseResult.previewRows.map((row, idx) => (
                    <tr key={`prev-${idx}`} className="hover:bg-slate-50/50">
                      {parseResult.headers.map((h) => (
                        <td key={`c-${idx}-${h}`} className="p-3 text-text-main truncate max-w-[180px]">
                          {String(row[h] || '')}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Live Indian Mutual Funds Explorer Modal */}
      <MFSchemeExplorerModal
        isOpen={isMfapiModalOpen}
        onClose={() => setIsMfapiModalOpen(false)}
        onAddSchemeToPortfolio={(scheme) => {
          if (onAddFundMeta) {
            onAddFundMeta({
              fundName: scheme.fundName,
              schemeCode: scheme.schemeCode,
              category: scheme.category,
              reportingDate: new Date().toISOString().slice(0, 10),
              reportedWeightTotal: 1.0,
              isNormalized: true,
              holdingsCount: 0,
              completenessScore: 100,
              dataQualityIssues: [],
            });
          }
        }}
      />
    </div>
  );
};
