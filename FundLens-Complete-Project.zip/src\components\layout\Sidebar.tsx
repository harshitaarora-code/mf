// Application Sidebar with Navigation, Brand Identity, and System Status

import React from 'react';
import {
  LayoutDashboard,
  Briefcase,
  GitCompare,
  TrendingUp,
  BarChart3,
  Sparkles,
  FileSpreadsheet,
  BookOpen,
  PieChart,
} from 'lucide-react';

export type NavScreenId =
  | 'overview'
  | 'portfolio'
  | 'fund-overlap'
  | 'stock-exposure'
  | 'sector-analysis'
  | 'what-if'
  | 'data-management'
  | 'methodology';

interface SidebarProps {
  currentScreen: NavScreenId;
  onSelectScreen: (screen: NavScreenId) => void;
  fundsCount: number;
  uniqueStocksCount: number;
}

interface NavItem {
  id: NavScreenId;
  label: string;
  icon: React.ElementType;
  badge?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentScreen,
  onSelectScreen,
  fundsCount,
  uniqueStocksCount,
}) => {
  const navItems: NavItem[] = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'portfolio', label: 'My Portfolio', icon: Briefcase, badge: `${fundsCount}` },
    { id: 'fund-overlap', label: 'Fund Overlap', icon: GitCompare },
    { id: 'stock-exposure', label: 'Stock Exposure', icon: TrendingUp, badge: `${uniqueStocksCount}` },
    { id: 'sector-analysis', label: 'Sector Analysis', icon: BarChart3 },
    { id: 'what-if', label: 'What-If Simulator', icon: Sparkles },
    { id: 'data-management', label: 'Holdings & Data', icon: FileSpreadsheet },
    { id: 'methodology', label: 'Methodology', icon: BookOpen },
  ];

  return (
    <aside className="w-64 bg-white border-r border-border flex flex-col shrink-0 select-none min-h-screen">
      {/* Brand Header */}
      <div className="p-5 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-primary-light border border-primary-border flex items-center justify-center text-primary shadow-xs">
            <PieChart className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-base tracking-tight text-text-main">FundLens</span>
              <span className="text-[10px] font-semibold bg-primary-light text-primary px-1.5 py-0.2 rounded border border-primary-border">
                PRO
              </span>
            </div>
            <p className="text-[11px] text-text-sub leading-tight">Mutual Fund Intelligence</p>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        <div className="px-3 pb-2 text-[11px] font-semibold tracking-wider text-text-sub uppercase">
          Analytics & Intelligence
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentScreen === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectScreen(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-primary-light text-primary font-semibold border border-primary-border shadow-xs'
                  : 'text-text-main hover:bg-slate-50 hover:text-text-main'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon className={`w-4 h-4 ${isActive ? 'text-primary' : 'text-text-sub'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-semibold tabular-nums ${
                    isActive
                      ? 'bg-primary text-white'
                      : 'bg-[#F2F4F7] text-text-sub'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Portfolio Status Card at Bottom */}
      <div className="p-3.5 border-t border-border">
        <div className="p-3 bg-[#F8F9FA] rounded-xl border border-border">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-semibold text-text-main">Portfolio Scope</span>
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          </div>
          <div className="space-y-1 text-[11px] text-text-sub">
            <div className="flex justify-between">
              <span>Included Funds:</span>
              <span className="font-medium text-text-main tabular-nums">{fundsCount} schemes</span>
            </div>
            <div className="flex justify-between">
              <span>Unique Stocks:</span>
              <span className="font-medium text-text-main tabular-nums">{uniqueStocksCount} stocks</span>
            </div>
          </div>
          <div className="mt-2.5 pt-2 border-t border-border/80 flex items-center gap-1.5 text-[10px] text-emerald-700">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>AMFI Live Data (MFAPI)</span>
          </div>
        </div>
      </div>
    </aside>
  );
};
