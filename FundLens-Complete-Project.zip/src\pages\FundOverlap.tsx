// Dedicated Fund Overlap Analysis Screen for FundLens

import React, { useState } from 'react';
import { Holding, PortfolioFundItem } from '../types';
import { calculatePairwiseOverlap } from '../lib/analytics';
import { formatPercent, formatDate } from '../lib/formatting';
import { OverlapHeatmap } from '../components/charts/OverlapHeatmap';
import {
  GitCompare,
  ArrowRight,
  ShieldAlert,
  Search,
  ArrowUpDown,
  Building2,
  PieChart,
  HelpCircle,
} from 'lucide-react';

interface FundOverlapProps {
  portfolio: PortfolioFundItem[];
  allHoldings: Holding[];
  initialFundA?: string;
  initialFundB?: string;
}

export const FundOverlap: React.FC<FundOverlapProps> = ({
  portfolio,
  allHoldings,
  initialFundA,
  initialFundB,
}) => {
  // Available funds from portfolio, or all funds with holdings
  const fundNames = Array.from(new Set(allHoldings.map((h) => h.fundName)));

  const defaultA = initialFundA || portfolio[0]?.fundName || fundNames[0] || '';
  const defaultB =
    initialFundB ||
    (portfolio.length > 1 ? portfolio[1].fundName : fundNames.find((f) => f !== defaultA) || '');

  const [fundA, setFundA] = useState<string>(defaultA);
  const [fundB, setFundB] = useState<string>(defaultB);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<'contribution' | 'weightA' | 'weightB'>('contribution');
  const [sortAsc, setSortAsc] = useState(false);
  const [activeTab, setActiveTab] = useState<'shared' | 'uniqueA' | 'uniqueB' | 'sectors'>('shared');

  const pairData =
    fundA && fundB && fundA !== fundB
      ? calculatePairwiseOverlap(fundA, fundB, allHoldings)
      : null;

  // Filter & sort shared holdings
  const filteredShared = (pairData?.sharedHoldings || [])
    .filter(
      (s) =>
        s.securityName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.isin.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.sector.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      let diff = 0;
      if (sortField === 'contribution') diff = b.overlapContribution - a.overlapContribution;
      else if (sortField === 'weightA') diff = b.weightInA - a.weightInA;
      else if (sortField === 'weightB') diff = b.weightInB - a.weightInB;
      return sortAsc ? -diff : diff;
    });

  const toggleSort = (field: 'contribution' | 'weightA' | 'weightB') => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Screen Title & Pair Selector */}
      <div className="bg-white p-6 rounded-2xl border border-border shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-primary-light text-primary border border-primary-border">
                Pairwise Overlap Engine
              </span>
              <span className="text-xs text-text-sub font-mono">O(A,B) = ∑ min(w_A, w_B)</span>
            </div>
            <h2 className="text-2xl font-bold text-text-main tracking-tight">
              Fund Overlap & Shared Holdings Analysis
            </h2>
            <p className="text-xs text-text-sub mt-1 max-w-2xl">
              Inspect common stock holdings, individual overlap contributions, and sector differences between any two mutual fund schemes.
            </p>
          </div>

          {/* Scheme Selectors Box */}
          <div className="flex items-center gap-2 bg-[#F8F9FA] p-2 rounded-xl border border-border">
            <select
              value={fundA}
              onChange={(e) => setFundA(e.target.value)}
              className="p-2 rounded-lg border border-border text-xs font-semibold text-text-main bg-white max-w-[200px] truncate focus:outline-hidden focus:border-primary"
            >
              {fundNames.map((name) => (
                <option key={`a-${name}`} value={name}>
                  {name}
                </option>
              ))}
            </select>

            <span className="text-xs font-bold text-text-sub px-1">vs</span>

            <select
              value={fundB}
              onChange={(e) => setFundB(e.target.value)}
              className="p-2 rounded-lg border border-border text-xs font-semibold text-text-main bg-white max-w-[200px] truncate focus:outline-hidden focus:border-primary"
            >
              {fundNames.map((name) => (
                <option key={`b-${name}`} value={name}>
                  {name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Pair Summary Metrics */}
        {pairData && (
          <div className="mt-6 pt-6 border-t border-border grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-primary-light/50 border border-primary-border">
              <span className="text-xs font-medium text-text-sub block">Pairwise Overlap Weight</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl font-extrabold text-primary tabular-nums">
                  {formatPercent(pairData.overlapWeight)}
                </span>
                <span className="text-xs text-text-sub">by portfolio weight</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-white border border-border">
              <span className="text-xs font-medium text-text-sub block">Shared Companies</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl font-bold text-text-main tabular-nums">
                  {pairData.sharedHoldings.length}
                </span>
                <span className="text-xs text-text-sub">common stocks</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-white border border-border">
              <span className="text-xs font-medium text-text-sub block">Unique to Scheme A</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-bold text-text-main tabular-nums">
                  {pairData.uniqueToA.length}
                </span>
                <span className="text-xs text-text-sub">stocks ({formatPercent(pairData.uniqueToA.reduce((s, u) => s + u.weight, 0))})</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-white border border-border">
              <span className="text-xs font-medium text-text-sub block">Unique to Scheme B</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-bold text-text-main tabular-nums">
                  {pairData.uniqueToB.length}
                </span>
                <span className="text-xs text-text-sub">stocks ({formatPercent(pairData.uniqueToB.reduce((s, u) => s + u.weight, 0))})</span>
              </div>
            </div>
          </div>
        )}

        {/* Contemporaneous Warning */}
        {pairData && !pairData.isContemporaneous && (
          <div className="mt-4 p-3 bg-amber-50 rounded-xl border border-amber-200 flex items-center gap-2.5 text-xs text-amber-900">
            <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <strong>Disclosure Date Mismatch:</strong> {pairData.fundA} ({formatDate(pairData.reportingDateA)}) vs {pairData.fundB} ({formatDate(pairData.reportingDateB)}). Holdings disclosures represent periodic snapshot dates, not real-time positions.
            </span>
          </div>
        )}
      </div>

      {/* Deep-Dive Tabs (Shared Holdings, Unique to A, Unique to B, Sector Deltas) */}
      {pairData && (
        <div className="bg-white rounded-2xl border border-border shadow-xs overflow-hidden">
          {/* Tabs bar */}
          <div className="p-4 border-b border-border flex flex-wrap items-center justify-between gap-4 bg-[#F8F9FA]">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('shared')}
                className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'shared'
                    ? 'bg-white text-primary shadow-xs border border-border'
                    : 'text-text-sub hover:text-text-main'
                }`}
              >
                Shared Holdings ({pairData.sharedHoldings.length})
              </button>
              <button
                onClick={() => setActiveTab('uniqueA')}
                className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'uniqueA'
                    ? 'bg-white text-primary shadow-xs border border-border'
                    : 'text-text-sub hover:text-text-main'
                }`}
              >
                Unique to {pairData.fundA.slice(0, 15)}... ({pairData.uniqueToA.length})
              </button>
              <button
                onClick={() => setActiveTab('uniqueB')}
                className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'uniqueB'
                    ? 'bg-white text-primary shadow-xs border border-border'
                    : 'text-text-sub hover:text-text-main'
                }`}
              >
                Unique to {pairData.fundB.slice(0, 15)}... ({pairData.uniqueToB.length})
              </button>
              <button
                onClick={() => setActiveTab('sectors')}
                className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'sectors'
                    ? 'bg-white text-primary shadow-xs border border-border'
                    : 'text-text-sub hover:text-text-main'
                }`}
              >
                Sector Deltas ({pairData.sectorDeltas.length})
              </button>
            </div>

            {/* Search filter */}
            {activeTab === 'shared' && (
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-text-sub absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Filter shared stocks..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8 pr-3 py-1.5 rounded-lg border border-border text-xs text-text-main bg-white focus:outline-hidden focus:border-primary w-52"
                />
              </div>
            )}
          </div>

          {/* TAB 1: Shared Holdings Table */}
          {activeTab === 'shared' && (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#F8F9FA]/60 text-text-sub border-b border-border">
                  <tr>
                    <th className="p-3.5 font-semibold">Security Name</th>
                    <th className="p-3.5 font-semibold">ISIN</th>
                    <th className="p-3.5 font-semibold">Sector</th>
                    <th
                      onClick={() => toggleSort('weightA')}
                      className="p-3.5 font-semibold text-right cursor-pointer hover:text-text-main"
                    >
                      <div className="inline-flex items-center gap-1">
                        <span>Weight in {pairData.fundA.slice(0, 14)}...</span>
                        <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                    <th
                      onClick={() => toggleSort('weightB')}
                      className="p-3.5 font-semibold text-right cursor-pointer hover:text-text-main"
                    >
                      <div className="inline-flex items-center gap-1">
                        <span>Weight in {pairData.fundB.slice(0, 14)}...</span>
                        <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                    <th
                      onClick={() => toggleSort('contribution')}
                      className="p-3.5 font-semibold text-right cursor-pointer hover:text-primary text-primary"
                    >
                      <div className="inline-flex items-center gap-1">
                        <span>Overlap Contribution min(A,B)</span>
                        <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredShared.map((item, idx) => (
                    <tr key={`shared-${idx}`} className="hover:bg-slate-50/50">
                      <td className="p-3.5 font-semibold text-text-main flex items-center gap-2">
                        <Building2 className="w-3.5 h-3.5 text-text-sub shrink-0" />
                        <span>{item.securityName}</span>
                      </td>
                      <td className="p-3.5 font-mono text-[11px] text-text-sub">
                        {item.isin}
                      </td>
                      <td className="p-3.5 text-text-sub">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 border border-slate-200">
                          {item.sector}
                        </span>
                      </td>
                      <td className="p-3.5 text-right tabular-nums text-text-main">
                        {formatPercent(item.weightInA)}
                      </td>
                      <td className="p-3.5 text-right tabular-nums text-text-main">
                        {formatPercent(item.weightInB)}
                      </td>
                      <td className="p-3.5 text-right tabular-nums font-bold text-primary bg-primary-light/20">
                        {formatPercent(item.overlapContribution)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* TAB 2: Unique to Fund A */}
          {activeTab === 'uniqueA' && (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#F8F9FA]/60 text-text-sub border-b border-border">
                  <tr>
                    <th className="p-3.5 font-semibold">Security Name</th>
                    <th className="p-3.5 font-semibold">ISIN</th>
                    <th className="p-3.5 font-semibold">Sector</th>
                    <th className="p-3.5 font-semibold text-right">Weight in {pairData.fundA}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {pairData.uniqueToA.map((item, idx) => (
                    <tr key={`ua-${idx}`} className="hover:bg-slate-50/50">
                      <td className="p-3.5 font-semibold text-text-main">{item.securityName}</td>
                      <td className="p-3.5 font-mono text-[11px] text-text-sub">{item.isin}</td>
                      <td className="p-3.5 text-text-sub">{item.sector}</td>
                      <td className="p-3.5 text-right tabular-nums font-semibold text-text-main">
                        {formatPercent(item.weight)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* TAB 3: Unique to Fund B */}
          {activeTab === 'uniqueB' && (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#F8F9FA]/60 text-text-sub border-b border-border">
                  <tr>
                    <th className="p-3.5 font-semibold">Security Name</th>
                    <th className="p-3.5 font-semibold">ISIN</th>
                    <th className="p-3.5 font-semibold">Sector</th>
                    <th className="p-3.5 font-semibold text-right">Weight in {pairData.fundB}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {pairData.uniqueToB.map((item, idx) => (
                    <tr key={`ub-${idx}`} className="hover:bg-slate-50/50">
                      <td className="p-3.5 font-semibold text-text-main">{item.securityName}</td>
                      <td className="p-3.5 font-mono text-[11px] text-text-sub">{item.isin}</td>
                      <td className="p-3.5 text-text-sub">{item.sector}</td>
                      <td className="p-3.5 text-right tabular-nums font-semibold text-text-main">
                        {formatPercent(item.weight)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* TAB 4: Sector Deltas */}
          {activeTab === 'sectors' && (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#F8F9FA]/60 text-text-sub border-b border-border">
                  <tr>
                    <th className="p-3.5 font-semibold">Sector</th>
                    <th className="p-3.5 font-semibold text-right">Weight in {pairData.fundA}</th>
                    <th className="p-3.5 font-semibold text-right">Weight in {pairData.fundB}</th>
                    <th className="p-3.5 font-semibold text-right">Absolute Difference</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {pairData.sectorDeltas.map((sd, idx) => (
                    <tr key={`sd-${idx}`} className="hover:bg-slate-50/50">
                      <td className="p-3.5 font-semibold text-text-main">{sd.sector}</td>
                      <td className="p-3.5 text-right tabular-nums text-text-main">
                        {formatPercent(sd.weightInA)}
                      </td>
                      <td className="p-3.5 text-right tabular-nums text-text-main">
                        {formatPercent(sd.weightInB)}
                      </td>
                      <td className="p-3.5 text-right tabular-nums font-bold text-amber-700">
                        {formatPercent(sd.delta)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Full Portfolio Overlap Heatmap Section */}
      <div className="bg-white rounded-2xl border border-border p-5 shadow-xs">
        <div className="mb-4">
          <h3 className="text-sm font-bold text-text-main">NxN Portfolio Heatmap Matrix</h3>
          <p className="text-[11px] text-text-sub">
            Click any cell to compare those two funds directly above
          </p>
        </div>
        <OverlapHeatmap
          portfolio={portfolio}
          allHoldings={allHoldings}
          onSelectPair={(a, b) => {
            setFundA(a);
            setFundB(b);
          }}
        />
      </div>
    </div>
  );
};
