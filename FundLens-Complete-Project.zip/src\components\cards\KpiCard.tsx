// KPI Card Component with Tooltip and Contextual Metrics

import React, { useState } from 'react';
import { HelpCircle } from 'lucide-react';

interface KpiCardProps {
  label: string;
  value: string;
  subValue?: string;
  tooltip: string;
  contextTag?: {
    text: string;
    type: 'positive' | 'warning' | 'neutral' | 'accent';
  };
  onClick?: () => void;
}

export const KpiCard: React.FC<KpiCardProps> = ({
  label,
  value,
  subValue,
  tooltip,
  contextTag,
  onClick,
}) => {
  const [showTooltip, setShowTooltip] = useState(false);

  const getTagClasses = () => {
    switch (contextTag?.type) {
      case 'positive':
        return 'bg-emerald-50 text-emerald-800 border-emerald-200';
      case 'warning':
        return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'accent':
        return 'bg-primary-light text-primary border-primary-border';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div
      onClick={onClick}
      className={`bg-white rounded-xl border border-border p-4 shadow-xs relative transition-all ${
        onClick ? 'cursor-pointer hover:border-primary-border hover:shadow-sm' : ''
      }`}
    >
      {/* Label and Tooltip Trigger */}
      <div className="flex items-center justify-between gap-1 mb-2">
        <span className="text-xs font-medium text-text-sub">{label}</span>
        <div className="relative">
          <button
            type="button"
            onMouseEnter={() => setShowTooltip(true)}
            onMouseLeave={() => setShowTooltip(false)}
            onClick={(e) => {
              e.stopPropagation();
              setShowTooltip(!showTooltip);
            }}
            className="text-text-sub hover:text-text-main p-0.5 rounded transition-colors"
            aria-label="Information"
          >
            <HelpCircle className="w-3.5 h-3.5" />
          </button>

          {showTooltip && (
            <div className="absolute right-0 top-6 z-30 w-52 p-2.5 bg-[#172B4D] text-white text-[11px] rounded-lg shadow-lg leading-normal pointer-events-none">
              {tooltip}
            </div>
          )}
        </div>
      </div>

      {/* Primary KPI Value */}
      <div className="flex items-baseline gap-2">
        <span className="text-2xl font-bold text-text-main tracking-tight tabular-nums">
          {value}
        </span>
      </div>

      {/* Sub-value or Context Tag */}
      <div className="mt-2 flex items-center justify-between gap-2 min-h-[22px]">
        {subValue && (
          <span className="text-[11px] text-text-sub truncate" title={subValue}>
            {subValue}
          </span>
        )}
        {contextTag && (
          <span
            className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${getTagClasses()}`}
          >
            {contextTag.text}
          </span>
        )}
      </div>
    </div>
  );
};
