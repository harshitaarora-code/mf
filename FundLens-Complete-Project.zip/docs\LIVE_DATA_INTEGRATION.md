# FundLens Live Indian Mutual Funds Data Integration (AMFI / MFAPI.in)

FundLens connects directly to official Indian mutual fund feeds published daily under the Association of Mutual Funds in India (AMFI) regulatory framework.

---

## 1. Upstream Data Source: MFAPI.in

MFAPI.in provides an open REST API delivering verified daily Net Asset Values (NAV), scheme codes, and fund classifications for all Indian Asset Management Companies (AMCs).

### Primary Endpoints Used:

1. **Scheme Search:**
   - **Route:** `GET https://api.mfapi.in/mf/search?q={query}`
   - **Payload:** Returns a collection of matching schemes across all AMCs with their unique 6-digit AMFI scheme code and official name.
   - **Example:** Searching `"Parag Parikh"` yields scheme code `122640` (*Parag Parikh Flexi Cap Fund - Direct Plan - Growth*).

2. **Scheme Details & Historical NAV Series:**
   - **Route:** `GET https://api.mfapi.in/mf/{scheme_code}`
   - **Payload:** Returns fund metadata (`fund_house`, `scheme_type`, `scheme_category`) along with the full historical daily NAV time-series formatted as:
     ```json
     {
       "meta": {
         "fund_house": "PPFAS Mutual Fund",
         "scheme_type": "Open Ended Schemes",
         "scheme_category": "Equity Scheme - Flexi Cap Fund",
         "scheme_code": 122640,
         "scheme_name": "Parag Parikh Flexi Cap Fund - Direct Plan - Growth"
       },
       "data": [
         { "date": "16-10-2026", "nav": "82.4150" },
         { "date": "15-10-2026", "nav": "82.1120" }
       ]
     }
     ```

---

## 2. CORS Proxy Architecture

Because `api.mfapi.in` does not provide permissive cross-origin browser headers (`Access-Control-Allow-Origin: *`), FundLens incorporates an automated local Vite reverse-proxy configuration:

```typescript
// vite.config.ts
export default defineConfig({
  server: {
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: true,
    proxy: {
      '/api/mfapi': {
        target: 'https://api.mfapi.in',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/mfapi/, ''),
        secure: false,
      },
    },
  },
});
```

The frontend client in `src/lib/mfapi.ts` routes through `/api/mfapi` when running in the browser and automatically falls back to direct HTTPS calls in external environments.

---

## 3. NAV Return Calculations & Performance Metrics

From the raw NAV time series, FundLens calculates:
- **1-Month Return:** $\frac{\text{NAV}_{\text{latest}} - \text{NAV}_{30\text{d}}}{\text{NAV}_{30\text{d}}} \times 100\%$
- **6-Month Return:** $\frac{\text{NAV}_{\text{latest}} - \text{NAV}_{180\text{d}}}{\text{NAV}_{180\text{d}}} \times 100\%$
- **1-Year Return:** $\frac{\text{NAV}_{\text{latest}} - \text{NAV}_{365\text{d}}}{\text{NAV}_{365\text{d}}} \times 100\%$
- **3-Year Annualized CAGR:** $\left[\left(\frac{\text{NAV}_{\text{latest}}}{\text{NAV}_{3\text{y}}}\right)^{1/3} - 1\right] \times 100\%$
- **52-Week High & Low:** Evaluated across the trailing 252 trading sessions.

---

## 4. Separation of NAV and Monthly Portfolio Disclosures

- **Daily NAV:** Sourced in real time from AMFI/MFAPI.in daily feeds.
- **Underlying Portfolio Holdings:** Sourced from monthly regulatory AMC portfolio disclosures published in compliance with SEBI circulars.
- **Custom Portfolios:** Investors can upload custom CSV disclosures for any scheme, validated against ISIN and SEBI classification standards.
