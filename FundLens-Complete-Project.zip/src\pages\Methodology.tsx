// Mathematical Methodology & Data Disclosure Documentation Screen for FundLens

import React from 'react';
import {
  BookOpen,
  Sigma,
  Scale,
  ShieldCheck,
  AlertTriangle,
  FileSpreadsheet,
  Layers,
  Database,
  ExternalLink,
} from 'lucide-react';

export const Methodology: React.FC<MethodologyProps> = () => {
  return (
    <div className="space-y-8 pb-16 max-w-5xl mx-auto">
      {/* Title */}
      <div className="bg-white p-6 rounded-2xl border border-border shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-primary-light text-primary border border-primary-border">
            Quantitative Finance Reference
          </span>
          <span className="text-xs text-text-sub">• Open Analytical Standards</span>
        </div>
        <h2 className="text-2xl font-bold text-text-main tracking-tight">
          Financial Calculation Engine & Mathematical Methodology
        </h2>
        <p className="text-xs text-text-sub mt-1">
          Complete transparent documentation of all deterministic formulas, exposure aggregations, concentration indices, data validation rules, and structural assumptions used throughout FundLens.
        </p>
      </div>

      {/* Section 1: Weighted Overlap */}
      <div className="bg-white p-6 rounded-2xl border border-border shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary-light border border-primary-border flex items-center justify-center text-primary">
            <Sigma className="w-4 h-4" />
          </div>
          <h3 className="text-base font-bold text-text-main">
            1. Pairwise Weighted Overlap Methodology
          </h3>
        </div>

        <p className="text-xs text-text-sub leading-relaxed">
          Fund overlap measures the degree to which two mutual fund schemes invest in identical underlying securities. Rather than simply counting common company names, FundLens computes the <strong>weighted pairwise holdings overlap</strong>:
        </p>

        {/* Math Block */}
        <div className="p-4 bg-[#F8F9FA] rounded-xl border border-border font-mono text-xs text-text-main overflow-x-auto">
          O(A, B) = ∑_i min(w_i,A, w_i,B)
        </div>

        <div className="text-xs text-text-sub space-y-1.5 leading-relaxed">
          <p>Where:</p>
          <ul className="list-disc pl-5 space-y-1">
            <li><code className="text-text-main font-semibold">w_i,A</code> represents the reported decimal weight of security <em>i</em> in Scheme A.</li>
            <li><code className="text-text-main font-semibold">w_i,B</code> represents the reported decimal weight of security <em>i</em> in Scheme B.</li>
            <li>Missing securities in either fund are evaluated as 0% for that comparison.</li>
            <li>The formula is strictly symmetric: <code className="text-text-main font-semibold">O(A, B) = O(B, A)</code>.</li>
            <li>Self-overlap <code className="text-text-main font-semibold">O(A, A)</code> equals the exact sum of valid disclosed holdings weights (which is 100% only if normalized). FundLens never hardcodes 100%.</li>
          </ul>
        </div>
      </div>

      {/* Section 2: Effective Stock Exposure */}
      <div className="bg-white p-6 rounded-2xl border border-border shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600">
            <Layers className="w-4 h-4" />
          </div>
          <h3 className="text-base font-bold text-text-main">
            2. Effective Look-Through Stock Exposure
          </h3>
        </div>

        <p className="text-xs text-text-sub leading-relaxed">
          When an investor allocates capital across multiple funds, their true exposure to any single company is the weighted combination of that company’s allocation within each fund:
        </p>

        <div className="p-4 bg-[#F8F9FA] rounded-xl border border-border font-mono text-xs text-text-main overflow-x-auto">
          E_i = ∑_j (a_j · w_i,j)
        </div>

        <div className="text-xs text-text-sub space-y-1.5 leading-relaxed">
          <p>Where:</p>
          <ul className="list-disc pl-5 space-y-1">
            <li><code className="text-text-main font-semibold">a_j</code> is the investor's allocation to fund <em>j</em> in their portfolio (normalized so ∑ a_j = 1.0).</li>
            <li><code className="text-text-main font-semibold">w_i,j</code> is the weight of security <em>i</em> within fund <em>j</em>.</li>
          </ul>
          <p className="mt-2">
            <strong>Example:</strong> If a portfolio is 40% in Scheme A and 60% in Scheme B, and Stock X represents 8% of Scheme A and 6% of Scheme B, the effective portfolio exposure is:
          </p>
          <p className="font-mono bg-white p-2 rounded border border-border text-[11px]">
            E_X = (0.40 × 0.08) + (0.60 × 0.06) = 0.032 + 0.036 = 0.068 (6.80%)
          </p>
        </div>
      </div>

      {/* Section 3: Concentration & HHI */}
      <div className="bg-white p-6 rounded-2xl border border-border shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
            <Scale className="w-4 h-4" />
          </div>
          <h3 className="text-base font-bold text-text-main">
            3. Concentration Metrics: Herfindahl-Hirschman Index (HHI)
          </h3>
        </div>

        <p className="text-xs text-text-sub leading-relaxed">
          To assess whether underlying diversification is genuinely broad or concentrated in a handful of giant holdings, FundLens calculates the <strong>Herfindahl-Hirschman Index</strong> and its reciprocal, the <strong>Effective Number of Holdings</strong>:
        </p>

        <div className="p-4 bg-[#F8F9FA] rounded-xl border border-border font-mono text-xs text-text-main overflow-x-auto">
          HHI = ∑_i (p_i)^2 &emsp;&emsp; N_effective = 1 / HHI
        </div>

        <div className="text-xs text-text-sub space-y-1.5 leading-relaxed">
          <p>
            Here, <code className="text-text-main font-semibold">p_i</code> is the normalized proportion of each valid stock within the total identified equity universe (∑ p_i = 1.0).
          </p>
          <p>
            <strong>Standard Benchmark:</strong> If a portfolio held three stocks weighted at 50%, 30%, and 20%:
          </p>
          <p className="font-mono bg-white p-2 rounded border border-border text-[11px]">
            HHI = 0.50² + 0.30² + 0.20² = 0.25 + 0.09 + 0.04 = 0.38
            <br />
            N_effective = 1 / 0.38 ≈ 2.63 equivalent equal-weighted securities.
          </p>
        </div>
      </div>

      {/* Section 4: Data Treatment & Critical Limitations */}
      <div className="bg-white p-6 rounded-2xl border border-border shadow-xs space-y-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-600">
            <AlertTriangle className="w-4 h-4" />
          </div>
          <h3 className="text-base font-bold text-text-main">
            4. Data Freshness, Periodic Disclosures vs Real-Time NAV
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-50 border border-border space-y-2">
            <h4 className="font-bold text-text-main">Periodic Monthly Disclosures</h4>
            <p className="text-text-sub leading-relaxed">
              Under SEBI mutual fund regulations in India, Asset Management Companies (AMCs) disclose complete portfolio holdings periodically — typically on a monthly basis (within 10 days of month-end).
            </p>
            <p className="text-text-sub leading-relaxed">
              Mutual fund holdings are snapshot statements of portfolio composition as of that disclosure date. They do not represent intraday or real-time trading positions.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-border space-y-2">
            <h4 className="font-bold text-text-main">NAV vs Holdings Distinction</h4>
            <p className="text-text-sub leading-relaxed">
              Net Asset Value (NAV) represents the per-unit end-of-day market value of a scheme. Daily NAV data indicates scheme value change, but does <strong>not</strong> reveal which underlying stocks were bought or sold.
            </p>
            <p className="text-text-sub leading-relaxed">
              FundLens does not claim that an NAV API provides stock holdings. Overlap analysis requires verified portfolio disclosures.
            </p>
          </div>
        </div>

        {/* Scope and Non-Advisory Notice */}
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 leading-relaxed">
          <strong>Analytical Scope Notice:</strong> FundLens is an educational and analytical portfolio intelligence tool. Lower overlap does not guarantee lower risk, reduced volatility, or superior financial returns. Financial decisions should consider risk appetite, investment horizon, scheme expense ratios (TER), and fund manager strategies.
        </div>
      </div>

      {/* Section 5: Live MFAPI.in Data Integration Architecture */}
      <div className="bg-white p-6 rounded-2xl border border-border shadow-xs space-y-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-primary">
            <Database className="w-4 h-4" />
          </div>
          <h3 className="text-base font-bold text-text-main">
            5. MFAPI.in Live Indian Mutual Fund Data Integration
          </h3>
        </div>

        <p className="text-xs text-text-sub leading-relaxed">
          FundLens integrates directly with <strong>MFAPI.in</strong>, an open API service streaming official Association of Mutual Funds in India (AMFI) daily Net Asset Values and scheme classifications:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div className="p-3.5 rounded-xl bg-[#F8F9FA] border border-border space-y-1">
            <span className="font-bold text-text-main block">1. Scheme Registry & Search</span>
            <span className="font-mono text-[11px] text-text-sub block">GET /mf/search?q={'{query}'}</span>
            <p className="text-text-sub text-[11px]">
              Enables live instant search across all 40,000+ Indian mutual fund schemes by fund house, name, or AMFI code.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-[#F8F9FA] border border-border space-y-1">
            <span className="font-bold text-text-main block">2. Scheme Metadata & NAV Series</span>
            <span className="font-mono text-[11px] text-text-sub block">GET /mf/{'{schemeCode}'}</span>
            <p className="text-text-sub text-[11px]">
              Returns verified fund house name, SEBI category, ISIN, and the complete historical daily NAV series.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-[#F8F9FA] border border-border space-y-1">
            <span className="font-bold text-text-main block">3. Quantitative NAV Returns</span>
            <span className="font-mono text-[11px] text-text-sub block">CAGR & 52-Week Range</span>
            <p className="text-text-sub text-[11px]">
              The FundLens math engine computes annualized 3-year CAGR, 1-year absolute returns, and 52-week high/low ranges on demand.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

interface MethodologyProps {}
