# FundLens User Guide & Operational Manual

This guide walks through using FundLens to analyze mutual fund overlap, discover hidden portfolio concentration, and model what-if scenarios.

---

## 1. Navigating the Platform

The navigation sidebar grants access to all 8 core intelligence modules:
1. **Overview:** Portfolio executive summary, top overlapping fund pairs, concentration badges, and automated diagnostic insights.
2. **My Portfolio:** Manage scheme selection, adjust target weights, toggle between equal and custom weighting, and search AMFI registry.
3. **Fund Overlap:** Interactive $N \times N$ pairwise heatmap, side-by-side fund comparison, and detailed shared holdings table.
4. **Stock Exposure:** Look-through list of all underlying companies, sorted by portfolio weight, with drilldown modals showing which funds hold each stock.
5. **Sector Analysis:** Sector allocation bar chart and SEBI market cap breakdown (Large-Cap vs. Mid-Cap vs. Small-Cap).
6. **What-If Simulator:** Test adding, removing, or replacing funds to see immediate impact on HHI, effective holdings, and max pairwise overlap.
7. **Holdings & Data Management:** Review active fund holdings, download standard CSV templates, and drag-and-drop custom monthly disclosures.
8. **Methodology:** Complete in-app interactive reference of all mathematical formulas and academic definitions.

---

## 2. Managing Your Portfolio

### Adjusting Fund Weights
- In **My Portfolio**, use the weight sliders or numeric inputs to specify target allocations (e.g., $40\%$ in Parag Parikh Flexi Cap, $30\%$ in Mirae Asset Large & Midcap, $30\%$ in HDFC Mid Cap).
- If your weights do not sum to $100\%$, click **"Normalize Weights"** to automatically rescale them proportionately to $1.0$.

### Searching 40,000+ Indian Schemes
- Click **"Search live across all 40,000+ Indian Mutual Funds on MFAPI"**.
- Type any AMC or scheme name (e.g., *"Axis Small Cap"*, *"SBI Bluechip"*, *"ICICI Prudential Value"*).
- View live 90-day NAV charts, 1Y return, 3Y CAGR, and AMC metadata.
- Click **"Add Scheme to Portfolio"** to incorporate it into your active holdings.

---

## 3. Interpreting Overlap & Concentration Metrics

### How Much Overlap is "Too Much"?
- **$< 15\%$ Overlap:** Excellent diversification. The funds hold largely distinct companies and sectors.
- **$15\% - 30\%$ Overlap:** Healthy complement. Typical between a Large-Cap fund and a Flexi-Cap fund.
- **$30\% - 50\%$ Overlap:** Moderate redundancy. Review the shared top 10 holdings to verify whether you are inadvertently paying double management fees for identical equity exposure.
- **$> 50\%$ Overlap:** Severe redundancy. Holding both funds provides minimal incremental diversification.

### Effective Holdings ($N_{\text{eff}}$) vs. Nominal Holdings
If your portfolio displays **140 unique stocks** but an **effective holding count ($N_{\text{eff}}$) of 22**, your true risk is concentrated in just 22 stocks. The remaining 118 stocks each comprise fractional weights ($< 0.3\%$) that cannot meaningfully drive returns.

---

## 4. Uploading Custom Mutual Fund Disclosures

### CSV Format Requirements
The CSV upload engine accepts any standard monthly disclosure containing the following columns:

| Column Name | Required | Description | Example |
| :--- | :--- | :--- | :--- |
| **Fund Name** | Yes | Name of the mutual fund scheme | *Parag Parikh Flexi Cap Fund* |
| **Security Name** | Yes | Company or asset name | *HDFC Bank Ltd.* |
| **Weight %** | Yes | Weight percentage inside the fund | *8.12* |
| **ISIN** | Recommended | 12-character standard security identifier | *INE040A01034* |
| **Sector** | Optional | Industry classification | *Financial Services* |
| **Market Cap** | Optional | SEBI cap tier | *Large-Cap* |

A standard ready-to-use template can be downloaded directly from the **Holdings & Data Management** screen by clicking **"Download CSV Template"**.
