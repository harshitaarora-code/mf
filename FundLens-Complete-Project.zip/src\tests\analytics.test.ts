// Automated Unit Tests for FundLens Financial Calculation Engine
// Directly tests requirements in Section 6 and Section 12 of Master Build Prompt

import { describe, it, expect } from 'vitest';
import {
  calculatePairwiseOverlap,
  calculateSelfOverlap,
  calculateEffectiveStockExposures,
  calculateSectorExposures,
  calculateConcentrationMetrics,
  calculatePortfolioAnalytics,
  simulateFundReplacement,
  normalizeWeights,
} from '../lib/analytics';
import { Holding, PortfolioFundItem } from '../types';

describe('FundLens Financial Calculation Engine', () => {
  // Test 1: Example Weighted Overlap is 13%
  it('1. calculates weighted overlap of 13% for the master build prompt example', () => {
    // Stock X: 8% in Fund A, 7% in Fund B -> min is 7%
    // Stock Y: 6% in Fund A, 9% in Fund B -> min is 6%
    // Total overlap = 7% + 6% = 13% (0.13)
    const holdings: Holding[] = [
      { fundName: 'Fund A', securityName: 'Stock X', weight: 0.08 },
      { fundName: 'Fund A', securityName: 'Stock Y', weight: 0.06 },
      { fundName: 'Fund B', securityName: 'Stock X', weight: 0.07 },
      { fundName: 'Fund B', securityName: 'Stock Y', weight: 0.09 },
    ];

    const result = calculatePairwiseOverlap('Fund A', 'Fund B', holdings);
    expect(result.overlapWeight).toBeCloseTo(0.13, 6);
    expect(result.sharedHoldings).toHaveLength(2);
    expect(result.sharedHoldings[0].overlapContribution).toBeCloseTo(0.07, 6);
    expect(result.sharedHoldings[1].overlapContribution).toBeCloseTo(0.06, 6);
  });

  // Test 2: Effective Exposure is 6.8%
  it('2. calculates effective stock exposure of 6.8% for the master build prompt example', () => {
    // Portfolio: 40% in Fund A, 60% in Fund B
    // Stock X represents 8% in Fund A, 6% in Fund B
    // Effective exposure = (0.40 * 0.08) + (0.60 * 0.06) = 0.032 + 0.036 = 0.068 (6.8%)
    const portfolio: PortfolioFundItem[] = [
      { id: '1', fundName: 'Fund A', normalizedWeight: 0.40 },
      { id: '2', fundName: 'Fund B', normalizedWeight: 0.60 },
    ];

    const holdings: Holding[] = [
      { fundName: 'Fund A', securityName: 'Stock X', isin: 'INE123A01010', weight: 0.08, sector: 'Technology' },
      { fundName: 'Fund B', securityName: 'Stock X', isin: 'INE123A01010', weight: 0.06, sector: 'Technology' },
    ];

    const exposures = calculateEffectiveStockExposures(portfolio, holdings);
    expect(exposures).toHaveLength(1);
    expect(exposures[0].securityName).toBe('Stock X');
    expect(exposures[0].effectiveWeight).toBeCloseTo(0.068, 6);
  });

  // Test 3: Overlap is strictly symmetric
  it('3. ensures fund overlap is symmetric: O_{A,B} = O_{B,A}', () => {
    const holdings: Holding[] = [
      { fundName: 'Alpha Fund', securityName: 'HDFC Bank', isin: 'INE040A01034', weight: 0.095 },
      { fundName: 'Alpha Fund', securityName: 'Infosys', isin: 'INE009A01021', weight: 0.070 },
      { fundName: 'Beta Fund', securityName: 'HDFC Bank', isin: 'INE040A01034', weight: 0.062 },
      { fundName: 'Beta Fund', securityName: 'TCS', isin: 'INE467B01029', weight: 0.085 },
    ];

    const overlapAB = calculatePairwiseOverlap('Alpha Fund', 'Beta Fund', holdings);
    const overlapBA = calculatePairwiseOverlap('Beta Fund', 'Alpha Fund', holdings);

    expect(overlapAB.overlapWeight).toBeCloseTo(overlapBA.overlapWeight, 6);
    expect(overlapAB.sharedHoldings.length).toBe(overlapBA.sharedHoldings.length);
  });

  // Test 4: Self-overlap returns sum of valid weights without hardcoding 1.0
  it('4. calculates self-overlap as sum of valid holdings weights (not hardcoded to 1.0)', () => {
    // Fund with unnormalized holdings totaling 98.2%
    const unnormalizedHoldings: Holding[] = [
      { fundName: 'Fund X', securityName: 'Stock 1', weight: 0.50 },
      { fundName: 'Fund X', securityName: 'Stock 2', weight: 0.482 },
    ];

    const selfOverlap = calculateSelfOverlap('Fund X', unnormalizedHoldings);
    expect(selfOverlap).toBeCloseTo(0.982, 6);
    expect(selfOverlap).not.toBe(1.0);

    // Fund with normalized holdings totaling 100%
    const normalizedHoldings: Holding[] = [
      { fundName: 'Fund Y', securityName: 'Stock 1', weight: 0.60 },
      { fundName: 'Fund Y', securityName: 'Stock 2', weight: 0.40 },
    ];
    expect(calculateSelfOverlap('Fund Y', normalizedHoldings)).toBeCloseTo(1.0, 6);
  });

  // Test 5: Missing holdings do not silently become zero exposures
  it('5. handles missing or unrepresented funds cleanly without fabricated numbers', () => {
    const portfolio: PortfolioFundItem[] = [
      { id: '1', fundName: 'Fund With Holdings', normalizedWeight: 0.5 },
      { id: '2', fundName: 'Fund Without Holdings', normalizedWeight: 0.5 },
    ];
    const holdings: Holding[] = [
      { fundName: 'Fund With Holdings', securityName: 'Stock A', weight: 0.10 },
    ];

    const exposures = calculateEffectiveStockExposures(portfolio, holdings);
    expect(exposures).toHaveLength(1);
    expect(exposures[0].effectiveWeight).toBeCloseTo(0.05, 6);
    expect(exposures[0].fundCount).toBe(1);
  });

  // Test 6: Duplicate records are aggregated safely
  it('6. safely aggregates duplicate records for the same security within a fund', () => {
    const holdings: Holding[] = [
      { fundName: 'Fund A', securityName: 'Reliance', isin: 'INE002A01018', weight: 0.05 },
      { fundName: 'Fund A', securityName: 'Reliance Industries', isin: 'INE002A01018', weight: 0.03 },
      { fundName: 'Fund B', securityName: 'Reliance', isin: 'INE002A01018', weight: 0.07 },
    ];

    // Total in Fund A is 0.08, Fund B is 0.07 -> min is 0.07
    const overlap = calculatePairwiseOverlap('Fund A', 'Fund B', holdings);
    expect(overlap.overlapWeight).toBeCloseTo(0.07, 6);
  });

  // Test 7: Normalization helper correctly scales weights
  it('7. normalizes portfolio allocation weights correctly', () => {
    const rawWeights = [25, 25, 50];
    const normalized = normalizeWeights(rawWeights);
    expect(normalized).toEqual([0.25, 0.25, 0.5]);
    expect(normalized.reduce((a, b) => a + b, 0)).toBeCloseTo(1.0, 6);
  });

  // Test 8: Portfolio-level security exposures (Top 5, Top 10)
  it('8. calculates top 5 and top 10 exposures correctly', () => {
    const portfolio: PortfolioFundItem[] = [
      { id: '1', fundName: 'Mega Fund', normalizedWeight: 1.0 },
    ];
    const holdings: Holding[] = Array.from({ length: 15 }, (_, i) => ({
      fundName: 'Mega Fund',
      securityName: `Stock ${i + 1}`,
      weight: (15 - i) * 0.01, // 0.15, 0.14, 0.13, ...
    }));

    const result = calculatePortfolioAnalytics(portfolio, holdings);
    expect(result.uniqueStocksCount).toBe(15);
    // Top 5: 0.15 + 0.14 + 0.13 + 0.12 + 0.11 = 0.65
    expect(result.top5StockExposure).toBeCloseTo(0.65, 6);
    // Top 10: 0.65 + 0.10 + 0.09 + 0.08 + 0.07 + 0.06 = 1.05
    expect(result.top10StockExposure).toBeCloseTo(1.05, 6);
  });

  // Test 9: Sector exposures reconcile with classified and unclassified universe
  it('9. reconciles sector exposures with classified and unclassified universes', () => {
    const stockExposures = [
      {
        securityName: 'Bank A',
        isin: 'INE1',
        sector: 'Financials',
        marketCap: 'Large-Cap' as const,
        effectiveWeight: 0.40,
        fundContributions: [],
        fundCount: 1,
      },
      {
        securityName: 'Tech B',
        isin: 'INE2',
        sector: 'Technology',
        marketCap: 'Large-Cap' as const,
        effectiveWeight: 0.40,
        fundContributions: [],
        fundCount: 1,
      },
      {
        securityName: 'Unknown C',
        isin: 'INE3',
        sector: 'Unclassified',
        marketCap: 'Unclassified' as const,
        effectiveWeight: 0.20,
        fundContributions: [],
        fundCount: 1,
      },
    ];

    const sectors = calculateSectorExposures(stockExposures);
    expect(sectors).toHaveLength(3);

    const financials = sectors.find((s) => s.sector === 'Financials');
    const unclassified = sectors.find((s) => s.sector === 'Unclassified');

    expect(financials?.effectiveWeight).toBeCloseTo(0.40, 6);
    // Classified universe total is 0.40 + 0.40 = 0.80. Financials classified % = 0.40 / 0.80 = 0.50 (50%)
    expect(financials?.effectiveWeightClassified).toBeCloseTo(0.50, 6);
    expect(unclassified?.effectiveWeight).toBeCloseTo(0.20, 6);
    expect(unclassified?.effectiveWeightClassified).toBe(0);
  });

  // Test 10: What-if replacement matches fresh recalculation
  it('10. verifies what-if simulation performs an authentic recalculation', () => {
    const portfolio: PortfolioFundItem[] = [
      { id: '1', fundName: 'Fund Alpha', normalizedWeight: 0.60 },
      { id: '2', fundName: 'Fund Beta', normalizedWeight: 0.40 },
    ];

    const holdings: Holding[] = [
      { fundName: 'Fund Alpha', securityName: 'Stock 1', weight: 0.10 },
      { fundName: 'Fund Beta', securityName: 'Stock 2', weight: 0.10 },
      { fundName: 'Fund Gamma', securityName: 'Stock 3', weight: 0.15 },
    ];

    const simResult = simulateFundReplacement(
      portfolio,
      'Fund Beta',
      'Fund Gamma',
      holdings
    );

    // Fresh portfolio with Gamma instead of Beta
    const freshPortfolio: PortfolioFundItem[] = [
      { id: '1', fundName: 'Fund Alpha', normalizedWeight: 0.60 },
      { id: '2', fundName: 'Fund Gamma', normalizedWeight: 0.40 },
    ];
    const freshAnalytics = calculatePortfolioAnalytics(freshPortfolio, holdings);

    expect(simResult.simulated.uniqueStocksCount).toBe(freshAnalytics.uniqueStocksCount);
    expect(simResult.simulated.top5StockExposure).toBeCloseTo(freshAnalytics.top5StockExposure, 6);
    expect(simResult.simulated.portfolioWeightedOverlap).toBeCloseTo(freshAnalytics.portfolioWeightedOverlap, 6);
  });

  // Test 11: Empty datasets do not produce NaN or Infinity
  it('11. handles empty datasets safely without NaN or Infinity', () => {
    const result = calculatePortfolioAnalytics([], []);
    expect(result.uniqueStocksCount).toBe(0);
    expect(result.portfolioWeightedOverlap).toBe(0);
    expect(result.hhi).toBe(0);
    expect(result.effectiveHoldings).toBe(0);
    expect(isNaN(result.top5StockExposure)).toBe(false);
  });

  // Test 12: HHI and effective holdings with 50%, 30%, 20%
  it('12. calculates HHI = 0.38 and N_effective ≈ 2.6316 for weights [0.5, 0.3, 0.2]', () => {
    // 0.5^2 + 0.3^2 + 0.2^2 = 0.25 + 0.09 + 0.04 = 0.38
    // 1 / 0.38 = 2.6315789...
    const { hhi, effectiveHoldings } = calculateConcentrationMetrics([0.5, 0.3, 0.2]);

    expect(hhi).toBeCloseTo(0.38, 6);
    expect(effectiveHoldings).toBeCloseTo(1 / 0.38, 4);
    expect(effectiveHoldings).toBeCloseTo(2.6316, 3);
  });
});
