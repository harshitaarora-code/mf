// Sector and Market Cap Diversification Analysis Screen for FundLens

import React, { useState } from 'react';
import {
  PortfolioAnalyticsResult,
  SectorExposure,
  MarketCapExposure,
} from '../types';
import { SectorBarChart } from '../components/charts/SectorBarChart';
import { formatPercent } from '../lib/formatting';
import {
  PieChart as PieChartIcon,
  BarChart3,
  Layers,
  Building2,
  AlertCircle,
  ToggleLeft,
  ToggleRight,
  ShieldCheck,
} from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';

interface SectorAnalysisProps {
  analytics: PortfolioAnalyticsResult;
  onNavigateToStock: (sectorName: string) => void;
}

const SECTOR_PALETTE = [
  '#147D64',
  '#2563EB',
  '#0D9488',
  '#D97706',
  '#7C3AED',
  '#475569',
  '#DB2777',
  '#059669',
  '#EA580C',
  '#6366F1',
];

export const SectorAnalysis: React.FC<SectorAnalysisProps> = ({
  analytics,
  onNavigateToStock,
}) => {
  // Toggle between % of total portfolio vs % of classified equity universe
  const [useClassifiedOnly, setUseClassifiedOnly] = useState(false);

  // Prepare sector donut data
  const sectorPieData = analytics.sectorExposures.map((s, idx) => ({
    name: s.sector,
    value: useClassifiedOnly ? s.effectiveWeightClassified : s.effectiveWeight,
    rawWeight: s.effectiveWeight,
    stockCount: s.stockCount,
    color: s.sector === 'Unclassified' ? '#94A3B8' : SECTOR_PALETTE[idx % SECTOR_PALETTE.length],
  }));

  // Market Cap Donut Data
  const capColors: Record<string, string> = {
    'Large-Cap': '#2563EB',
    'Mid-Cap': '#0D9488',
    'Small-Cap': '#D97706',
    Other: '#7C3AED',
    Unclassified: '#94A3B8',
  };

  const marketCapPieData = analytics.marketCapExposures.map((c) => ({
    name: c.category,
    value: c.effectiveWeight,
    count: c.stockCount,
    color: capColors[c.category] || '#64748B',
  }));

  return (
    <div className="space-y-6 pb-12">
      {/* Hero Header */}
      <div className="bg-white p-6 rounded-2xl border border-border shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-primary-light text-primary border border-primary-border">
                Sector Diversification
              </span>
              <span className="text-xs text-text-sub font-mono">S_k = ∑_(i∈k) E_i</span>
            </div>
            <h2 className="text-2xl font-bold text-text-main tracking-tight">
              Sector & Market-Cap Exposure Intelligence
            </h2>
            <p className="text-xs text-text-sub mt-1 max-w-2xl">
              Understand industry concentration and market-cap distribution across underlying holdings. Preserves unclassified disclosures without distortion.
            </p>
          </div>

          {/* Scope Toggle: Total Portfolio vs Classified Equity */}
          <div className="flex items-center gap-2.5 bg-[#F8F9FA] p-2 rounded-xl border border-border">
            <span className="text-xs font-medium text-text-sub">Base Denominator:</span>
            <button
              onClick={() => setUseClassifiedOnly(false)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                !useClassifiedOnly
                  ? 'bg-white text-primary shadow-xs border border-border'
                  : 'text-text-sub hover:text-text-main'
              }`}
            >
              % of Total Portfolio
            </button>
            <button
              onClick={() => setUseClassifiedOnly(true)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                useClassifiedOnly
                  ? 'bg-white text-primary shadow-xs border border-border'
                  : 'text-text-sub hover:text-text-main'
              }`}
            >
              % of Classified Equity
            </button>
          </div>
        </div>

        {/* Sector Summary KPI row */}
        <div className="mt-6 pt-6 border-t border-border grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-3.5 rounded-xl bg-slate-50 border border-border">
            <span className="text-[11px] font-medium text-text-sub block">Top Sector Weight</span>
            <span className="text-2xl font-bold text-text-main tabular-nums">
              {analytics.highestSectorExposure
                ? formatPercent(
                    useClassifiedOnly
                      ? analytics.sectorExposures[0]?.effectiveWeightClassified
                      : analytics.highestSectorExposure.weight
                  )
                : '—'}
            </span>
            <span className="text-xs text-text-sub truncate block mt-0.5">
              {analytics.highestSectorExposure?.sector}
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-border">
            <span className="text-[11px] font-medium text-text-sub block">Distinct Sectors</span>
            <span className="text-2xl font-bold text-text-main tabular-nums">
              {analytics.sectorExposures.length}
            </span>
            <span className="text-xs text-text-sub block mt-0.5">
              across {analytics.uniqueStocksCount} companies
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-border">
            <span className="text-[11px] font-medium text-text-sub block">Unclassified Holdings</span>
            <span
              className={`text-2xl font-bold tabular-nums ${
                analytics.unclassifiedWeight > 0.05 ? 'text-amber-700' : 'text-text-main'
              }`}
            >
              {formatPercent(analytics.unclassifiedWeight)}
            </span>
            <span className="text-xs text-text-sub block mt-0.5">
              {analytics.unclassifiedWeight > 0 ? 'Requires enrichment' : '100% categorized'}
            </span>
          </div>
        </div>
      </div>

      {/* Charts Grid: Sector Bar Chart & Donut */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Horizontal Bars */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-border p-5 shadow-xs">
          <div className="mb-2">
            <h3 className="text-sm font-bold text-text-main">Ranked Sector Exposures</h3>
            <p className="text-[11px] text-text-sub">
              {useClassifiedOnly
                ? 'Scaled relative to confirmed classified equity holdings'
                : 'Absolute effective weight in complete portfolio'}
            </p>
          </div>
          <SectorBarChart
            sectors={analytics.sectorExposures}
            maxDisplay={10}
            useClassifiedOnly={useClassifiedOnly}
          />
        </div>

        {/* Sector Donut */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-border p-5 shadow-xs flex flex-col justify-between">
          <div className="mb-2">
            <h3 className="text-sm font-bold text-text-main">Sector Composition</h3>
            <p className="text-[11px] text-text-sub">Portfolio distribution by industry</p>
          </div>

          <div className="w-full h-60">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sectorPieData}
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {sectorPieData.map((entry, index) => (
                    <Cell key={`sec-cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any, _: any, entry: any) => [
                    `${formatPercent(Number(val))} (${entry.payload.stockCount} stocks)`,
                    entry.payload.name,
                  ]}
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    borderColor: '#E4E7EC',
                    borderRadius: '8px',
                    fontSize: '12px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Top 4 Sectors mini legend */}
          <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-border">
            {sectorPieData.slice(0, 4).map((item) => (
              <div key={item.name} className="flex items-center gap-1.5 truncate">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                <span className="truncate text-text-sub text-[11px]">{item.name}:</span>
                <span className="font-semibold text-text-main tabular-nums text-[11px]">
                  {formatPercent(item.value)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Market Cap Analysis Grid */}
      <div className="bg-white rounded-2xl border border-border p-5 shadow-xs">
        <div className="mb-4">
          <h3 className="text-sm font-bold text-text-main">Market Capitalization Allocation</h3>
          <p className="text-[11px] text-text-sub">
            SEBI classification categories (Large-Cap 1-100, Mid-Cap 101-250, Small-Cap 251+)
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {analytics.marketCapExposures.map((cap) => (
            <div key={cap.category} className="p-4 rounded-xl border border-border bg-[#F8F9FA]/60">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-text-sub">{cap.category}</span>
                <span className="text-[10px] font-semibold text-text-sub px-1.5 py-0.5 rounded bg-white border border-border tabular-nums">
                  {cap.stockCount} stocks
                </span>
              </div>
              <span className="text-2xl font-bold text-text-main tabular-nums">
                {formatPercent(cap.effectiveWeight)}
              </span>
              {/* Visual mini bar */}
              <div className="w-full h-1.5 bg-slate-200 rounded-full mt-2 overflow-hidden">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${Math.min(100, cap.effectiveWeight * 100)}%`,
                    backgroundColor: capColors[cap.category] || '#147D64',
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Comprehensive Sector Table */}
      <div className="bg-white rounded-2xl border border-border shadow-xs overflow-hidden">
        <div className="p-4 border-b border-border bg-[#F8F9FA] flex items-center justify-between">
          <h3 className="text-xs font-bold text-text-main uppercase tracking-wider">
            Sector Exposure Breakdown ({analytics.sectorExposures.length} Sectors)
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#F8F9FA]/60 text-text-sub border-b border-border">
              <tr>
                <th className="p-3.5 font-semibold">Sector</th>
                <th className="p-3.5 font-semibold text-right">Effective Portfolio Weight</th>
                <th className="p-3.5 font-semibold text-right">% of Classified Universe</th>
                <th className="p-3.5 font-semibold text-center">Underlying Stocks</th>
                <th className="p-3.5 font-semibold">Top Company in Sector</th>
                <th className="p-3.5 font-semibold">Contributing Funds</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {analytics.sectorExposures.map((sec) => (
                <tr key={sec.sector} className="hover:bg-slate-50/50">
                  <td className="p-3.5 font-semibold text-text-main flex items-center gap-2">
                    <span
                      className={`w-2.5 h-2.5 rounded-full ${
                        sec.sector === 'Unclassified' ? 'bg-slate-400' : 'bg-primary'
                      }`}
                    />
                    <span>{sec.sector}</span>
                  </td>
                  <td className="p-3.5 text-right tabular-nums font-bold text-primary">
                    {formatPercent(sec.effectiveWeight)}
                  </td>
                  <td className="p-3.5 text-right tabular-nums text-text-sub">
                    {sec.sector === 'Unclassified' ? '—' : formatPercent(sec.effectiveWeightClassified)}
                  </td>
                  <td className="p-3.5 text-center tabular-nums">
                    <span className="px-2 py-0.5 rounded-md bg-slate-100 font-semibold text-[11px] text-text-main">
                      {sec.stockCount} companies
                    </span>
                  </td>
                  <td className="p-3.5 text-text-main">
                    <div className="font-medium">{sec.topStockName}</div>
                    <div className="text-[10px] text-text-sub tabular-nums">
                      Weight: {formatPercent(sec.topStockWeight)}
                    </div>
                  </td>
                  <td className="p-3.5 text-text-sub text-[11px]">
                    <div className="flex flex-wrap gap-1">
                      {sec.contributingFunds.map((f) => (
                        <span
                          key={f}
                          className="px-1.5 py-0.5 rounded bg-slate-100 border border-slate-200 text-[10px]"
                          title={f}
                        >
                          {f.length > 18 ? f.slice(0, 16) + '...' : f}
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
