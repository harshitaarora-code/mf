// Stock Drilldown Modal showing Transparent Effective Exposure Contribution Breakdown

import React from 'react';
import { X, Building2, Layers, ShieldAlert } from 'lucide-react';
import { EffectiveStockExposure } from '../../types';
import { formatPercent, formatINR } from '../../lib/formatting';

interface StockDrilldownModalProps {
  stock: EffectiveStockExposure | null;
  onClose: () => void;
}

export const StockDrilldownModal: React.FC<StockDrilldownModalProps> = ({ stock, onClose }) => {
  if (!stock) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl border border-border shadow-2xl max-w-xl w-full overflow-hidden animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-5 border-b border-border flex items-start justify-between gap-3 bg-[#F8F9FA]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary-light border border-primary-border flex items-center justify-center text-primary shrink-0">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-text-main leading-tight">
                {stock.securityName}
              </h3>
              <div className="flex items-center gap-2 mt-1 text-xs text-text-sub flex-wrap">
                <span className="font-mono bg-white px-1.5 py-0.5 rounded border border-border">
                  ISIN: {stock.isin}
                </span>
                <span>•</span>
                <span className="font-medium text-text-main">{stock.sector}</span>
                <span>•</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 border border-slate-200">
                  {stock.marketCap}
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-text-sub hover:text-text-main p-1 rounded-lg hover:bg-slate-200/60 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Exposure Summary Banner */}
          <div className="grid grid-cols-2 gap-4 p-4 rounded-xl bg-primary-light/50 border border-primary-border">
            <div>
              <span className="text-xs font-medium text-text-sub block">Effective Portfolio Exposure</span>
              <span className="text-2xl font-bold text-primary tabular-nums">
                {formatPercent(stock.effectiveWeight)}
              </span>
            </div>
            {stock.effectiveAmount !== undefined && (
              <div>
                <span className="text-xs font-medium text-text-sub block">Effective Invested Amount</span>
                <span className="text-2xl font-bold text-text-main tabular-nums">
                  {formatINR(stock.effectiveAmount)}
                </span>
              </div>
            )}
          </div>

          {/* Mathematical Formula Explanation */}
          <div className="text-xs text-text-sub bg-[#F8F9FA] p-3 rounded-lg border border-border font-mono">
            <strong>Formula:</strong> Exposure = ∑ (Fund Allocation % × Stock Weight in Fund %)
          </div>

          {/* Contributing Funds Table */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-text-main uppercase tracking-wider">
                Contributing Portfolio Funds ({stock.fundContributions.length})
              </span>
            </div>

            <div className="border border-border rounded-xl overflow-hidden">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#F8F9FA] border-b border-border text-text-sub font-medium">
                  <tr>
                    <th className="p-3">Mutual Fund Scheme</th>
                    <th className="p-3 text-right">Fund Weight (a_j)</th>
                    <th className="p-3 text-right">Stock in Fund (w_ij)</th>
                    <th className="p-3 text-right font-semibold text-text-main">Effective Contribution</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {stock.fundContributions.map((fc, i) => (
                    <tr key={`fc-${i}`} className="hover:bg-slate-50/50">
                      <td className="p-3 font-medium text-text-main flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5 text-text-sub" />
                        <span>{fc.fundName}</span>
                      </td>
                      <td className="p-3 text-right tabular-nums text-text-sub">
                        {formatPercent(fc.fundWeightInPortfolio)}
                      </td>
                      <td className="p-3 text-right tabular-nums text-text-sub">
                        {formatPercent(fc.stockWeightInFund)}
                      </td>
                      <td className="p-3 text-right tabular-nums font-semibold text-primary">
                        {formatPercent(fc.contributionWeight)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Data Quality Notice if any */}
          {stock.dataQualityWarning && (
            <div className="flex items-center gap-2 p-3 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-800">
              <ShieldAlert className="w-4 h-4 shrink-0 text-amber-600" />
              <span>{stock.dataQualityWarning}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-border bg-[#F8F9FA] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-slate-100 text-text-main border border-border rounded-lg text-xs font-semibold shadow-2xs transition-colors"
          >
            Close Drill-Down
          </button>
        </div>
      </div>
    </div>
  );
};
